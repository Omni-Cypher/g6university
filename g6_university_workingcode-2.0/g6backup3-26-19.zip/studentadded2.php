<html>
<head>
<title>Add Student</title>
</head>
<body>
<?php
session_start();
DEFINE ('DB_USER5', 'omnicypher');
    
DEFINE ('DB_PASSWORD5', 'S3RV3R!!');
DEFINE ('DB_HOST5', 'localhost');
DEFINE ('DB_NAME5', 'g6');
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$con = @mysqli_connect(DB_HOST5, DB_USER5, DB_PASSWORD5, DB_NAME5)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());           


    if(!$con)
    {
        echo'Not Connected To Server';
    }
    if(!mysqli_select_db($con,'g6'))
    {
        echo 'Database Not Selected';
    }

    $s_id = $_POST['student_id'];
    $s_name = $_POST['student_name'];
    $a_name = $_POST['advisor_name'];
    $s_number = $_POST['student_number'];
    $doe = $_POST['date_of_enrollment'];
    $hold = $_POST['hold_id'];
    
    $sql = "INSERT INTO student (student_id,student_name,advisor_name,student_number,date_of_enrollment,hold_id) VALUES ('$s_id','$s_name','$a_name','$s_number','$doe','$hold')";
    
    if(!mysqli_query($con,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        echo'Student Inserted';
    }
    header("refresh:2; url=addstudent2.php");
 
?>
 
<form action="studentadded2.php" method="post">
 
<b>Add a New Student</b>
 
<p>Student ID:
<input type="text" name="student_id" size="30" value="" />
</p>
    
<p>First Name:
<input type="text" name="student_name" size="30" value="" />
</p>
 
<p>Advisor Name:
<input type="text" name="advisor_name" size="30" value="" />
</p>
    
<p>Student Number:
<input type="text" name="student_number" size="30" value="" />
</p>
    
<p>Date Of Enrollment:
<input type="text" name="date_of_enrollment" size="30" value="" />
</p>
    
<p>Hold:
<input type="text" name="hold_id" size="30" value="" />
</p>
 
<p>
<input type="submit" name="submit" value="Send" />
</p>
 
</form>
</body>
</html>