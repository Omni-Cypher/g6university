<?php
session_start();
include_once 'mysqli_connect2.php';
include_once 'includes/dbh.inc2.php'; //conn is for the login
?>
<!Doctype html>
<!--https://www.youtube.com/watch?v=xb8aad4MRx8 (help with this code section)--> 
<html>
<head>
    <Title></Title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header>
     <div class ="main-wrapper">
          <div class="box1" style="background-color:lightblue">
        <img class="logo" src="https://www.wilsoncc.edu/wp-content/uploads/2018/02/Graduation-Icon-1.png" alt="college logo" height="60" width="60" position="relative">
        <h1 class="maintitle">Group 6 University</h1>
         </div>

                 <?php
                    if(isset($_SESSION['username'])){
                        
                        //extra admin privlages
                        $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level>0";
                        $result = mysqli_query($conn,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        if($resultCheck>0){
                        //if you are an admin
                        
                            echo '<nav>
                       
                    <ul>
                        <li><a href="main.php">Home</a></li>
                        <li><a href="index.html">Student</a></li>
                        <li><a href="index.html">Admissions</a></li>
                        <li><a href="coursecatalog.php">Course Catalog</a></li>
                        <li><a href="studentsearch.php">Search student</a></li>
                    </ul>
                        <div class="nav-login">';
         
                        //** add more admin abilities above **/    
                       
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form>';
                            
                        }else{
                         //if you are an regular user
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul>
                        <li><a href="main.php">Home</a></li>
                        <li><a href="StudentMain.html">Student</a></li>
                        <li><a href="admissions.html">Admissions</a></li>
                        <li><a href="coursecatalog.php">Course Catalog</a></li>
                        <li><a href="index.html">My Profile</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form>';   
                        }
                }else{
                                echo '<nav>
                        <div class ="main-wrapper">
                    <ul>
                        <li><a href="main.php">Home</a></li>
                        <li><a href="StudentMain.html">Student</a></li>
                        <li><a href="admissions.html">Admissions</a></li>
                        <li><a href="coursecatalog.php">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
                         echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                    <button type="submit" name="submit">Login</button>
                    </form>
                    <a href="signup.php">sign up</a>';
                    }
                ?>
                  
                </div>
        </div>
    </nav>
    </header>