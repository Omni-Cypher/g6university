<?php
include_once 'header.php';
include_once 'includes/dbh.inc2.php';
?>
    
<body class="main" body style="background-color:powderblue;">
<div class="studentinfo">
<?php
// Get a connection for the database
require_once('mysqli_connect2.php');

 
// Create a query for the database
$set = $_POST['search'];
$query = "SELECT student_id, student_name, advisor_name, student_number, date_of_enrollment, hold_id FROM student WHERE student_id ='$set'";

// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);
if(isset($_POST['search']) && isset($_SESSION['username'])) { //checks too see if search was pressed and not just url typed
// If the query executed properly proceed
if($response){

echo'<h1 style="color: cadetblue;padding-top: 20px;padding-left:15px; font-size:200%;">&nbsp;&nbsp;STUDENT SEARCH RESULTS</h1><br><br>';
echo '<table align="left" cellspacing="5" cellpadding="8">
<tr><tr style="color:black;"><td align="left"><b>&emsp;&emsp;Student ID&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Student Name&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Advisor Name&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Student Number&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Date Of Enrollment&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Hold ID</b></td></tr>';
 
// mysqli_fetch_array will return a row of data from the query
// until no further data is available

while($row = mysqli_fetch_array($response)){
 
echo '<tr><td align="left" style="padding-left: 30px; line-height: 50px;">' . $row['student_id'] . '</td><td align="left">' . $row['student_name'] . '</td><td align="left">' . $row['advisor_name'] . '</td><td align="left">' . $row['student_number'] . '</td><td align="left">' . $row['date_of_enrollment'] . '</td><td align="left">' . $row['hold_id'] . '</td>';
 
echo '</tr>';
}
 
echo '</table>';

} else{
 
echo "Couldn't issue database query<br />";
 
echo mysqli_error($dbc);
 
}
}else{
    //if they just typed out the address without the form//
    header("Location:studentsearch.php");
    exit();    
}
 
// Close connection to the database
mysqli_close($dbc);
 
?>
</div>

<div>
<?php
             echo'<br><br><br><br><br><br>
    <div style="padding-left: 30px;">
    <form action="searchedstudent.php" method="post">
    <input type="text" name ="search"/>
    <Button type="submit" name="submit">Search</Button>
    </form></div>';
    ?>
    
</div>
 

</body>
</html>