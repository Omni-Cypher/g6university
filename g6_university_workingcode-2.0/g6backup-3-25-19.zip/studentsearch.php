<?php
include_once 'header.php';
include_once 'includes/dbh.inc2.php';
?>
<title>Search Student</title>

<body class="main" body style="background-color:powderblue;">
<?php
   
             echo'<b><h1 style="padding-top: 50px; padding-left: 40px;";>SEARCH STUDENT</h1></b>
    <div style="padding-left: 40px;">
    <form action="searchedstudent.php" method="post">
    <input type="text" name ="search"/>
    <Button type="submit" name="submit">Search</Button>
    </form></div>';
      
   
?>
</body>
</html>