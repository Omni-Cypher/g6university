<?php
include_once 'header.php';
include_once 'includes/dbh.inc2.php';
?>
<body>
<div class ="sform">
<form action="studentadded2.php" method="post">
 
<b>Add a New Student</b>
 
<p>Student ID:
<input type="text" name="student_id" size="30" value="" />
</p>
    
<p>First Name:
<input type="text" name="student_name" size="30" value="" />
</p>
 
<p>Advisor Name:
<input type="text" name="advisor_name" size="30" value="" />
</p>
    
<p>Student Number:
<input type="text" name="student_number" size="30" value="" />
</p>
    
<p>Date Of Enrollment:
<input type="text" name="date_of_enrollment" size="30" value="" />
</p>
    
<p>Hold:
<input type="text" name="hold_id" size="30" value="" />
</p>
 
<p>
<input type="submit" name="submit" value="Send" />
</p>
 
</form>
</div>
</body>
</html>