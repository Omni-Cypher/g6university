
<html>
<head>
    <Title></Title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header>
     <div class ="main-wrapper">
          <div class="box1" style="background-color:lightblue">
        <img class="logo" src="https://www.wilsoncc.edu/wp-content/uploads/2018/02/Graduation-Icon-1.png" alt="college logo" height="60" width="60" position="relative">
        <h1 class="maintitle">Group 6 University</h1>
         </div>
         

                 <?php
                 session_start();


                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $username = $_SESSION['username'];
                 
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'theusers');
                
                
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());

                 
                 
                 
                    if(isset($_SESSION['username'])){
                        
                        //extra admin privlages
                        $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level>0";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        if($resultCheck>0){
                        //if you are an admin
                        
                            echo '<nav>
                       
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="index.html">Student</a></li>
                        <li><a href="index.html">Admissions</a></li>
                        <li><a href="coursecatalog.php">Course Catalog</a></li>
                        <li><a href="studentsearch.php">Search student</a></li>
                    </ul>
                        <div class="nav-login">';
         
                        //** add more admin abilities above **/    
                       
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form>';
                            
                        }else{
                         //if you are an regular user
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="StudentMain.html">Student</a></li>
                        <li><a href="admissions.html">Admissions</a></li>
                        <li><a href="coursecatalog.php">Course Catalog</a></li>
                        <li><a href="index.html">My Profile</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form>';   
                        }
                }else{
                                echo '<nav>
                        <div class ="main-wrapper">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="StudentMain.html">Student</a></li>
                        <li><a href="admissions.html">Admissions</a></li>
                        <li><a href="coursecatalog.php">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
                         echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                    <button type="submit" name="submit">Login</button>
                    </form>
                    <a href="signup.php">sign up</a>';
                    }
                ?>
                  
                </div>

    </header>
    <section class="main-container">
        <div class="main-wrapper"></div>
        <h2>Main Page</h2>
        <div class="content">
        <?php
        if(isset($_SESSION['username'])){
            $username= $_SESSION['username'];
            echo"Welcome $username,You are logged in";     
            
               $sql = "SELECT * FROM users WHERE username='$username' AND level>0";
            $result = mysqli_query($conn,$sql);
            $resultCheck = mysqli_num_rows($result);
            if($resultCheck>0){
            echo" <br></br><p>you are an admin!!!<p>";
            }
        }
       
        
        ?>
        </div>
     
    </section>

</body>
<div class="footer">
        <div class="ft1">
            <p style="text-align: left; padding: 10px;">Juvon Hyatt Copyright 2018-2019</p>
        </div>

        <div class="ft2">
            <p style="text-align: left; padding: 10px;">Juvon Hyatt Copyright 2018-2019</p>
        </div>

        <div class="ft3">
            <p style="text-align: left; padding: 10px;">Juvon Hyatt Copyright 2018-2019</p>
        </div>
    </div>
    
</html>
