-- MySQL dump 10.13  Distrib 5.6.43, for Linux (x86_64)
--
-- Host: localhost    Database: g6
-- ------------------------------------------------------
-- Server version	5.6.43-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `CS_Major`
--

DROP TABLE IF EXISTS `CS_Major`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CS_Major` (
  `entry_number` int(30) NOT NULL AUTO_INCREMENT,
  `Course_ID` int(30) NOT NULL,
  `Prerequisit_ID` int(30) NOT NULL,
  PRIMARY KEY (`entry_number`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CS_Major`
--

LOCK TABLES `CS_Major` WRITE;
/*!40000 ALTER TABLE `CS_Major` DISABLE KEYS */;
INSERT INTO `CS_Major` (`entry_number`, `Course_ID`, `Prerequisit_ID`) VALUES (11,2501,0),(2,1351,0),(3,1362,0),(4,1369,0),(5,1398,0),(6,1418,0),(7,1434,2501),(8,1441,2501),(9,1425,0),(10,1349,0),(12,2501,0);
/*!40000 ALTER TABLE `CS_Major` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CurrentSemester`
--

DROP TABLE IF EXISTS `CurrentSemester`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CurrentSemester` (
  `entry_number` int(30) NOT NULL,
  `semester` varchar(255) NOT NULL,
  PRIMARY KEY (`entry_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CurrentSemester`
--

LOCK TABLES `CurrentSemester` WRITE;
/*!40000 ALTER TABLE `CurrentSemester` DISABLE KEYS */;
INSERT INTO `CurrentSemester` (`entry_number`, `semester`) VALUES (0,'Summer 2019');
/*!40000 ALTER TABLE `CurrentSemester` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `History_Major`
--

DROP TABLE IF EXISTS `History_Major`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `History_Major` (
  `entry_number` int(255) NOT NULL AUTO_INCREMENT,
  `Course_ID` int(30) NOT NULL,
  `Prerequisite_ID` int(30) NOT NULL,
  PRIMARY KEY (`entry_number`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `History_Major`
--

LOCK TABLES `History_Major` WRITE;
/*!40000 ALTER TABLE `History_Major` DISABLE KEYS */;
INSERT INTO `History_Major` (`entry_number`, `Course_ID`, `Prerequisite_ID`) VALUES (1,2466,0),(2,2210,0),(3,26,0),(4,1,2501),(5,5,2501),(6,13,2501),(7,29,0),(8,114,0),(9,2501,0);
/*!40000 ALTER TABLE `History_Major` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `adminn`
--

DROP TABLE IF EXISTS `adminn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adminn` (
  `Admin_ID` int(11) NOT NULL,
  `A_name` varchar(255) DEFAULT NULL,
  `A_Department` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Admin_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adminn`
--

LOCK TABLES `adminn` WRITE;
/*!40000 ALTER TABLE `adminn` DISABLE KEYS */;
INSERT INTO `adminn` (`Admin_ID`, `A_name`, `A_Department`) VALUES (101,'Timothy Cane','Criminology'),(102,'George Canberry','Criminology'),(103,'Larry Findle','Criminology'),(104,'Tasha Graye','Criminology'),(105,'Geraldine Curry','Criminology'),(106,'Vivian Ramp','Criminology'),(107,'Denise Wilson','Criminology'),(108,'Marsha Johnson','Criminology'),(109,'Sonia Marvel','Criminology'),(110,'Jackie Knaull','Criminology'),(111,'Yvonne Cradle','Criminology'),(112,'Eleanor Winters','Criminology'),(113,'Wayne Cruz','Criminology'),(114,'Umar Crane','Criminology'),(115,'Michael Young','Criminology'),(116,'Joshua Browne','Criminology'),(117,'Douglas Roam','Criminology'),(118,'Patrice Winslow','Criminology'),(119,'Marco Fields','Criminology'),(120,'Nicole Prince','Criminology'),(121,'Carly Pine','Criminology'),(122,'Lindsay Coleman','Criminology'),(123,'Gabriele Jammer','Criminology'),(124,'Beau Griffins ','Criminology'),(125,'Kristopher Engle','Criminology'),(126,'Frank Quinn','Criminology'),(127,'Rudy Blinn','Criminology'),(128,'Cory Runed','Criminology'),(129,'Vernon Riley','Criminology'),(130,'Buck Dunover','Criminology'),(131,'Yolanda Brighte','Criminology'),(132,'Cameron Lindell','Criminology'),(133,'Alexandra Slette','Criminology'),(134,'Keisha Wyatt','Criminology'),(135,'Trudy Seales','Criminology'),(136,'Rasheeda Stevens','Criminology'),(137,'Harvey Pellon','Criminology'),(138,'Malaysia Humphreys','Criminology'),(139,'Felicia Manore','Criminology'),(140,'Ulysses Northwood ','Criminology'),(141,'Daphne Golding','English'),(142,'Andre Roper','English'),(143,'Kyle Marker','English'),(144,'Hunter Togher','English'),(145,'Riley OConnor','English'),(146,'Daniel Swine','English'),(147,'Rashawn Lowe','English'),(148,'Jessica Truette','English'),(149,'Tiffany Banks','English'),(150,'Eileen Hilton','English'),(151,'June Markel','English'),(152,'Xiana Klopsy','English'),(153,'Janice Cooper','English'),(154,'Steven Hopkins','English'),(155,'Stephan Dunberry','English'),(156,'April Duncan','English'),(157,'Laura Fancy','English'),(158,'Julie Guapo','English'),(159,'Kristen Buttons','English'),(160,'Madison Draft','English'),(161,'Kelsey Pardon','English'),(162,'Tiana Olson','English'),(163,'Mary Flint','English'),(164,'Kate Dotte','English'),(165,'Amanda Casley','English'),(166,'Ashley Castelle','English'),(167,'Margrette Juniper','English'),(168,'Oliver Stanley','English'),(169,'Annie Bunt','English'),(170,'Karlene Dabess','English'),(171,'Angelica Tomahawk','English'),(172,'Sharmane Baileys','English'),(173,'Tomas Feliz','English'),(174,'Darlene Platt','English'),(175,'Kristy Jones','English'),(176,'Cooper Buckley','English'),(177,'Stanley Duncan','English'),(178,'Samuel Zienou','English'),(179,'Justin Greene','English'),(180,'Jorge Rodriguez','English'),(181,'Andrea Felix','History and Philosophy'),(182,'Stephanie Rich','History and Philosophy'),(183,'Dennis Gormula','History and Philosophy'),(184,'Diane Codey','History and Philosophy'),(185,'Derek Frinkle','History and Philosophy'),(186,'Richard Uyvas','History and Philosophy'),(187,'Randolph Bice','History and Philosophy'),(188,'Nathan Erie','History and Philosophy'),(189,'Henry Thomas','History and Philosophy'),(190,'Selma Vickers','History and Philosophy'),(191,'Winston Dunes','History and Philosophy'),(192,'Nancy King','History and Philosophy'),(193,'Lance Smith','History and Philosophy'),(194,'Judy Canes','History and Philosophy'),(195,'Samantha Donald','History and Philosophy'),(196,'Francene Hunter','History and Philosophy'),(197,'Joseph Fellow','History and Philosophy'),(198,'Dylan Polly','History and Philosophy'),(199,'Eugene Unice ','History and Philosophy'),(200,'Andrew Stuart','History and Philosophy'),(201,'Colton Nolan','math'),(202,'Warren Walsh','math'),(203,'Emma-Louise Dunn','math'),(204,'Nia Lynn','math'),(205,'Bradleigh Needham','math'),(206,'Liam Fulton','math'),(207,'Callu, Appleton','math'),(208,'Zoha Tyson','math'),(209,'Tayyib Decker','math'),(210,'Shayan Witt','math'),(211,'Tyson Boyd','math'),(212,'Elias Britt','math'),(213,'Albi Clements','math'),(214,'Tamika Floyd','math'),(215,'Reese Shea','math'),(216,'Brodie Reyna','math'),(217,'Khadija Albert','math'),(218,'Amisha Almond','math'),(219,' Traci Merritt','math'),(220,'Muskaan Simmons','math'),(221,'Pranav Proctor','math'),(222,'Billie Brook','math'),(223,'Rylee Huff','math'),(224,'Janice Hart','math'),(225,'Lawson Acevedo','math'),(226,'Briony Puckett','math'),(227,'Amani Pennington','math'),(228,'Gurleen Contreras','math'),(229,'Mairead Finney','math'),(231,'Thomas Parra','math'),(232,'Yousif Ashton','math'),(233,'Archer Little','math'),(234,'Patrick Hines','math'),(235,'Wilfred Zhangl','math'),(236,'Caleb Sinclair','math'),(237,'Phillipa Alexander','math'),(238,'Xander Vo','math'),(239,'Saqlain Maldonado','math'),(240,'Franco Levine','math'),(241,'Elsie-Mae Reed','math'),(242,'Pablo Ingram','math'),(243,'Eleri Alexander','math'),(244,'Abdur-Rahman Herring','math'),(245,'Aishah Logan','math'),(246,'Omari Whitley','math'),(247,'Akeel Booker','math'),(248,'Darrell Rivera','math'),(249,'Sanaya McClain','math'),(250,'Cooper Cuevas','math'),(251,'Beatriz Sanford','math'),(252,'Marlon Prosser','math'),(253,'Charleigh Haley','math'),(254,'Sherri Devine','math'),(255,'Rosina McCulloch','math'),(256,'Yazmin Bouvet','math'),(257,'Paulina Mays','math'),(258,'Javier Stokes','math'),(259,'Kaylem Wharton','math'),(260,'Jada Wormald','math'),(261,'Macey Cardenas','math'),(262,'Cole Dillon','math'),(263,'Tiffany Justice','math'),(264,'Estelle Carey','math'),(265,'Keeleigh Tran','math'),(266,'Kacey Gilmore','math'),(267,'Eesa Villegas','math'),(268,'Milla Parks','math'),(269,'Arandeep Hill','math'),(270,'Francisco Larsen','math'),(271,'Osian Neale','math'),(272,'Sherri Devine','math'),(273,'Rosina McCulloch','math'),(274,'Yazmin Bouvet','math'),(275,'Paulina Mays','math'),(276,'Javier Stokes','math'),(277,'Kaylem Wharton','math'),(278,'Jada Wormald','math'),(279,'Macey Cardenas','math'),(280,'Cloe Dillon','math'),(281,'Tiffany Justice','math'),(282,'Estelle Carey','math'),(283,'Keeleigh Tran','math'),(284,'Kacey Gilmore','math'),(285,'Eesa Villegas','math'),(286,'Milla Parks','math'),(287,'Arandeep Hill','math'),(288,'Francisco Larsen','math'),(289,'Osian Neale','math'),(290,'Sherri Devine','math'),(291,'Rosina McCulloch','math'),(292,'Yazmin Bouvet','math'),(293,'Paulina Mays','math'),(294,'Javier Stokes','math'),(295,'Kaylem Wharton','math'),(296,'Jada Wormald','math'),(297,'Macey Cardenas','math'),(298,'Cloe Dillon','math'),(299,'Tiffany Justice','math'),(300,'Estelle Carey','math'),(301,'Ira Haney','math'),(302,'Addison Booth  ','math'),(303,'Jamaal Figueroa','math'),(304,'Reya Wade','math'),(305,'Ilayda Hagan','math'),(306,'Damian Weaver','math'),(307,'Bluebell Spence','math'),(308,'Isabel Campbell','math'),(309,'Daniyal Foreman','math'),(310,'Aarav Hartman','math'),(311,'Tyson Pruitt','math'),(312,'Tomos Lees','math'),(314,'Lewis Gillespie','math'),(315,'Ruby-Leigh Zavala','math'),(316,'Hetty Jeffery','math'),(317,'Kali Mcgee','math'),(318,'Milana Valenzuela','math'),(319,'Manahil Cameron','math'),(320,'Arnav Howell','math'),(321,'Arnav Howell','math'),(322,'Polly Medrano','math'),(323,'Brian Daly','math'),(324,'Siena Akhtar','math'),(325,'Cayden Whitmore','math'),(326,'Chantelle Morton','math'),(327,'Charleigh Miranda','math'),(328,'Szymon Wainwright','math'),(329,'Junayd Rahman','math'),(330,'Aoife Flowers','math'),(331,'Justine Davis','math'),(332,'Aimee Stewart','math'),(333,'Collette Watts','math'),(334,'Tonya Searle','math'),(335,'Christiana Guzman','math'),(336,'Danielle Huang','math'),(337,'Zavier Taylor','math'),(338,'Arnav Howell','math'),(339,'Arnav Howell','math'),(340,'Alys Kearney','math'),(341,'Aden Bonilla','math'),(342,'Renesmae Lancaster','math'),(343,'Myla Greig','math'),(344,'Hallie Dougherty','math'),(345,'Anaya Mclellan','math'),(346,'Nur Kidd','math'),(347,'Charlize Cooper','math'),(348,'Dione Sloan','math'),(349,'Dione Sloan','math'),(350,'Rajan Chadwick','math'),(351,'Jasper Mackie','math'),(352,'Karam Hays','math'),(353,'Emmeline Wardle','math'),(354,'Nikkita Fry','math'),(355,'Fenella Seymour','math'),(356,' John-Paul Salt','math'),(357,'Isobella Hawkins','math'),(358,'Aryan Rossi','math'),(359,'Dione Sloan','math'),(360,'Dione Sloan','math'),(361,'Jordi Neville','math'),(362,'Aaryan Norton','math'),(363,'Nile Kouma','math'),(364,'Lorena Romero','math'),(365,'Alanna Beltran','math'),(366,'Sandra Richard','math'),(367,'Eilidh Charles','math'),(368,'Frazer Drew','math'),(369,'Amanda Ashley','math'),(370,'Meghan Jimenez','math'),(371,'Ellie Goldsmith','math'),(372,'Fredrick Combs','math'),(373,'Kenzo Buck','math'),(374,'Sophia-Rose Driscoll','math'),(375,'Adaline Alvarez','math'),(376,'Elodie Parsons','math'),(377,'Jardel Tomlinson','math'),(378,'Eliana Perkins','math'),(379,'Lorelei Powell','math'),(380,'Zak Golden','math'),(381,'Jennifer Carpenter','math'),(382,'Hudson Vargas','math'),(383,'Tazmin Alford','math'),(384,'Courtney Calderon','math'),(385,'Sumaiya Kumar','math'),(386,'Eleanor Hodson','math'),(387,'Aimee Dowling','math'),(388,'Louise Peterson','math'),(389,'Adnan Mayo','math'),(390,'Jem Stacey','math'),(391,'Teresa Hurley','math'),(392,'Cristiano Ferry','math'),(393,'Lincoln Daly','math'),(394,'Corrie Burns','math'),(395,'Parker Conner','math'),(396,'Lewis Byers','math'),(397,'Toni Cohen','math'),(398,'Subhaan Erickson','math'),(399,'Sofie Feeney','math'),(400,'John Green','math'),(401,'Najma Hills','math'),(501,'Jonathan Price','History and Philosophy'),(502,'Jack Moore','History and Philosophy'),(503,'Graham Lowell','History and Philosophy'),(504,'Royal Payne','History and Philosophy'),(505,'Charles Fliller','History and Philosophy'),(506,'Carmen Opal','History and Philosophy'),(507,'Phoebe Daley','History and Philosophy'),(508,'Candace Oday','History and Philosophy'),(509,'Sonia Marvel','History and Philosophy'),(510,'Lacey Knaull','History and Philosophy'),(511,'Alexis Randell','History and Philosophy'),(512,'Rosalie Wint','History and Philosophy'),(513,'Vincent Cruz','History and Philosophy'),(514,'Dane Jackal','History and Philosophy'),(515,'Damion Rollo','History and Philosophy'),(516,'Bruno Bakey','History and Philosophy'),(517,'Roman Kindale','History and Philosophy'),(518,'Yanique Winchester','History and Philosophy'),(519,'Ashlynn Gunner','History and Philosophy'),(520,'Randy Blues','History and Philosophy'),(521,'Nicole Pine','Industrial & Labor Relations'),(522,'Japrice Mann','Industrial & Labor Relations'),(523,'Ginger Lummer','Industrial & Labor Relations'),(524,'Rodolph Chinns ','Industrial & Labor Relations'),(525,'Kristen Toff','Industrial & Labor Relations'),(526,'Quinn Deuces','Industrial & Labor Relations'),(527,'Betty Nimp','Industrial & Labor Relations'),(528,'Sasha Umpert','Industrial & Labor Relations'),(529,'Eric Watte','Industrial & Labor Relations'),(530,'Carl Staples','Industrial & Labor Relations'),(531,'Maggie Corner','Industrial & Labor Relations'),(532,'Tevin Lowell','Industrial & Labor Relations'),(533,'Kayla Frinne','Industrial & Labor Relations'),(534,'Kacie Russe','Industrial & Labor Relations'),(535,'Angelo Lucci','Industrial & Labor Relations'),(536,'Ronda Colls','Industrial & Labor Relations'),(537,'Henrietta Bush','Industrial & Labor Relations'),(538,'Malaysia Kloe','Industrial & Labor Relations'),(539,'Theresa Moore','Industrial & Labor Relations'),(540,'Justice Northwood','Industrial & Labor Relations'),(541,'Kwasi Golding','Industrial & Labor Relations'),(542,'Olu Roper','Industrial & Labor Relations'),(543,'Tamika Marker','Industrial & Labor Relations'),(544,'Megan Coles','Industrial & Labor Relations'),(545,'Rufus Dome','Industrial & Labor Relations'),(546,'Danielle Surfer','Industrial & Labor Relations'),(547,'Rachel Roe','Industrial & Labor Relations'),(548,'Jessie Turtle','Industrial & Labor Relations'),(549,'Tommy Bundt','Industrial & Labor Relations'),(550,'Elise Hill','Industrial & Labor Relations'),(551,'Jennifer Money','Industrial & Labor Relations'),(552,'Kathleen Klopsy','Industrial & Labor Relations'),(553,'Mildred Hooper','Industrial & Labor Relations'),(554,'Christina Chopkin','Industrial & Labor Relations'),(555,'Kalim Guap','Industrial & Labor Relations'),(556,'Aileen Moors','Industrial & Labor Relations'),(557,'Lizette Pointe','Industrial & Labor Relations'),(558,'Julissa Gunther','Industrial & Labor Relations'),(559,'Misty Uvas','Industrial & Labor Relations'),(560,'Courtney Lumell','Industrial & Labor Relations'),(561,'Kevin Dunmark','Liberal Studies'),(562,'Tara Flint','Liberal Studies'),(563,'Maryanne Rutte','Liberal Studies'),(564,'Tina Dunes','Liberal Studies'),(565,'Penny Casley','Liberal Studies'),(566,'Olsa Castelle','Liberal Studies'),(567,'Mehgan Russo','Liberal Studies'),(568,'Maxwell Putt','Liberal Studies'),(569,'Anisa Junee','Liberal Studies'),(570,'Karol Munt','Liberal Studies'),(571,'Angela Lopel','Liberal Studies'),(572,'Shelly Tompkins','Liberal Studies'),(573,'Lamar Jones','Liberal Studies'),(574,'Jeanene Francis','Liberal Studies'),(575,'Paul Buckner','Liberal Studies'),(576,'Jane Cooper','Liberal Studies'),(577,'Shane Stevens','Liberal Studies'),(578,'Jacklyn Crosse','Liberal Studies'),(579,'Pauline Hope','Liberal Studies'),(580,'Duncan Member','Liberal Studies'),(581,'Cheryl Pole','Liberal Studies'),(582,'Conrad Cruz','Liberal Studies'),(583,'Caesar Rodriguez','Liberal Studies'),(584,'Opal Johnson','Liberal Studies'),(585,'Dominic Winn','Liberal Studies'),(586,'Ruth Christopher','Liberal Studies'),(587,'Gregory Bundle','Liberal Studies'),(588,'Peter Erie','Liberal Studies'),(589,'Ruth Thomas','Liberal Studies'),(590,'Susan Vinny','Liberal Studies'),(591,'Edward Williams','Liberal Studies'),(592,'Bradley Nunn','Liberal Studies'),(593,'Shane Schmitt','Liberal Studies'),(594,'Craig Zipp','Liberal Studies'),(595,'William Aitchison','Liberal Studies'),(596,'Claudia Angels','Liberal Studies'),(597,'Jose Fiend','Liberal Studies'),(598,'Vanessa Vice','Liberal Studies'),(599,'David Samm ','Liberal Studies'),(600,'Shamiek Roe','Liberal Studies'),(701,' Lee Finch ','math'),(702,' Trystan Hill ','math'),(703,' Monika Vega ','math'),(704,' Kamal Cunningham ','math'),(705,' Oliver Clements ','math'),(706,' Emmy Rahman ','math'),(707,' Anita Higgs ','math'),(708,' Malaikah Brown ','math'),(709,' Zayd Matthams ','math'),(710,' Melvin Keeling ','math'),(711,' Donnie Khan ','math'),(712,' Monique Kearns ','math'),(713,' Elias Guy ','math'),(714,' Mira Alston ','math'),(715,' Lewys Dodson ','math'),(716,' Aras Lim ','math'),(717,' Wilbur Lopez ','math'),(718,' Dolcie Simons ','math'),(719,' Rojin Benson ','math'),(720,' Drew Charles ','math'),(721,' Arron Langley ','math'),(722,' Allana Villalobos ','math'),(723,' Conal Macdonald ','math'),(724,' Jesse Cantrell ','math'),(725,' Ashleigh Walls ','math'),(726,' Milly Sargent ','math'),(727,' Zakariyah Roche ','math'),(728,' Yusuf Acevedo ','math'),(729,' Sherri Ruiz ','math'),(730,' Joely Gillespie ','math'),(731,' Eoghan Conrad ','math'),(732,' Jamil York ','math'),(733,' Santiago Heath ','math'),(734,' Nancie Madden ','math'),(735,' Declan Reed ','math'),(736,' Clarke Alfaro ','math'),(737,' Sapphire Mclaughlin ','math'),(738,' Toni Montoya ','math'),(739,' Cherise Summers ','math'),(740,' Sofija Oneal ','math'),(741,' Marcel Nelson ','math'),(742,' Abiha Schmitt ','math'),(743,' Allan Little ','math'),(744,' Osama Ball ','math'),(745,' Tyrell Emery ','math'),(746,' Dominik Cash ','math'),(747,' Amayah Fleming ','math'),(748,' Manraj Bray ','math'),(749,' Tate Santiago ','math'),(750,' Reuben Medrano ','math'),(751,' Billie-Jo Cresswell ','math'),(752,' Hina Burton ','math'),(753,' Annabelle Rayner ','math'),(754,' Casper Camacho ','math'),(755,' Theon Rush ','math'),(756,' Ioana Aguilar ','math'),(757,' Lindsey Collier ','math'),(758,' Nabil Crosby ','math'),(759,' Ezekiel Coleman ','math'),(760,' Tea Armstrong ','math'),(761,' Nayla Estrada ','math'),(762,' Chris Myers ','math'),(763,' Jonas Vargas ','math'),(764,' Daisy-Mae Colon ','math'),(765,' Akeem Molina ','math'),(766,' Gwion Mooney ','math'),(767,' Kishan Brandt ','math'),(768,' Dante Odonnell ','math'),(769,' Helin Lucas ','math'),(770,' Robyn Rosario ','math'),(771,' Asiya Mcdonald ','math'),(772,' Eamonn Penn ','math'),(773,' Daanyaal Campos ','math'),(774,' Benjamin Akhtar ','math');
/*!40000 ALTER TABLE `adminn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advisor`
--

DROP TABLE IF EXISTS `advisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `advisor` (
  `Advisor_ID` int(11) NOT NULL,
  `Advisor_Name` varchar(255) DEFAULT NULL,
  `Advisor_Number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Advisor_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advisor`
--

LOCK TABLES `advisor` WRITE;
/*!40000 ALTER TABLE `advisor` DISABLE KEYS */;
/*!40000 ALTER TABLE `advisor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attendance` (
  `entry_number` int(255) NOT NULL AUTO_INCREMENT,
  `class_id` int(30) NOT NULL,
  `student_id` int(30) NOT NULL,
  `date` varchar(255) NOT NULL,
  `record` varchar(255) NOT NULL DEFAULT 'Absent',
  PRIMARY KEY (`entry_number`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` (`entry_number`, `class_id`, `student_id`, `date`, `record`) VALUES (1,26,700000000,'2019/04/30','absent'),(32,1434,700000030,'2019/05/06','absent'),(31,114,700000000,'2019/05/02','absent'),(2,114,700000000,'2019/04/30','absent'),(33,26,700000000,'2019/05/08','absent');
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `building`
--

DROP TABLE IF EXISTS `building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `building` (
  `Building_Name` varchar(255) NOT NULL,
  PRIMARY KEY (`Building_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `building`
--

LOCK TABLES `building` WRITE;
/*!40000 ALTER TABLE `building` DISABLE KEYS */;
INSERT INTO `building` (`Building_Name`) VALUES (' East'),(' North'),(' South'),(' West');
/*!40000 ALTER TABLE `building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classsection`
--

DROP TABLE IF EXISTS `classsection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classsection` (
  `Course_ID` varchar(255) DEFAULT NULL,
  `Student_Name` varchar(255) DEFAULT NULL,
  `Student_Number` int(11) DEFAULT NULL,
  `Advisor_ID` int(11) DEFAULT NULL,
  `Hold_ID` int(11) DEFAULT NULL,
  KEY `Advisor_ID` (`Advisor_ID`),
  KEY `Hold_ID` (`Hold_ID`),
  CONSTRAINT `classsection_ibfk_1` FOREIGN KEY (`Advisor_ID`) REFERENCES `advisor` (`Advisor_ID`),
  CONSTRAINT `classsection_ibfk_2` FOREIGN KEY (`Hold_ID`) REFERENCES `holds` (`Hold_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classsection`
--

LOCK TABLES `classsection` WRITE;
/*!40000 ALTER TABLE `classsection` DISABLE KEYS */;
/*!40000 ALTER TABLE `classsection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `Course_ID` int(30) NOT NULL,
  `CRN` varchar(255) NOT NULL,
  `Time_ID` int(11) DEFAULT NULL,
  `Course_Name` varchar(255) DEFAULT NULL,
  `open_seats` int(30) NOT NULL DEFAULT '25',
  `Course_Credits` int(11) DEFAULT NULL,
  `Semester_ID` varchar(255) DEFAULT NULL,
  `Course_Description` varchar(255) DEFAULT NULL,
  `Professor_ID` int(11) DEFAULT NULL,
  `Department_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`Course_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` (`Course_ID`, `CRN`, `Time_ID`, `Course_Name`, `open_seats`, `Course_Credits`, `Semester_ID`, `Course_Description`, `Professor_ID`, `Department_ID`) VALUES (1,'AS1282',18,'Intro To African American Studies - 001',25,4,'Spring 2019','TBA',900100,101101),(2,'AS1282',59,'Intro To African American Studies - 002',25,4,'Summer 2019','TBA',900100,101101),(3,'AS1282',17,'Intro To African American Studies - 003',25,4,'Fall 2019','TBA',900100,101101),(4,'AS1282',23,'Intro To African American Studies - 004',25,4,'Winter 2019','TBA',900100,101101),(5,'AS1282',17,'Introduction to African American Studies - 001',25,4,'Spring 2019','TBA',900101,101101),(6,'AS1282',15,'Introduction to African American Studies - 002',25,4,'Summer 2019','TBA',900101,101101),(7,'AS1282',17,'Introduction to African American Studies - 003',25,4,'Fall 2019','TBA',900101,101101),(8,'AS1282',47,'Introduction to African American Studies - 004',25,4,'Winter 2019','TBA',900101,101101),(9,'AS2202',28,'Contemporary U.S. Society - 001',25,4,'Spring 2019','TBA',900102,101101),(10,'AS2202',48,'Contemporary U.S. Society - 002',25,4,'Summer 2019','TBA',900102,101101),(11,'AS2202',38,'Contemporary U.S. Society - 003',25,4,'Fall 2019','TBA',900102,101101),(12,'AS2202',36,'Contemporary U.S. Society - 004',25,4,'Winter 2019','TBA',37,101101),(13,'AS2252',13,'US Social Movement - 001',25,4,'Spring 2019','TBA',37,101101),(14,'AS2252',52,'US Social Movement - 002',25,4,'Summer 2019','TBA',900103,101101),(15,'AS2252',44,'US Social Movement - 003',25,4,'Fall 2019','TBA',900103,101101),(16,'AS2252',22,'US Social Movement - 004',25,4,'Winter 2019','TBA',900103,101101),(17,'A1S152',21,'Themes in U.S. History - 001',25,4,'Spring 2019','TBA',900104,101101),(18,'A1S152',48,'Themes in U.S. History - 002',25,4,'Summer 2019','TBA',900104,101101),(19,'A1S152',39,'Themes in U.S. History - 003',25,4,'Fall 2019','TBA',900104,101101),(20,'A1S152',46,'Themes in U.S. History - 004',25,4,'Winter 2019','TBA',900104,101101),(21,'AS2202',51,'Contemporary U.S. Society - 001',25,4,'Spring 2019','TBA',900105,101101),(22,'AS2202',24,'Contemporary U.S. Society - 002',25,4,'Summer 2019','TBA',0,101101),(23,'AS2202',16,'Contemporary U.S. Society - 003',25,4,'Fall 2019','TBA',900105,101101),(24,'AS2202',45,'Contemporary U.S. Society - 004',25,4,'Winter 2019','TBA',900105,101101),(25,'AS2252',34,'US Social Movement - 001',25,4,'Spring 2019','TBA',900106,101101),(26,'AS2252',14,'US Social Movement - 002',25,4,'Summer 2019','TBA',37,101101),(27,'AS2252',24,'US Social Movement - 003',25,4,'Fall 2019','TBA',900106,101101),(28,'AS2252',58,'US Social Movement - 004',25,4,'Winter 2019','TBA',900106,101101),(29,'AS2262',59,'African American History I - 001',25,4,'Spring 2019','TBA',0,101101),(30,'AS2262',36,'African American History I - 002',25,4,'Summer 2019','TBA',900107,101101),(31,'AS2262',20,'African American History I - 003',25,4,'Fall 2019','TBA',900107,101101),(32,'AS2262',12,'African American History I - 004',25,4,'Winter 2019','TBA',900107,101101),(33,'AS2263',58,'African American History II - 001',25,4,'Spring 2019','TBA',900108,101101),(34,'AS2263',59,'African American History II - 002',25,4,'Summer 2019','TBA',900108,101101),(35,'AS2263',17,'African American History II - 003',25,4,'Fall 2019','TBA',900108,101101),(36,'AS2263',59,'African American History II - 004',25,4,'Winter 2019','TBA',900108,101101),(37,'AS2300',54,'Problems in US Environmental History - 001',25,4,'Spring 2019','TBA',900109,101101),(38,'AS2300',11,'Problems in US Environmental History - 002',25,4,'Summer 2019','TBA',900109,101101),(39,'AS2300',20,'Problems in US Environmental History - 003',25,4,'Fall 2019','TBA',900109,101101),(40,'AS2300',30,'Problems in US Environmental History - 004',25,4,'Winter 2019','TBA',900109,101101),(41,'AS2740',23,'US Latina/o History - 001',25,4,'Spring 2019','TBA',900110,101101),(42,'AS2740',40,'US Latina/o History - 002',25,4,'Summer 2019','TBA',900110,101101),(43,'AS2740',12,'US Latina/o History - 003',25,4,'Fall 2019','TBA',900110,101101),(44,'AS2740',59,'US Latina/o History - 004',25,4,'Winter 2019','TBA',900110,101101),(45,'AS2752',44,'Media Studies - 001',25,4,'Spring 2019','TBA',900111,101101),(46,'AS2752',56,'Media Studies - 002',25,4,'Summer 2019','TBA',900111,101101),(47,'AS2752',15,'Media Studies - 003',25,4,'Fall 2019','TBA',900111,101101),(48,'AS2752',12,'Media Studies - 004',25,4,'Winter 2019','TBA',900111,101101),(49,'AS2802',52,'Introduction to Journalism and Media - 001',25,4,'Spring 2019','TBA',900112,101101),(50,'AS2802',29,'Introduction to Journalism and Media - 002',25,4,'Summer 2019','TBA',900112,101101),(51,'AS2802',34,'Introduction to Journalism and Media - 003',25,4,'Fall 2019','TBA',900112,101101),(52,'AS2802',24,'Introduction to Journalism and Media - 004',25,4,'Winter 2019','TBA',900112,101101),(53,'AS3222',24,'Urban History - 001',25,4,'Spring 2019','TBA',900113,101101),(54,'AS3222',50,'Urban History - 002',25,4,'Summer 2019','TBA',900113,101101),(55,'AS3222',26,'Urban History - 003',25,4,'Fall 2019','TBA',900113,101101),(56,'AS3222',38,'Urban History - 004',25,4,'Winter 2019','TBA',900113,101101),(57,'AS3252',55,'U.S. Social Movements - 001',25,4,'Spring 2019','TBA',900114,101101),(58,'AS3252',12,'U.S. Social Movements - 002',25,4,'Summer 2019','TBA',900114,101101),(59,'AS3252',55,'U.S. Social Movements - 003',25,4,'Fall 2019','TBA',900114,101101),(60,'AS3252',44,'U.S. Social Movements - 004',25,4,'Winter 2019','TBA',900114,101101),(61,'AS3270',54,'Africa in the Americas - 001',25,4,'Spring 2019','TBA',900115,101101),(62,'AS3270',49,'Africa in the Americas - 002',25,4,'Summer 2019','TBA',900115,101101),(63,'AS3270',14,'Africa in the Americas - 003',25,4,'Fall 2019','TBA',900115,101101),(64,'AS3270',40,'Africa in the Americas - 004',25,4,'Winter 2019','TBA',900115,101101),(65,'AS3432',24,'Women: Cultural Issues - 001',25,4,'Spring 2019','TBA',900116,101101),(66,'AS3432',16,'Women: Cultural Issues - 002',25,4,'Summer 2019','TBA',900116,101101),(67,'AS3432',21,'Women: Cultural Issues - 003',25,4,'Fall 2019','TBA',0,101101),(68,'AS3432',55,'Women: Cultural Issues - 004',25,4,'Winter 2019','TBA',900116,101101),(69,'AS3462',19,'History of Women in the U.S - 001',25,4,'Spring 2019','TBA',900117,101101),(70,'AS3462',11,'History of Women in the U.S - 002',25,4,'Summer 2019','TBA',900117,101101),(71,'AS3462',44,'History of Women in the U.S - 003',25,4,'Fall 2019','TBA',900117,101101),(72,'AS3462',23,'History of Women in the U.S - 004',25,4,'Winter 2019','TBA',900117,101101),(73,'AS3632',15,'History of U.S. Film - 001',25,4,'Spring 2019','TBA',900118,101101),(74,'AS3632',45,'History of U.S. Film - 002',25,4,'Summer 2019','TBA',900118,101101),(75,'AS3632',44,'History of U.S. Film - 003',25,4,'Fall 2019','TBA',900118,101101),(76,'AS3632',14,'History of U.S. Film - 004',25,4,'Winter 2019','TBA',900118,101101),(77,'AS3712',12,'American Film Genres - 001',25,4,'Spring 2019','TBA',900119,101101),(78,'AS3712',32,'American Film Genres - 002',25,4,'Summer 2019','TBA',900119,101101),(79,'AS3712',16,'American Film Genres - 003',25,4,'Fall 2019','TBA',900119,101101),(80,'AS3712',55,'American Film Genres - 004',25,4,'Winter 2019','TBA',900119,101101),(81,'AS3722',38,'History of Mass Media - 001',25,4,'Spring 2019','TBA',900120,101101),(82,'AS3722',12,'History of Mass Media - 002',25,4,'Summer 2019','TBA',900120,101101),(83,'AS3722',27,'History of Mass Media - 003',25,4,'Fall 2019','TBA',900120,101101),(84,'AS3722',42,'History of Mass Media - 004',25,4,'Winter 2019','TBA',900120,101101),(85,'AS30732',12,'Politics of Media - 001',25,4,'Spring 2019','TBA',900121,101101),(86,'AS30732',14,'Politics of Media - 002',25,4,'Summer 2019','TBA',900121,101101),(87,'AS30732',32,'Politics of Media - 003',25,4,'Fall 2019','TBA',900121,101101),(88,'AS30732',37,'Politics of Media - 004',25,4,'Winter 2019','TBA',900121,101101),(89,'AS30735',22,'Documentary Media Studies - 001',25,4,'Spring 2019','TBA',900122,101101),(90,'AS30735',15,'Documentary Media Studies - 002',25,4,'Summer 2019','TBA',900122,101101),(91,'AS30735',21,'Documentary Media Studies - 003',25,4,'Fall 2019','TBA',900122,101101),(92,'AS30735',15,'Documentary Media Studies - 004',25,4,'Winter 2019','TBA',900122,101101),(93,'AS30742',49,'Myths and Images in Film - 001',25,4,'Spring 2019','TBA',900123,101101),(94,'AS30742',29,'Myths and Images in Film - 002',25,4,'Summer 2019','TBA',900123,101101),(95,'AS30742',38,'Myths and Images in Film - 003',25,4,'Fall 2019','TBA',900123,101101),(96,'AS30742',44,'Myths and Images in Film - 004',25,4,'Winter 2019','TBA',900123,101101),(97,'AS3745',42,'Film and Gender - 001',25,4,'Spring 2019','TBA',900124,101101),(98,'AS3745',50,'Film and Gender - 002',25,4,'Summer 2019','TBA',900124,101101),(99,'AS3745',14,'Film and Gender - 003',25,4,'Fall 2019','TBA',900124,101101),(100,'AS3745',39,'Film and Gender - 004',25,4,'Winter 2019','TBA',900124,101101),(101,'AS3830',18,'Public Relations and Society - 001',25,4,'Spring 2019','TBA',900125,101101),(102,'AS3830',46,'Public Relations and Society - 002',25,4,'Summer 2019','TBA',900125,101101),(103,'AS3830',35,'Public Relations and Society - 003',25,4,'Fall 2019','TBA',900125,101101),(104,'AS3830',23,'Public Relations and Society - 004',25,4,'Winter 2019','TBA',900125,101101),(105,'AS4160',34,'Special Topics in Media Studies - 001',25,4,'Spring 2019','TBA',900126,101101),(106,'AS4160',38,'Special Topics in Media Studies - 002',25,4,'Summer 2019','TBA',900126,101101),(107,'AS4160',22,'Special Topics in Media Studies - 003',25,4,'Fall 2019','TBA',900126,101101),(108,'AS4160',24,'Special Topics in Media Studies - 004',25,4,'Winter 2019','TBA',900126,101101),(109,'AS4212',48,'Early America - 001',25,4,'Spring 2019','TBA',900127,101101),(110,'AS4212',57,'Early America - 002',25,4,'Summer 2019','TBA',900127,101101),(111,'AS4212',29,'Early America - 003',25,4,'Fall 2019','TBA',900127,101101),(112,'AS4212',17,'Early America - 004',25,4,'Winter 2019','TBA',900127,101101),(113,'AS421',29,'Critical Ideas in American History - 001',25,4,'Spring 2019','TBA',900128,101101),(114,'AS421',18,'Critical Ideas in American History - 002',25,4,'Summer 2019','114	AS421	Critical Ideas in American History - 002',0,101101),(115,'AS421',59,'Critical Ideas in American History - 003',25,4,'Fall 2019','TBA',900128,101101),(116,'AS421',42,'Critical Ideas in American History - 004',25,4,'Winter 2019','TBA',900128,101101),(117,'AS4218',54,'Civil War and Reconstruction - 001',25,4,'Spring 2019','TBA',900129,101101),(118,'AS4218',37,'Civil War and Reconstruction - 002',25,4,'Summer 2019','TBA',900129,101101),(119,'AS4218',26,'Civil War and Reconstruction - 003',25,4,'Fall 2019','TBA',900129,101101),(120,'AS4218',13,'Civil War and Reconstruction - 004',25,4,'Winter 2019','TBA',0,101101),(121,'AS4222',43,'The Emergence of Modern America - 001',25,4,'Spring 2019','TBA',900130,101101),(122,'AS4222',26,'The Emergence of Modern America - 002',25,4,'Summer 2019','TBA',900130,101101),(123,'AS4222',38,'The Emergence of Modern America - 003',25,4,'Fall 2019','TBA',900130,101101),(124,'AS4222',55,'The Emergence of Modern America - 004',25,4,'Winter 2019','TBA',900130,101101),(125,'AS4222',45,'Special Topics in Media Studies - 001',25,4,'Spring 2019','TBA',900131,101101),(126,'AS4222',54,'Special Topics in Media Studies - 002',25,4,'Summer 2019','TBA',900131,101101),(127,'AS4222',44,'Special Topics in Media Studies - 003',25,4,'Fall 2019','TBA',900131,101101),(128,'AS4222',48,'Special Topics in Media Studies - 004',25,4,'Winter 2019','TBA',900131,101101),(129,'AS4223',45,'The Emergence of Modern America - 001',25,4,'Spring 2019','TBA',900132,101101),(130,'AS4223',31,'The Emergence of Modern America - 002',25,4,'Summer 2019','TBA',900132,101101),(131,'AS4223',42,'The Emergence of Modern America - 003',25,4,'Fall 2019','TBA',900132,101101),(132,'AS4223',34,'The Emergence of Modern America - 004',25,4,'Winter 2019','TBA',900132,101101),(133,'AS4250',33,'Immigration Today - 001',25,4,'Spring 2019','TBA',900133,101101),(134,'AS4250',16,'Immigration Today - 002',25,4,'Summer 2019','TBA',900133,101101),(135,'AS4250',44,'Immigration Today - 003',25,4,'Fall 2019','TBA',900133,101101),(136,'AS4250',48,'Immigration Today - 004',25,4,'Winter 2019','TBA',900133,101101),(137,'AS4253',43,'Latino New York - 001',25,4,'Spring 2019','TBA',900134,101101),(138,'AS4253',55,'Latino New York - 002',25,4,'Summer 2019','TBA',900134,101101),(139,'AS4253',40,'Latino New York - 003',25,4,'Fall 2019','TBA',900134,101101),(140,'AS4253',23,'Latino New York - 004',25,4,'Winter 2019','TBA',900134,101101),(141,'AS4280',55,'Global Media - 001',25,4,'Spring 2019','TBA',900135,101101),(142,'AS4280',27,'Global Media - 002',25,4,'Summer 2019','TBA',900135,101101),(143,'AS4280',23,'Global Media - 003',25,4,'Fall 2019','TBA',900135,101101),(144,'AS4280',30,'Global Media - 004',25,4,'Winter 2019','TBA',900135,101101),(145,'AS4282',19,'America in War and Peace: 1898 to 2001 - 001',25,4,'Spring 2019','TBA',900136,101101),(146,'AS4282',56,'America in War and Peace: 1898 to 2001 - 002',25,4,'Summer 2019','TBA',900136,101101),(147,'AS4282',11,'America in War and Peace: 1898 to 2001 - 003',25,4,'Fall 2019','TBA',900136,101101),(148,'AS4282',20,'America in War and Peace: 1898 to 2001 - 004',25,4,'Winter 2019','TBA',900136,101101),(149,'AS4283',38,'America Between the World Wars - 001',25,4,'Spring 2019','TBA',900137,101101),(150,'AS4283',25,'America Between the World Wars - 002',25,4,'Summer 2019','TBA',900137,101101),(151,'AS4283',12,'America Between the World Wars - 003',25,4,'Fall 2019','TBA',900137,101101),(152,'AS4283',44,'America Between the World Wars - 004',25,4,'Winter 2019','TBA',900137,101101),(153,'AS4285',14,'Vietnam and After - 001',25,4,'Spring 2019','TBA',900138,101101),(154,'AS4285',54,'Vietnam and After - 002',25,4,'Summer 2019','TBA',900138,101101),(155,'AS4285',25,'Vietnam and After - 003',25,4,'Fall 2019','TBA',900138,101101),(156,'AS4285',44,'Vietnam and After - 004',25,4,'Winter 2019','TBA',900138,101101),(157,'AS4288',13,'Contemporary U.S. Foreign Policy - 001',25,4,'Spring 2019','TBA',900139,101101),(158,'AS4288',36,'Contemporary U.S. Foreign Policy - 002',25,4,'Summer 2019','TBA',900139,101101),(159,'AS4288',35,'Contemporary U.S. Foreign Policy - 003',25,4,'Fall 2019','TBA',900139,101101),(160,'AS4288',37,'Contemporary U.S. Foreign Policy - 004',25,4,'Winter 2019','TBA',900139,101101),(161,'AS4292',39,'America Since WWII: 1945-1989 - 001',25,4,'Spring 2019','TBA',900140,101101),(162,'AS4292',49,'America Since WWII: 1945-1989 - 002',25,4,'Summer 2019','TBA',900140,101101),(163,'AS4292',35,'America Since WWII: 1945-1989 - 003',25,4,'Fall 2019','TBA',900140,101101),(164,'AS4292',11,'America Since WWII: 1945-1989 - 004',25,4,'Winter 2019','TBA',900140,101101),(165,'AS4402',35,'History of the Family in the U.S. - 001',25,4,'Spring 2019','TBA',900141,101101),(166,'AS4402',21,'History of the Family in the U.S. - 002',25,4,'Summer 2019','TBA',900141,101101),(167,'AS4402',25,'History of the Family in the U.S. - 003',25,4,'Fall 2019','TBA',900141,101101),(168,'AS4402',36,'History of the Family in the U.S. - 004',25,4,'Winter 2019','TBA',900141,101101),(169,'AS4420',17,'History of New York City and State - 001',25,4,'Spring 2019','TBA',900142,101101),(170,'AS4420',20,'History of New York City and State - 002',25,4,'Summer 2019','TBA',900142,101101),(171,'AS4420',55,'History of New York City and State - 003',25,4,'Fall 2019','TBA',900142,101101),(172,'AS4420',28,'History of New York City and State - 004',25,4,'Winter 2019','TBA',900142,101101),(173,'AS4432',52,'History of the Womens Movement - 001',25,4,'Spring 2019','TBA',900143,101101),(174,'AS4432',13,'History of the Womens Movement - 002',25,4,'Summer 2019','TBA',900143,101101),(175,'AS4432',49,'History of the Womens Movement - 003',25,4,'Fall 2019','TBA',900143,101101),(176,'AS4432',15,'History of the Womens Movement - 004',25,4,'Winter 2019','TBA',900143,101101),(177,'AS4435',57,'Woman of Color Feminisms - 001',25,4,'Spring 2019','TBA',900144,101101),(178,'AS4435',42,'Woman of Color Feminisms - 002',25,4,'Summer 2019','TBA',900144,101101),(179,'AS4435',14,'Woman of Color Feminisms - 003',25,4,'Fall 2019','TBA',900144,101101),(180,'AS4435',49,'Woman of Color Feminisms - 004',25,4,'Winter 2019','TBA',900144,101101),(181,'AS4715',52,'African-American Thought and Culture - 001',25,4,'Spring 2019','TBA',900145,101101),(182,'AS4715',47,'African-American Thought and Culture - 002',25,4,'Summer 2019','TBA',900145,101101),(183,'AS4715',52,'African-American Thought and Culture - 003',25,4,'Fall 2019','TBA',900145,101101),(184,'AS4715',14,'African-American Thought and Culture - 004',25,4,'Winter 2019','TBA',900145,101101),(185,'AS4722',27,'Film: Ideas and Aesthetics - 001',25,4,'Spring 2019','TBA',900146,101101),(186,'AS4722',23,'Film: Ideas and Aesthetics - 002',25,4,'Summer 2019','TBA',900146,101101),(187,'AS4722',19,'Film: Ideas and Aesthetics - 003',25,4,'Fall 2019','TBA',900146,101101),(188,'AS4722',58,'Film: Ideas and Aesthetics - 004',25,4,'Winter 2019','TBA',900146,101101),(189,'AS4725',58,'The Photograph and American Culture - 001',25,4,'Spring 2019','TBA',900147,101101),(190,'AS4725',34,'The Photograph and American Culture - 002',25,4,'Summer 2019','TBA',900147,101101),(191,'AS4725',38,'The Photograph and American Culture - 003',25,4,'Fall 2019','TBA',900147,101101),(192,'AS4725',21,'The Photograph and American Culture - 004',25,4,'Winter 2019','TBA',900147,101101),(193,'AS4732',57,'Political Film - 001',25,4,'Spring 2019','TBA',900148,101101),(194,'AS4732',14,'Political Film - 002',25,4,'Summer 2019','TBA',900148,101101),(195,'AS4732',24,'Political Film - 003',25,4,'Fall 2019','TBA',900148,101101),(196,'AS4732',20,'Political Film - 004',25,4,'Winter 2019','TBA',900148,101101),(197,'AS4850',46,'Digital Revolution - 001',25,4,'Spring 2019','TBA',900149,101101),(198,'AS4850',27,'Digital Revolution - 002',25,4,'Summer 2019','TBA',900149,101101),(199,'AS4850',28,'Digital Revolution - 003',25,4,'Fall 2019','TBA',900149,101101),(200,'AS4850',35,'Digital Revolution - 004',25,4,'Winter 2019','TBA',900149,101101),(201,'AS9990',17,'Independent Study - 001',25,4,'Spring 2019','TBA',900150,101101),(202,'AS9990',47,'Independent Study - 002',25,4,'Summer 2019','TBA',900150,101101),(203,'AS9990',49,'Independent Study - 003',25,4,'Fall 2019','TBA',900150,101101),(204,'AS9990',50,'Independent Study - 004',25,4,'Winter 2019','TBA',900150,101101),(205,'BS2400',48,'Basic Biology I with Lab - 001',25,4,'Spring 2019','TBA',900151,101102),(206,'BS2400',12,'Basic Biology I with Lab - 002',25,4,'Summer 2019','TBA',900151,101102),(207,'BS2400',48,'Basic Biology I with Lab - 003',25,4,'Fall 2019','TBA',900151,101102),(208,'BS2400',52,'Basic Biology I with Lab - 004',25,4,'Winter 2019','TBA',900151,101102),(209,'BS5410',53,'Seminar I: Reading in the Discipline - 001',25,4,'Spring 2019','TBA',900152,101102),(210,'BS5410',14,'Seminar I: Reading in the Discipline - 002',25,4,'Summer 2019','TBA',900152,101102),(211,'BS5410',50,'Seminar I: Reading in the Discipline - 003',25,4,'Fall 2019','TBA',900152,101102),(212,'BS5410',42,'Seminar I: Reading in the Discipline - 004',25,4,'Winter 2019','TBA',900152,101102),(213,'BS5420',48,'Basic Biology II with Lab - 001',25,4,'Spring 2019','TBA',900153,101102),(214,'BS5420',35,'Basic Biology II with Lab - 002',25,4,'Summer 2019','TBA',900153,101102),(215,'BS5420',21,'Basic Biology II with Lab - 003',25,4,'Fall 2019','TBA',900153,101102),(216,'BS5420',41,'Basic Biology II with Lab - 004',25,4,'Winter 2019','TBA',900153,101102),(217,'BS5410',44,'Seminar II: Writing in the Discipline - 001',25,4,'Spring 2019','TBA',900154,101102),(218,'BS5410',48,'Seminar II: Writing in the Discipline - 002',25,4,'Summer 2019','TBA',900154,101102),(219,'BS5410',47,'Seminar II: Writing in the Discipline - 003',25,4,'Fall 2019','TBA',900154,101102),(220,'BS5410',36,'Seminar II: Writing in the Discipline - 004',25,4,'Winter 2019','TBA',900154,101102),(221,'BS4400',41,'Cell Biology - 001',25,4,'Spring 2019','TBA',900155,101102),(222,'BS4400',41,'Cell Biology - 002',25,4,'Summer 2019','TBA',900155,101102),(223,'BS4400',30,'Cell Biology - 003',25,4,'Fall 2019','TBA',900155,101102),(224,'BS4400',35,'Cell Biology - 004',25,4,'Winter 2019','TBA',900155,101102),(225,'BS4460',20,'Genetics - 001',25,4,'Spring 2019','TBA',900156,101102),(226,'BS4460',33,'Genetics - 002',25,4,'Summer 2019','TBA',900156,101102),(227,'BS4460',16,'Genetics - 003',25,4,'Fall 2019','TBA',900156,101102),(228,'BS4460',25,'Genetics - 004',25,4,'Winter 2019','TBA',900156,101102),(229,'BS3400',55,'Vertebrate Physiology - 001',25,4,'Spring 2019','TBA',900157,101102),(230,'BS3400',36,'Vertebrate Physiology - 002',25,4,'Summer 2019','TBA',900157,101102),(231,'BS3400',25,'Vertebrate Physiology - 003',25,4,'Fall 2019','TBA',900157,101102),(232,'BS3400',57,'Vertebrate Physiology - 004',25,4,'Winter 2019','TBA',900157,101102),(233,'BS3520',51,'Comparative Anatomy - 001',25,4,'Spring 2019','TBA',900158,101102),(234,'BS3520',31,'Comparative Anatomy - 002',25,4,'Summer 2019','TBA',900158,101102),(235,'BS3520',26,'Comparative Anatomy - 003',25,4,'Fall 2019','TBA',900158,101102),(236,'BS3520',56,'Comparative Anatomy - 004',25,4,'Winter 2019','TBA',900158,101102),(237,'BS4440',58,'Evolution - 001',25,4,'Spring 2019','TBA',900159,101102),(238,'BS4440',31,'Evolution - 002',25,4,'Summer 2019','TBA',900159,101102),(239,'BS4440',36,'Evolution - 003',25,4,'Fall 2019','TBA',900159,101102),(240,'BS4440',25,'Evolution - 004',25,4,'Winter 2019','TBA',900159,101102),(241,'BS4470',40,'Ecology - 001',25,4,'Spring 2019','TBA',900160,101102),(242,'BS4470',49,'Ecology - 002',25,4,'Summer 2019','TBA',900160,101102),(243,'BS4470',16,'Ecology - 003',25,4,'Fall 2019','TBA',900160,101102),(244,'BS4470',35,'Ecology - 004',25,4,'Winter 2019','TBA',900160,101102),(245,'BS2490',37,'Environmental Science - 001',25,4,'Spring 2019','TBA',900161,101102),(246,'BS2490',52,'Environmental Science - 002',25,4,'Summer 2019','TBA',900161,101102),(247,'BS2490',42,'Environmental Science - 003',25,4,'Fall 2019','TBA',900161,101102),(248,'BS2490',21,'Environmental Science - 004',25,4,'Winter 2019','TBA',900161,101102),(249,'BS3400',50,'Vertebrate Physiology - 001',25,4,'Spring 2019','TBA',900162,101102),(250,'BS3400',19,'Vertebrate Physiology - 002',25,4,'Summer 2019','TBA',900162,101102),(251,'BS3400',40,'Vertebrate Physiology - 003',25,4,'Fall 2019','TBA',900162,101102),(252,'BS3400',50,'Vertebrate Physiology - 004',25,4,'Winter 2019','TBA',900162,101102),(253,'BS3450',15,'Plant Biology - 001',25,4,'Spring 2019','TBA',900163,101102),(254,'BS3450',51,'Plant Biology - 002',25,4,'Summer 2019','TBA',900163,101102),(255,'BS3450',21,'Plant Biology - 003',25,4,'Fall 2019','TBA',900163,101102),(256,'BS3450',34,'Plant Biology - 004',25,4,'Winter 2019','TBA',900163,101102),(257,'BS3510',15,'Parasitology - 001',25,4,'Spring 2019','TBA',900164,101102),(258,'BS3510',48,'Parasitology - 002',25,4,'Summer 2019','TBA',900164,101102),(259,'BS3510',45,'Parasitology - 003',25,4,'Fall 2019','TBA',900164,101102),(260,'BS3510',52,'Parasitology - 004',25,4,'Winter 2019','TBA',900164,101102),(261,'BS3520',59,'Comparative Anatomy - 001',25,4,'Spring 2019','TBA',900165,101102),(262,'BS3520',46,'Comparative Anatomy - 002',25,4,'Summer 2019','TBA',900165,101102),(263,'BS3520',48,'Comparative Anatomy - 003',25,4,'Fall 2019','TBA',900165,101102),(264,'BS3520',37,'Comparative Anatomy - 004',25,4,'Winter 2019','TBA',900165,101102),(265,'BS3530',42,'Comparative Genetics - 001',25,4,'Spring 2019','TBA',900166,101102),(266,'BS3530',15,'Comparative Genetics - 002',25,4,'Summer 2019','TBA',900166,101102),(267,'BS3530',25,'Comparative Genetics - 003',25,4,'Fall 2019','TBA',900166,101102),(268,'BS3530',56,'Comparative Genetics - 004',25,4,'Winter 2019','TBA',900166,101102),(269,'BS2400',48,'Basic Biology I with Lab - 001',25,4,'Spring 2019','TBA',900151,101102),(270,'BS2400',12,'Basic Biology I with Lab - 002',25,4,'Summer 2019','TBA',900151,101102),(271,'BS2400',48,'Basic Biology I with Lab - 003',25,4,'Fall 2019','TBA',900151,101102),(272,'BS2400',52,'Basic Biology I with Lab - 004',25,4,'Winter 2019','TBA',900151,101102),(273,'BS5410',53,'Seminar I: Reading in the Discipline - 001',25,4,'Spring 2019','TBA',900152,101102),(274,'BS5410',14,'Seminar I: Reading in the Discipline - 002',25,4,'Summer 2019','TBA',900152,101102),(275,'BS5410',50,'Seminar I: Reading in the Discipline - 003',25,4,'Fall 2019','TBA',900152,101102),(276,'BS5410',42,'Seminar I: Reading in the Discipline - 004',25,4,'Winter 2019','TBA',900152,101102),(277,'BS05420',48,'Basic Biology II with Lab - 001',25,4,'Spring 2019','TBA',900153,101102),(278,'BS05420',35,'Basic Biology II with Lab - 002',25,4,'Summer 2019','TBA',900153,101102),(279,'BS05420',21,'Basic Biology II with Lab - 003',25,4,'Fall 2019','TBA',900153,101102),(280,'BS05420',41,'Basic Biology II with Lab - 004',25,4,'Winter 2019','TBA',900153,101102),(281,'BS5410',44,'Seminar II: Writing in the Discipline - 001',25,4,'Spring 2019','TBA',900154,101102),(282,'BS5410',48,'Seminar II: Writing in the Discipline - 002',25,4,'Summer 2019','TBA',900154,101102),(283,'BS5410',47,'Seminar II: Writing in the Discipline - 003',25,4,'Fall 2019','TBA',900154,101102),(284,'BS5410',36,'Seminar II: Writing in the Discipline - 004',25,4,'Winter 2019','TBA',900154,101102),(285,'BS4400',41,'Cell Biology - 001',25,4,'Spring 2019','TBA',900155,101102),(286,'BS4400',41,'Cell Biology - 002',25,4,'Summer 2019','TBA',900155,101102),(287,'BS4400',30,'Cell Biology - 003',25,4,'Fall 2019','TBA',900155,101102),(288,'BS4400',35,'Cell Biology - 004',25,4,'Winter 2019','TBA',900155,101102),(289,'BS04460',20,'Genetics - 001',25,4,'Spring 2019','TBA',900156,101102),(290,'BS04460',33,'Genetics - 002',25,4,'Summer 2019','TBA',900156,101102),(291,'BS04460',16,'Genetics - 003',25,4,'Fall 2019','TBA',900156,101102),(292,'BS04460',25,'Genetics - 004',25,4,'Winter 2019','TBA',900156,101102),(293,'BS3400',55,'Vertebrate Physiology - 001',25,4,'Spring 2019','TBA',900157,101102),(294,'BS3400',36,'Vertebrate Physiology - 002',25,4,'Summer 2019','TBA',900157,101102),(295,'BS3400',25,'Vertebrate Physiology - 003',25,4,'Fall 2019','TBA',900157,101102),(296,'BS3400',57,'Vertebrate Physiology - 004',25,4,'Winter 2019','TBA',900157,101102),(297,'BS3520',51,'Comparative Anatomy - 001',25,4,'Spring 2019','TBA',900158,101102),(298,'BS3520',31,'Comparative Anatomy - 002',25,4,'Summer 2019','TBA',900158,101102),(299,'BS3520',26,'Comparative Anatomy - 003',25,4,'Fall 2019','TBA',900158,101102),(300,'BS3520',56,'Comparative Anatomy - 004',25,4,'Winter 2019','TBA',900158,101102),(301,'BS4440',58,'Evolution - 001',25,4,'Spring 2019','TBA',900159,101102),(302,'BS4440',31,'Evolution - 002',25,4,'Summer 2019','TBA',900159,101102),(303,'BS4440',36,'Evolution - 003',25,4,'Fall 2019','TBA',900159,101102),(304,'BS4440',25,'Evolution - 004',25,4,'Winter 2019','TBA',900159,101102),(305,'BS4470',40,'Ecology - 001',25,4,'Spring 2019','TBA',900160,101102),(306,'BS4470',49,'Ecology - 002',25,4,'Summer 2019','TBA',900160,101102),(307,'BS4470',16,'Ecology - 003',25,4,'Fall 2019','TBA',900160,101102),(308,'BS4470',35,'Ecology - 004',25,4,'Winter 2019','TBA',900160,101102),(309,'AS2740',24,'US Latina/o History - 001',25,4,'Spring 2019','TBA',900177,101101),(310,'AS2740',38,'US Latina/o History - 002',25,4,'Summer 2019','TBA',900177,101101),(311,'AS2740',17,'US Latina/o History - 003',25,4,'Fall 2019','TBA',900177,101101),(312,'AS2740',38,'US Latina/o History - 004',25,4,'Winter 2019','TBA',900177,101101),(313,'AS2752',31,'Media Studies - 001',25,4,'Spring 2019','TBA',900178,101101),(314,'AS2752',50,'Media Studies - 002',25,4,'Summer 2019','TBA',900178,101101),(315,'AS2752',30,'Media Studies - 003',25,4,'Fall 2019','TBA',900178,101101),(316,'AS2752',45,'Media Studies - 004',25,4,'Winter 2019','TBA',900178,101101),(317,'AS2802',47,'Introduction to Journalism and Media - 001',25,4,'Spring 2019','TBA',900179,101101),(318,'AS2802',47,'Introduction to Journalism and Media - 002',25,4,'Summer 2019','TBA',900179,101101),(319,'AS2802',53,'Introduction to Journalism and Media - 003',25,4,'Fall 2019','TBA',900179,101101),(320,'AS2802',40,'Introduction to Journalism and Media - 004',25,4,'Winter 2019','TBA',900179,101101),(321,'AS3222',50,'Urban History - 001',25,4,'Spring 2019','TBA',900180,101101),(322,'AS3222',28,'Urban History - 002',25,4,'Summer 2019','TBA',900180,101101),(323,'AS3222',27,'Urban History - 003',25,4,'Fall 2019','TBA',900180,101101),(324,'AS3222',39,'Urban History - 004',25,4,'Winter 2019','TBA',900180,101101),(325,'AS3252',47,'U.S. Social Movements - 001',25,4,'Spring 2019','TBA',900181,101101),(326,'AS3252',44,'U.S. Social Movements - 002',25,4,'Summer 2019','TBA',900181,101101),(327,'AS3252',38,'U.S. Social Movements - 003',25,4,'Fall 2019','TBA',900181,101101),(328,'AS3252',57,'U.S. Social Movements - 004',25,4,'Winter 2019','TBA',900181,101101),(329,'AS3270',45,'Africa in the Americas - 001',25,4,'Spring 2019','TBA',900182,101101),(330,'AS3270',51,'Africa in the Americas - 002',25,4,'Summer 2019','TBA',900182,101101),(331,'AS3270',49,'Africa in the Americas - 003',25,4,'Fall 2019','TBA',900182,101101),(332,'AS3270',34,'Africa in the Americas - 004',25,4,'Winter 2019','TBA',900182,101101),(333,'AS3432',37,'Women: Cultural Issues - 001',25,4,'Spring 2019','TBA',900183,101101),(334,'AS3432',44,'Women: Cultural Issues - 002',25,4,'Summer 2019','TBA',900183,101101),(335,'AS3432',33,'Women: Cultural Issues - 003',25,4,'Fall 2019','TBA',900183,101101),(336,'AS3432',13,'Women: Cultural Issues - 004',25,4,'Winter 2019','TBA',900183,101101),(337,'AS3462',59,'History of Women in the U.S - 001',25,4,'Spring 2019','TBA',900184,101101),(338,'AS3462',47,'History of Women in the U.S - 002',25,4,'Summer 2019','TBA',900184,101101),(339,'AS3462',43,'History of Women in the U.S - 003',25,4,'Fall 2019','TBA',900184,101101),(340,'AS3462',19,'History of Women in the U.S - 004',25,4,'Winter 2019','TBA',900184,101101),(341,'AS3632',42,'History of U.S. Film - 001',25,4,'Spring 2019','TBA',900185,101101),(342,'AS3632',53,'History of U.S. Film - 002',25,4,'Summer 2019','TBA',900185,101101),(343,'AS3632',40,'History of U.S. Film - 003',25,4,'Fall 2019','TBA',900185,101101),(344,'AS3632',40,'History of U.S. Film - 004',25,4,'Winter 2019','TBA',900185,101101),(345,'AS3712',30,'American Film Genres - 001',25,4,'Spring 2019','TBA',900186,101101),(346,'AS3712',43,'American Film Genres - 002',25,4,'Summer 2019','TBA',900186,101101),(347,'AS3712',14,'American Film Genres - 003',25,4,'Fall 2019','TBA',900186,101101),(348,'AS3712',48,'American Film Genres - 004',25,4,'Winter 2019','TBA',900186,101101),(349,'AS3722',56,'History of Mass Media - 001',25,4,'Spring 2019','TBA',900187,101101),(350,'AS3722',38,'History of Mass Media - 002',25,4,'Summer 2019','TBA',900187,101101),(351,'AS3722',31,'History of Mass Media - 003',25,4,'Fall 2019','TBA',900187,101101),(352,'AS3722',58,'History of Mass Media - 004',25,4,'Winter 2019','TBA',900187,101101),(353,'AS30732',33,'Politics of Media - 001',25,4,'Spring 2019','TBA',900188,101101),(354,'AS30732',55,'Politics of Media - 002',25,4,'Summer 2019','TBA',900188,101101),(355,'AS30732',41,'Politics of Media - 003',25,4,'Fall 2019','TBA',900188,101101),(356,'AS30732',24,'Politics of Media - 004',25,4,'Winter 2019','TBA',900188,101101),(357,'AS30735',16,'Documentary Media Studies - 001',25,4,'Spring 2019','TBA',900189,101101),(358,'AS30735',43,'Documentary Media Studies - 002',25,4,'Summer 2019','TBA',900189,101101),(359,'AS30735',55,'Documentary Media Studies - 003',25,4,'Fall 2019','TBA',900189,101101),(360,'AS30735',14,'Documentary Media Studies - 004',25,4,'Winter 2019','TBA',900189,101101),(361,'AS30742',39,'Myths and Images in Film - 001',25,4,'Spring 2019','TBA',900190,101101),(362,'AS30742',57,'Myths and Images in Film - 002',25,4,'Summer 2019','TBA',900190,101101),(363,'AS30742',32,'Myths and Images in Film - 003',25,4,'Fall 2019','TBA',900190,101101),(364,'AS30742',19,'Myths and Images in Film - 004',25,4,'Winter 2019','TBA',900190,101101),(365,'AS3745',54,'Film and Gender - 001',25,4,'Spring 2019','TBA',900191,101101),(366,'AS3745',58,'Film and Gender - 002',25,4,'Summer 2019','TBA',900191,101101),(367,'AS3745',46,'Film and Gender - 003',25,4,'Fall 2019','TBA',900191,101101),(368,'AS3745',44,'Film and Gender - 004',25,4,'Winter 2019','TBA',900191,101101),(369,'AS3830',29,'Public Relations and Society - 001',25,4,'Spring 2019','TBA',900192,101101),(370,'AS3830',57,'Public Relations and Society - 002',25,4,'Summer 2019','TBA',900192,101101),(371,'AS3830',29,'Public Relations and Society - 003',25,4,'Fall 2019','TBA',900192,101101),(372,'AS3830',56,'Public Relations and Society - 004',25,4,'Winter 2019','TBA',900192,101101),(373,'AS4160',28,'Special Topics in Media Studies - 001',25,4,'Spring 2019','TBA',900193,101101),(374,'AS4160',25,'Special Topics in Media Studies - 002',25,4,'Summer 2019','TBA',900193,101101),(375,'AS4160',47,'Special Topics in Media Studies - 003',25,4,'Fall 2019','TBA',900193,101101),(376,'AS4160',32,'Special Topics in Media Studies - 004',25,4,'Winter 2019','TBA',900193,101101),(377,'AS4212',42,'Early America - 001',25,4,'Spring 2019','TBA',900194,101101),(378,'AS4212',42,'Early America - 002',25,4,'Summer 2019','TBA',900194,101101),(379,'AS4212',47,'Early America - 003',25,4,'Fall 2019','TBA',900194,101101),(380,'AS4212',42,'Early America - 004',25,4,'Winter 2019','TBA',900194,101101),(381,'AS421',54,'Critical Ideas in American History - 001',25,4,'Spring 2019','TBA',900195,101101),(382,'AS421',14,'Critical Ideas in American History - 002',25,4,'Summer 2019','TBA',900195,101101),(383,'AS421',32,'Critical Ideas in American History - 003',25,4,'Fall 2019','TBA',900195,101101),(384,'AS421',32,'Critical Ideas in American History - 004',25,4,'Winter 2019','TBA',900195,101101),(385,'AS4218',54,'Civil War and Reconstruction - 001',25,4,'Spring 2019','TBA',900196,101101),(386,'AS4218',42,'Civil War and Reconstruction - 002',25,4,'Summer 2019','TBA',900196,101101),(387,'AS4218',43,'Civil War and Reconstruction - 003',25,4,'Fall 2019','TBA',900196,101101),(388,'AS4218',11,'Civil War and Reconstruction - 004',25,4,'Winter 2019','TBA',900196,101101),(389,'AS4222',21,'The Emergence of Modern America - 001',25,4,'Spring 2019','TBA',900197,101101),(390,'AS4222',40,'The Emergence of Modern America - 002',25,4,'Summer 2019','TBA',900197,101101),(391,'AS4222',14,'The Emergence of Modern America - 003',25,4,'Fall 2019','TBA',900197,101101),(392,'AS4222',26,'The Emergence of Modern America - 004',25,4,'Winter 2019','TBA',900197,101101),(393,'AS4222',32,'Special Topics in Media Studies - 001',25,4,'Spring 2019','TBA',900198,101101),(394,'AS4222',17,'Special Topics in Media Studies - 002',25,4,'Summer 2019','TBA',900198,101101),(395,'AS4222',43,'Special Topics in Media Studies - 003',25,4,'Fall 2019','TBA',900198,101101),(396,'AS4222',21,'Special Topics in Media Studies - 004',25,4,'Winter 2019','TBA',900198,101101),(397,'AS4223',41,'The Emergence of Modern America - 001',25,4,'Spring 2019','TBA',900199,101101),(398,'AS4223',16,'The Emergence of Modern America - 002',25,4,'Summer 2019','TBA',900199,101101),(399,'AS4223',41,'The Emergence of Modern America - 003',25,4,'Fall 2019','TBA',900199,101101),(400,'AS4223',47,'The Emergence of Modern America - 004',25,4,'Winter 2019','TBA',900199,101101),(401,'AS4250',36,'Immigration Today - 001',25,4,'Spring 2019','TBA',900200,101101),(402,'AS4250',21,'Immigration Today - 002',25,4,'Summer 2019','TBA',900200,101101),(403,'AS4250',54,'Immigration Today - 003',25,4,'Fall 2019','TBA',900200,101101),(404,'AS4250',45,'Immigration Today - 004',25,4,'Winter 2019','TBA',900200,101101),(405,'AS4253',33,'Latino New York - 001',25,4,'Spring 2019','TBA',900201,101101),(406,'AS4253',39,'Latino New York - 002',25,4,'Summer 2019','TBA',900201,101101),(407,'AS4253',25,'Latino New York - 003',25,4,'Fall 2019','TBA',900201,101101),(408,'AS4253',58,'Latino New York - 004',25,4,'Winter 2019','TBA',900201,101101),(409,'AS4280',31,'Global Media - 001',25,4,'Spring 2019','TBA',900202,101101),(410,'AS4280',41,'Global Media - 002',25,4,'Summer 2019','TBA',900202,101101),(411,'AS4280',20,'Global Media - 003',25,4,'Fall 2019','TBA',900202,101101),(412,'AS4280',27,'Global Media - 004',25,4,'Winter 2019','TBA',900202,101101),(413,'AS4282',30,'America in War and Peace: 1898 to 2001 - 001',25,4,'Spring 2019','TBA',900203,101101),(414,'AS4282',41,'America in War and Peace: 1898 to 2001 - 002',25,4,'Summer 2019','TBA',900203,101101),(415,'AS4282',47,'America in War and Peace: 1898 to 2001 - 003',25,4,'Fall 2019','TBA',900203,101101),(416,'AS4282',48,'America in War and Peace: 1898 to 2001 - 004',25,4,'Winter 2019','TBA',900203,101101),(417,'AS4283',40,'America Between the World Wars - 001',25,4,'Spring 2019','TBA',900204,101101),(418,'AS4283',36,'America Between the World Wars - 002',25,4,'Summer 2019','TBA',900204,101101),(419,'AS4283',52,'America Between the World Wars - 003',25,4,'Fall 2019','TBA',900204,101101),(420,'AS4283',53,'America Between the World Wars - 004',25,4,'Winter 2019','TBA',900204,101101),(421,'AS4285',47,'Vietnam and After - 001',25,4,'Spring 2019','TBA',900205,101101),(422,'AS4285',20,'Vietnam and After - 002',25,4,'Summer 2019','TBA',900205,101101),(423,'AS4285',41,'Vietnam and After - 003',25,4,'Fall 2019','TBA',900205,101101),(424,'AS4285',51,'Vietnam and After - 004',25,4,'Winter 2019','TBA',900205,101101),(425,'AS4288',51,'Contemporary U.S. Foreign Policy - 001',25,4,'Spring 2019','TBA',900206,101101),(426,'AS4288',33,'Contemporary U.S. Foreign Policy - 002',25,4,'Summer 2019','TBA',900206,101101),(427,'AS4288',25,'Contemporary U.S. Foreign Policy - 003',25,4,'Fall 2019','TBA',900206,101101),(428,'AS4288',46,'Contemporary U.S. Foreign Policy - 004',25,4,'Winter 2019','TBA',900206,101101),(429,'AS4292',22,'America Since WWII: 1945-1989 - 001',25,4,'Spring 2019','TBA',900207,101101),(430,'AS4292',15,'America Since WWII: 1945-1989 - 002',25,4,'Summer 2019','TBA',900207,101101),(431,'AS4292',50,'America Since WWII: 1945-1989 - 003',25,4,'Fall 2019','TBA',900207,101101),(432,'AS4292',37,'America Since WWII: 1945-1989 - 004',25,4,'Winter 2019','TBA',900207,101101),(433,'AS4402',48,'History of the Family in the U.S. - 001',25,4,'Spring 2019','TBA',900208,101101),(434,'AS4402',50,'History of the Family in the U.S. - 002',25,4,'Summer 2019','TBA',900208,101101),(435,'AS4402',24,'History of the Family in the U.S. - 003',25,4,'Fall 2019','TBA',900208,101101),(436,'AS4402',26,'History of the Family in the U.S. - 004',25,4,'Winter 2019','TBA',900208,101101),(437,'AS4420',59,'History of New York City and State - 001',25,4,'Spring 2019','TBA',900209,101101),(438,'AS4420',11,'History of New York City and State - 002',25,4,'Summer 2019','TBA',900209,101101),(439,'AS4420',42,'History of New York City and State - 003',25,4,'Fall 2019','TBA',900209,101101),(440,'AS4420',18,'History of New York City and State - 004',25,4,'Winter 2019','TBA',900209,101101),(441,'AS4432',24,'History of the Women’s Movement - 001',25,4,'Spring 2019','TBA',900210,101101),(442,'AS4432',19,'History of the Women’s Movement - 002',25,4,'Summer 2019','TBA',900210,101101),(443,'AS4432',28,'History of the Women’s Movement - 003',25,4,'Fall 2019','TBA',900210,101101),(444,'AS4432',59,'History of the Women’s Movement - 004',25,4,'Winter 2019','TBA',900210,101101),(445,'AS4435',13,'Woman of Color Feminisms - 001',25,4,'Spring 2019','TBA',900211,101101),(446,'AS4435',48,'Woman of Color Feminisms - 002',25,4,'Summer 2019','TBA',900211,101101),(447,'AS4435',37,'Woman of Color Feminisms - 003',25,4,'Fall 2019','TBA',900211,101101),(448,'AS4435',30,'Woman of Color Feminisms - 004',25,4,'Winter 2019','TBA',900211,101101),(449,'AS4715',54,'African-American Thought and Culture - 001',25,4,'Spring 2019','TBA',900212,101101),(450,'AS4715',22,'African-American Thought and Culture - 002',25,4,'Summer 2019','TBA',900212,101101),(451,'AS4715',25,'African-American Thought and Culture - 003',25,4,'Fall 2019','TBA',900212,101101),(452,'AS4715',40,'African-American Thought and Culture - 004',25,4,'Winter 2019','TBA',900212,101101),(453,'AS4722',51,'Film: Ideas and Aesthetics - 001',25,4,'Spring 2019','TBA',900213,101101),(454,'AS4722',14,'Film: Ideas and Aesthetics - 002',25,4,'Summer 2019','TBA',900213,101101),(455,'AS4722',32,'Film: Ideas and Aesthetics - 003',25,4,'Fall 2019','TBA',900213,101101),(456,'AS4722',49,'Film: Ideas and Aesthetics - 004',25,4,'Winter 2019','TBA',900213,101101),(457,'AS4725',48,'The Photograph and American Culture - 001',25,4,'Spring 2019','TBA',900214,101101),(458,'AS4725',29,'The Photograph and American Culture - 002',25,4,'Summer 2019','TBA',900214,101101),(459,'AS4725',47,'The Photograph and American Culture - 003',25,4,'Fall 2019','TBA',900214,101101),(460,'AS4725',18,'The Photograph and American Culture - 004',25,4,'Winter 2019','TBA',900214,101101),(461,'AS4732',59,'Political Film - 001',25,4,'Spring 2019','TBA',900215,101101),(462,'AS4732',53,'Political Film - 002',25,4,'Summer 2019','TBA',900215,101101),(463,'AS4732',35,'Political Film - 003',25,4,'Fall 2019','TBA',900215,101101),(464,'AS4732',19,'Political Film - 004',25,4,'Winter 2019','TBA',900215,101101),(465,'AS4850',59,'Digital Revolution - 001',25,4,'Spring 2019','TBA',900216,101101),(466,'AS4850',45,'Digital Revolution - 002',25,4,'Summer 2019','TBA',900216,101101),(467,'AS4850',18,'Digital Revolution - 003',25,4,'Fall 2019','TBA',900216,101101),(468,'AS4850',27,'Digital Revolution - 004',25,4,'Winter 2019','TBA',900216,101101),(469,'AS9990',39,'Independent Study - 001',25,4,'Spring 2019','TBA',900217,101101),(470,'AS9990',37,'Independent Study - 002',25,4,'Summer 2019','TBA',900217,101101),(471,'AS9990',21,'Independent Study - 003',25,4,'Fall 2019','TBA',900217,101101),(472,'AS9990',34,'Independent Study - 004',25,4,'Winter 2019','TBA',900217,101101),(473,'BS2400',49,'Basic Biology I with Lab - 001',25,4,'Spring 2019','TBA',900218,101102),(474,'BS2400',30,'Basic Biology I with Lab - 002',25,4,'Summer 2019','TBA',900218,101102),(475,'BS2400',37,'Basic Biology I with Lab - 003',25,4,'Fall 2019','TBA',900218,101102),(476,'BS2400',14,'Basic Biology I with Lab - 004',25,4,'Winter 2019','TBA',900218,101102),(477,'BS5410',20,'Seminar I: Reading in the Discipline - 001',25,4,'Spring 2019','TBA',900219,101102),(478,'BS5410',26,'Seminar I: Reading in the Discipline - 002',25,4,'Summer 2019','TBA',900219,101102),(479,'BS5410',37,'Seminar I: Reading in the Discipline - 003',25,4,'Fall 2019','TBA',900219,101102),(480,'BS5410',44,'Seminar I: Reading in the Discipline - 004',25,4,'Winter 2019','TBA',900219,101102),(481,'BS5420',23,'Basic Biology II with Lab - 001',25,4,'Spring 2019','TBA',900220,101102),(482,'BS5420',27,'Basic Biology II with Lab - 002',25,4,'Summer 2019','TBA',900220,101102),(483,'BS5420',17,'Basic Biology II with Lab - 003',25,4,'Fall 2019','TBA',900220,101102),(484,'BS5420',40,'Basic Biology II with Lab - 004',25,4,'Winter 2019','TBA',900220,101102),(485,'BS5410',16,'Seminar II: Writing in the Discipline - 001',25,4,'Spring 2019','TBA',900221,101102),(486,'BS5410',17,'Seminar II: Writing in the Discipline - 002',25,4,'Summer 2019','TBA',900221,101102),(487,'BS5410',13,'Seminar II: Writing in the Discipline - 003',25,4,'Fall 2019','TBA',900221,101102),(488,'BS5410',17,'Seminar II: Writing in the Discipline - 004',25,4,'Winter 2019','TBA',900221,101102),(489,'BS4400',17,'Cell Biology - 001',25,4,'Spring 2019','TBA',900222,101102),(490,'BS4400',29,'Cell Biology - 002',25,4,'Summer 2019','TBA',900222,101102),(491,'BS4400',57,'Cell Biology - 003',25,4,'Fall 2019','TBA',900222,101102),(492,'BS4400',52,'Cell Biology - 004',25,4,'Winter 2019','TBA',900222,101102),(493,'BS4460',50,'Genetics - 001',25,4,'Spring 2019','TBA',900223,101102),(494,'BS4460',25,'Genetics - 002',25,4,'Summer 2019','TBA',900223,101102),(495,'BS4460',20,'Genetics - 003',25,4,'Fall 2019','TBA',900223,101102),(496,'BS4460',40,'Genetics - 004',25,4,'Winter 2019','TBA',900223,101102),(497,'BS3400',16,'Vertebrate Physiology - 001',25,4,'Spring 2019','TBA',900224,101102),(498,'BS3400',23,'Vertebrate Physiology - 002',25,4,'Summer 2019','TBA',900224,101102),(499,'BS3400',39,'Vertebrate Physiology - 003',25,4,'Fall 2019','TBA',900224,101102),(500,'BS3400',46,'Vertebrate Physiology - 004',25,4,'Winter 2019','TBA',900224,101102),(501,'BS3520',42,'Comparative Anatomy - 001',25,4,'Spring 2019','TBA',900225,101102),(502,'BS3520',40,'Comparative Anatomy - 002',25,4,'Summer 2019','TBA',900225,101102),(503,'BS3520',19,'Comparative Anatomy - 003',25,4,'Fall 2019','TBA',900225,101102),(504,'BS3520',55,'Comparative Anatomy - 004',25,4,'Winter 2019','TBA',900225,101102),(505,'BS4440',37,'Evolution - 001',25,4,'Spring 2019','TBA',900226,101102),(506,'BS4440',58,'Evolution - 002',25,4,'Summer 2019','TBA',900226,101102),(507,'BS4440',50,'Evolution - 003',25,4,'Fall 2019','TBA',900226,101102),(508,'BS4440',13,'Evolution - 004',25,4,'Winter 2019','TBA',900226,101102),(509,'BS4470',35,'Ecology - 001',25,4,'Spring 2019','TBA',900227,101102),(510,'BS4470',44,'Ecology - 002',25,4,'Summer 2019','TBA',900227,101102),(511,'BS4470',59,'Ecology - 003',25,4,'Fall 2019','TBA',900227,101102),(512,'BS4470',22,'Ecology - 004',25,4,'Winter 2019','TBA',900227,101102),(513,'BS2490',40,'Environmental Science - 001',25,4,'Spring 2019','TBA',900228,101102),(514,'BS2490',54,'Environmental Science - 002',25,4,'Summer 2019','TBA',900228,101102),(515,'BS2490',38,'Environmental Science - 003',25,4,'Fall 2019','TBA',900228,101102),(516,'BS2490',29,'Environmental Science - 004',25,4,'Winter 2019','TBA',900228,101102),(517,'BS3400',49,'Vertebrate Physiology - 001',25,4,'Spring 2019','TBA',900229,101102),(518,'BS3400',58,'Vertebrate Physiology - 002',25,4,'Summer 2019','TBA',900229,101102),(519,'BS3400',58,'Vertebrate Physiology - 003',25,4,'Fall 2019','TBA',900229,101102),(520,'BS3400',15,'Vertebrate Physiology - 004',25,4,'Winter 2019','TBA',900229,101102),(521,'BS3450',31,'Plant Biology - 001',25,4,'Spring 2019','TBA',900230,101102),(522,'BS3450',34,'Plant Biology - 002',25,4,'Summer 2019','TBA',900230,101102),(523,'BS3450',38,'Plant Biology - 003',25,4,'Fall 2019','TBA',900230,101102),(524,'BS3450',36,'Plant Biology - 004',25,4,'Winter 2019','TBA',900230,101102),(525,'BS3510',24,'Parasitology - 001',25,4,'Spring 2019','TBA',900231,101102),(526,'BS3510',26,'Parasitology - 002',25,4,'Summer 2019','TBA',900231,101102),(527,'BS3510',26,'Parasitology - 003',25,4,'Fall 2019','TBA',900231,101102),(528,'BS3510',21,'Parasitology - 004',25,4,'Winter 2019','TBA',900231,101102),(529,'BS3520',16,'Comparative Anatomy - 001',25,4,'Spring 2019','TBA',900232,101102),(530,'BS3520',56,'Comparative Anatomy - 002',25,4,'Summer 2019','TBA',900232,101102),(531,'BS3520',21,'Comparative Anatomy - 003',25,4,'Fall 2019','TBA',900232,101102),(532,'BS3520',18,'Comparative Anatomy - 004',25,4,'Winter 2019','TBA',900232,101102),(533,'BS3530',57,'Comparative Genomics - 001',25,4,'Spring 2019','TBA',900233,101102),(534,'BS3530',57,'Comparative Genomics - 002',25,4,'Summer 2019','TBA',900233,101102),(535,'BS3530',13,'Comparative Genomics - 003',25,4,'Fall 2019','TBA',900233,101102),(536,'BS3530',19,'Comparative Genomics - 004',25,4,'Winter 2019','TBA',900233,101102),(537,'BS3531',11,'Comparative Genomics Lab - 001',25,4,'Spring 2019','TBA',900234,101102),(538,'BS3531',48,'Comparative Genomics Lab - 002',25,4,'Summer 2019','TBA',900234,101102),(539,'BS3531',59,'Comparative Genomics Lab - 003',25,4,'Fall 2019','TBA',900234,101102),(540,'BS3531',40,'Comparative Genomics Lab - 004',25,4,'Winter 2019','TBA',900234,101102),(541,'BS3710',57,'Environmental Physiology - 001',25,4,'Spring 2019','TBA',900235,101102),(542,'BS3710',30,'Environmental Physiology - 002',25,4,'Summer 2019','TBA',900235,101102),(543,'BS3710',39,'Environmental Physiology - 003',25,4,'Fall 2019','TBA',900235,101102),(544,'BS3710',22,'Environmental Physiology - 004',25,4,'Winter 2019','TBA',900235,101102),(545,'BS3810',11,'Biological Aspects of Aging - 001',25,4,'Spring 2019','TBA',900236,101102),(546,'BS3810',15,'Biological Aspects of Aging - 002',25,4,'Summer 2019','TBA',900236,101102),(547,'BS3810',33,'Biological Aspects of Aging - 003',25,4,'Fall 2019','TBA',900236,101102),(548,'BS3810',32,'Biological Aspects of Aging - 004',25,4,'Winter 2019','TBA',900236,101102),(549,'BS3910',25,'Introduction to Bioinformatics - 001',25,4,'Spring 2019','TBA',900237,101102),(550,'BS3910',29,'Introduction to Bioinformatics - 002',25,4,'Summer 2019','TBA',900237,101102),(551,'BS3910',46,'Introduction to Bioinformatics - 003',25,4,'Fall 2019','TBA',900237,101102),(552,'BS3910',42,'Introduction to Bioinformatics - 004',25,4,'Winter 2019','TBA',900237,101102),(553,'BS4400',42,'Cell Biology - 001',25,4,'Spring 2019','TBA',900238,101102),(554,'BS4400',59,'Cell Biology - 002',25,4,'Summer 2019','TBA',900238,101102),(555,'BS4400',48,'Cell Biology - 003',25,4,'Fall 2019','TBA',900238,101102),(556,'BS4400',32,'Cell Biology - 004',25,4,'Winter 2019','TBA',900238,101102),(557,'BS4410',48,'Histology - 001',25,4,'Spring 2019','TBA',900239,101102),(558,'BS4410',53,'Histology - 002',25,4,'Summer 2019','TBA',900239,101102),(559,'BS4410',24,'Histology - 003',25,4,'Fall 2019','TBA',900239,101102),(560,'BS4410',23,'Histology - 004',25,4,'Winter 2019','TBA',900239,101102),(561,'BS4420',30,'Microbiology - 001',25,4,'Spring 2019','TBA',900240,101102),(562,'BS4420',46,'Microbiology - 002',25,4,'Summer 2019','TBA',900240,101102),(563,'BS4420',45,'Microbiology - 003',25,4,'Fall 2019','TBA',900240,101102),(564,'BS4420',52,'Microbiology - 004',25,4,'Winter 2019','TBA',900240,101102),(565,'BS4430',45,'Developmental Biography - 001',25,4,'Spring 2019','TBA',900241,101102),(566,'BS4430',31,'Developmental Biography - 002',25,4,'Summer 2019','TBA',900241,101102),(567,'BS4430',43,'Developmental Biography - 003',25,4,'Fall 2019','TBA',900241,101102),(568,'BS4430',35,'Developmental Biography - 004',25,4,'Winter 2019','TBA',900241,101102),(569,'BS4440',23,'Evolution - 001',25,4,'Spring 2019','TBA',900242,101102),(570,'BS4440',19,'Evolution - 002',25,4,'Summer 2019','TBA',900242,101102),(571,'BS4440',35,'Evolution - 003',25,4,'Fall 2019','TBA',900242,101102),(572,'BS4440',52,'Evolution - 004',25,4,'Winter 2019','TBA',900242,101102),(573,'BS4471',54,'Freshwater Ecology - 001',25,4,'Spring 2019','TBA',900243,101102),(574,'BS4471',33,'Freshwater Ecology - 002',25,4,'Summer 2019','TBA',900243,101102),(575,'BS4471',31,'Freshwater Ecology - 003',25,4,'Fall 2019','TBA',900243,101102),(576,'BS4471',30,'Freshwater Ecology - 004',25,4,'Winter 2019','TBA',900243,101102),(577,'BS4474',55,'Microbial Ecology - 001',25,4,'Spring 2019','TBA',900244,101102),(578,'BS4474',45,'Microbial Ecology - 002',25,4,'Summer 2019','TBA',900244,101102),(579,'BS4474',16,'Microbial Ecology - 003',25,4,'Fall 2019','TBA',900244,101102),(580,'BS4474',26,'Microbial Ecology - 004',25,4,'Winter 2019','TBA',900244,101102),(581,'BS4480',13,'Animal Behavior - 001',25,4,'Spring 2019','TBA',900245,101102),(582,'BS4480',37,'Animal Behavior - 002',25,4,'Summer 2019','TBA',900245,101102),(583,'BS4480',30,'Animal Behavior - 003',25,4,'Fall 2019','TBA',900245,101102),(584,'BS4480',29,'Animal Behavior - 004',25,4,'Winter 2019','TBA',900245,101102),(585,'BS4491',18,'Human Ecology - 001',25,4,'Spring 2019','TBA',900246,101102),(586,'BS4491',24,'Human Ecology - 002',25,4,'Summer 2019','TBA',900246,101102),(587,'BS4491',36,'Human Ecology - 003',25,4,'Fall 2019','TBA',900246,101102),(588,'BS4491',37,'Human Ecology - 004',25,4,'Winter 2019','TBA',900246,101102),(589,'BS4500',23,'Cell and Molecular Neurobiology - 001',25,4,'Spring 2019','TBA',900247,101102),(590,'BS4500',42,'Cell and Molecular Neurobiology - 002',25,4,'Summer 2019','TBA',900247,101102),(591,'BS4500',18,'Cell and Molecular Neurobiology - 003',25,4,'Fall 2019','TBA',900247,101102),(592,'BS4500',17,'Cell and Molecular Neurobiology - 004',25,4,'Winter 2019','TBA',900247,101102),(593,'BS4550',55,'Cancer Cell Biology - 001',25,4,'Spring 2019','TBA',900248,101102),(594,'BS4550',42,'Cancer Cell Biology - 002',25,4,'Summer 2019','TBA',900248,101102),(595,'BS4550',26,'Cancer Cell Biology - 003',25,4,'Fall 2019','TBA',900248,101102),(596,'BS4550',53,'Cancer Cell Biology - 004',25,4,'Winter 2019','TBA',900248,101102),(597,'BS4560',44,'Molecular Biology - 001',25,4,'Spring 2019','TBA',900249,101102),(598,'BS4560',21,'Molecular Biology - 002',25,4,'Summer 2019','TBA',900249,101102),(599,'BS4560',46,'Molecular Biology - 003',25,4,'Fall 2019','TBA',900249,101102),(600,'BS4560',40,'Molecular Biology - 004',25,4,'Winter 2019','TBA',900249,101102),(601,'BS4651',21,'Toxicology - 001',25,4,'Spring 2019','TBA',900250,101102),(602,'BS4651',48,'Toxicology - 002',25,4,'Summer 2019','TBA',900250,101102),(603,'BS4651',28,'Toxicology - 003',25,4,'Fall 2019','TBA',900250,101102),(604,'BS4651',14,'Toxicology - 004',25,4,'Winter 2019','TBA',900250,101102),(605,'BS4680',15,'Environmental Health - 001',25,4,'Spring 2019','TBA',900251,101102),(606,'BS4680',31,'Environmental Health - 002',25,4,'Summer 2019','TBA',900251,101102),(607,'BS4680',46,'Environmental Health - 003',25,4,'Fall 2019','TBA',900251,101102),(608,'BS4680',54,'Environmental Health - 004',25,4,'Winter 2019','TBA',900251,101102),(609,'BS5590',36,'Advanced Research - 001',25,4,'Spring 2019','TBA',900252,101102),(610,'BS5590',17,'Advanced Research - 002',25,4,'Summer 2019','TBA',900252,101102),(611,'BS5590',17,'Advanced Research - 003',25,4,'Fall 2019','TBA',900252,101102),(612,'BS5590',19,'Advanced Research - 004',25,4,'Winter 2019','TBA',900252,101102),(613,'BS5591',57,'Environmental Research - 001',25,4,'Spring 2019','TBA',900253,101102),(614,'BS5591',25,'Environmental Research - 002',25,4,'Summer 2019','TBA',900253,101102),(615,'BS5591',22,'Environmental Research - 003',25,4,'Fall 2019','TBA',900253,101102),(616,'BS5591',31,'Environmental Research - 004',25,4,'Winter 2019','TBA',900253,101102),(617,'BS4510',54,'Biochemistry - 001',25,4,'Spring 2019','TBA',900254,101102),(618,'BS4510',45,'Biochemistry - 002',25,4,'Summer 2019','TBA',900254,101102),(619,'BS4510',13,'Biochemistry - 003',25,4,'Fall 2019','TBA',900254,101102),(620,'BS4510',48,'Biochemistry - 004',25,4,'Winter 2019','TBA',900254,101102),(621,'SY4520',18,'Research Methods I - 001',25,4,'Spring 2019','TBA',900255,10117),(622,'SY4520',56,'Research Methods I - 002',25,4,'Summer 2019','TBA',900255,10117),(623,'SY4520',19,'Research Methods I - 003',25,4,'Fall 2019','TBA',900255,10117),(624,'SY4520',32,'Research Methods I - 004',25,4,'Winter 2019','TBA',900255,10117),(625,'SY4530',43,'Sociological Theory I - 001',25,4,'Spring 2019','TBA',900256,10117),(626,'SY4530',30,'Sociological Theory I - 002',25,4,'Summer 2019','TBA',900256,10117),(627,'SY4530',37,'Sociological Theory I - 003',25,4,'Fall 2019','TBA',900256,10117),(628,'SY4530',41,'Sociological Theory I - 004',25,4,'Winter 2019','TBA',900256,10117),(629,'SY4540',46,'Sociological Theory II - 001',25,4,'Spring 2019','TBA',900257,10117),(630,'SY4540',38,'Sociological Theory II - 002',25,4,'Summer 2019','TBA',900257,10117),(631,'SY4540',56,'Sociological Theory II - 003',25,4,'Fall 2019','TBA',900257,10117),(632,'SY4540',54,'Sociological Theory II - 004',25,4,'Winter 2019','TBA',900257,10117),(633,'SY4570',56,'Research Methods II - 001',25,4,'Spring 2019','TBA',900258,10117),(634,'SY4570',52,'Research Methods II - 002',25,4,'Summer 2019','TBA',900258,10117),(635,'SY4570',40,'Research Methods II - 003',25,4,'Fall 2019','TBA',900258,10117),(636,'SY4570',48,'Research Methods II - 004',25,4,'Winter 2019','TBA',900258,10117),(637,'SY3160',25,'Sociology of Culture - 001',25,4,'Spring 2019','TBA',900259,10117),(638,'SY3160',23,'Sociology of Culture - 002',25,4,'Summer 2019','TBA',900259,10117),(639,'SY3160',55,'Sociology of Culture - 003',25,4,'Fall 2019','TBA',900259,10117),(640,'SY3160',55,'Sociology of Culture - 004',25,4,'Winter 2019','TBA',900259,10117),(641,'SY3160',52,'Family and Society - 001',25,4,'Spring 2019','TBA',900260,10117),(642,'SY3160',40,'Family and Society - 002',25,4,'Summer 2019','TBA',900260,10117),(643,'SY3160',51,'Family and Society - 003',25,4,'Fall 2019','TBA',900260,10117),(644,'SY3160',57,'Family and Society - 004',25,4,'Winter 2019','TBA',900260,10117),(645,'SY4500',29,'Global Sociology - 001',25,4,'Spring 2019','TBA',900261,10117),(646,'SY4500',35,'Global Sociology - 002',25,4,'Summer 2019','TBA',900261,10117),(647,'SY4500',48,'Global Sociology - 003',25,4,'Fall 2019','TBA',900261,10117),(648,'SY4500',25,'Global Sociology - 004',25,4,'Winter 2019','TBA',900261,10117),(649,'SY4651',42,'Sociology of Communications and Media - 001',25,4,'Spring 2019','TBA',900262,10117),(650,'SY4651',35,'Sociology of Communications and Media - 002',25,4,'Summer 2019','TBA',900262,10117),(651,'SY4651',32,'Sociology of Communications and Media - 003',25,4,'Fall 2019','TBA',900262,10117),(652,'SY4651',27,'Sociology of Communications and Media - 004',25,4,'Winter 2019','TBA',900262,10117),(653,'SY4950',56,'Sociology of Music - 001',25,4,'Spring 2019','TBA',900263,10117),(654,'SY4950',31,'Sociology of Music - 002',25,4,'Summer 2019','TBA',900263,10117),(655,'SY4950',41,'Sociology of Music - 003',25,4,'Fall 2019','TBA',900263,10117),(656,'SY4950',12,'Sociology of Music - 004',25,4,'Winter 2019','TBA',900263,10117),(657,'SY1500',18,'Introductory Sociology - 001',25,4,'Spring 2019','TBA',900264,10117),(658,'SY1500',39,'Introductory Sociology - 002',25,4,'Summer 2019','TBA',900264,10117),(659,'SY1500',54,'Introductory Sociology - 003',25,4,'Fall 2019','TBA',900264,10117),(660,'SY1500',37,'Introductory Sociology - 004',25,4,'Winter 2019','TBA',900264,10117),(661,'SY2600',39,'Social Deviance - 001',25,4,'Spring 2019','TBA',900265,10117),(662,'SY2600',30,'Social Deviance - 002',25,4,'Summer 2019','TBA',900265,10117),(663,'SY2600',58,'Social Deviance - 003',25,4,'Fall 2019','TBA',900265,10117),(664,'SY2600',48,'Social Deviance - 004',25,4,'Winter 2019','TBA',900265,10117),(665,'SY4270',25,'Internship in Social Work, Sociology and Criminology - 001',25,4,'Spring 2019','TBA',900266,10117),(666,'SY4270',51,'Internship in Social Work, Sociology and Criminology - 002',25,4,'Summer 2019','TBA',900266,10117),(667,'SY4270',37,'Internship in Social Work, Sociology and Criminology - 003',25,4,'Fall 2019','TBA',900266,10117),(668,'SY4270',48,'Internship in Social Work, Sociology and Criminology - 004',25,4,'Winter 2019','TBA',900266,10117),(669,'SY4810',59,'Law and Justice - 001',25,4,'Spring 2019','TBA',900267,10117),(670,'SY4810',40,'Law and Justice - 002',25,4,'Summer 2019','TBA',900267,10117),(671,'SY4810',40,'Law and Justice - 003',25,4,'Fall 2019','TBA',900267,10117),(672,'SY4810',32,'Law and Justice - 004',25,4,'Winter 2019','TBA',900267,10117),(673,'SY5990',32,'Senior Seminar - 001',25,4,'Spring 2019','TBA',900268,10117),(674,'SY5990',59,'Senior Seminar - 002',25,4,'Summer 2019','TBA',900268,10117),(675,'SY5990',53,'Senior Seminar - 003',25,4,'Fall 2019','TBA',900268,10117),(676,'SY5990',59,'Senior Seminar - 004',25,4,'Winter 2019','TBA',900268,10117),(677,'CR2090',42,'Juvenile Delinquency - 001',25,4,'Spring 2019','TBA',900269,101107),(678,'CR2090',23,'Juvenile Delinquency - 002',25,4,'Summer 2019','TBA',900269,101107),(679,'CR2090',50,'Juvenile Delinquency - 003',25,4,'Fall 2019','TBA',900269,101107),(680,'CR2090',49,'Juvenile Delinquency - 004',25,4,'Winter 2019','TBA',900269,101107),(681,'CR3092',35,'Victimology - 001',25,4,'Spring 2019','TBA',900270,101107),(682,'CR3092',44,'Victimology - 002',25,4,'Summer 2019','TBA',900270,101107),(683,'CR3092',38,'Victimology - 003',25,4,'Fall 2019','TBA',900270,101107),(684,'CR3092',12,'Victimology - 004',25,4,'Winter 2019','TBA',900270,101107),(685,'CR3093',47,'Criminal Justice Administration - 001',25,4,'Spring 2019','TBA',900271,101107),(686,'CR3093',32,'Criminal Justice Administration - 002',25,4,'Summer 2019','TBA',900271,101107),(687,'CR3093',20,'Criminal Justice Administration - 003',25,4,'Fall 2019','TBA',900271,101107),(688,'CR3093',26,'Criminal Justice Administration - 004',25,4,'Winter 2019','TBA',900271,101107),(689,'CR3094',58,'Drugs and Society - 001',25,4,'Spring 2019','TBA',900272,101107),(690,'CR3094',15,'Drugs and Society - 002',25,4,'Summer 2019','TBA',900272,101107),(691,'CR3094',34,'Drugs and Society - 003',25,4,'Fall 2019','TBA',900272,101107),(692,'CR3094',32,'Drugs and Society - 004',25,4,'Winter 2019','TBA',900272,101107),(693,'CR3117',29,'Sex, Violence and Social Control - 001',25,4,'Spring 2019','TBA',900273,101107),(694,'CR3117',23,'Sex, Violence and Social Control - 002',25,4,'Summer 2019','TBA',900273,101107),(695,'CR3117',49,'Sex, Violence and Social Control - 003',25,4,'Fall 2019','TBA',900273,101107),(696,'CR3117',17,'Sex, Violence and Social Control - 004',25,4,'Winter 2019','TBA',900273,101107),(697,'CR3200',41,'Crime, Media and Culture - 001',25,4,'Spring 2019','TBA',900274,101107),(698,'CR3200',45,'Crime, Media and Culture - 002',25,4,'Summer 2019','TBA',900274,101107),(699,'CR3200',48,'Crime, Media and Culture - 003',25,4,'Fall 2019','TBA',900274,101107),(700,'CR3200',15,'Crime, Media and Culture - 004',25,4,'Winter 2019','TBA',900274,101107),(701,'CR1500',52,'Introduction to Criminology - 001',25,4,'Spring 2019','TBA',900275,101107),(702,'CR1500',29,'Introduction to Criminology - 002',25,4,'Summer 2019','TBA',900275,101107),(703,'CR1500',54,'Introduction to Criminology - 003',25,4,'Fall 2019','TBA',900275,101107),(704,'CR1500',22,'Introduction to Criminology - 004',25,4,'Winter 2019','TBA',900275,101107),(705,'CR4000',25,'Gender, Crime and Justice - 001',25,4,'Spring 2019','TBA',900276,101107),(706,'CR4000',53,'Gender, Crime and Justice - 002',25,4,'Summer 2019','TBA',900276,101107),(707,'CR4000',54,'Gender, Crime and Justice - 003',25,4,'Fall 2019','TBA',900276,101107),(708,'CR4000',41,'Gender, Crime and Justice - 004',25,4,'Winter 2019','TBA',900276,101107),(709,'CR4091',13,'Punishment and Corrections - 001',25,4,'Spring 2019','TBA',900277,101107),(710,'CR4091',37,'Punishment and Corrections - 002',25,4,'Summer 2019','TBA',900277,101107),(711,'CR4091',49,'Punishment and Corrections - 003',25,4,'Fall 2019','TBA',900277,101107),(712,'CR4091',58,'Punishment and Corrections - 004',25,4,'Winter 2019','TBA',900277,101107),(713,'CR4099',27,'Sociology of Violence - 001',25,4,'Spring 2019','TBA',900278,101107),(714,'CR4099',49,'Sociology of Violence - 002',25,4,'Summer 2019','TBA',900278,101107),(715,'CR4099',18,'Sociology of Violence - 003',25,4,'Fall 2019','TBA',900278,101107),(716,'CR4099',32,'Sociology of Violence - 004',25,4,'Winter 2019','TBA',900278,101107),(717,'CR4999',40,'Issues in Criminology - 001',25,4,'Spring 2019','TBA',900279,101107),(718,'CR4999',34,'Issues in Criminology - 002',25,4,'Summer 2019','TBA',900279,101107),(719,'CR4999',46,'Issues in Criminology - 003',25,4,'Fall 2019','TBA',900279,101107),(720,'CR4999',51,'Issues in Criminology - 004',25,4,'Winter 2019','TBA',900279,101107),(721,'CR4550',43,'Theories of Crime - 001',25,4,'Spring 2019','TBA',900280,101107),(722,'CR4550',20,'Theories of Crime - 002',25,4,'Summer 2019','TBA',900280,101107),(723,'CR4550',26,'Theories of Crime - 003',25,4,'Fall 2019','TBA',900280,101107),(724,'CR4550',25,'Theories of Crime - 004',25,4,'Winter 2019','TBA',900280,101107),(725,'ED3742',45,'Middle Childhood & Adolescence - 001',25,4,'Spring 2019','TBA',900281,10116),(726,'ED3742',14,'Middle Childhood & Adolescence - 002',25,4,'Summer 2019','TBA',900281,10116),(727,'ED3742',23,'Middle Childhood & Adolescence - 003',25,4,'Fall 2019','TBA',900281,10116),(728,'ED3742',25,'Middle Childhood & Adolescence - 004',25,4,'Winter 2019','TBA',900281,10116),(729,'ED3820',55,'Foundations of Special Education - 001',25,4,'Spring 2019','TBA',900282,10116),(730,'ED3820',53,'Foundations of Special Education - 002',25,4,'Summer 2019','TBA',900282,10116),(731,'ED3820',41,'Foundations of Special Education - 003',25,4,'Fall 2019','TBA',900282,10116),(732,'ED3820',44,'Foundations of Special Education - 004',25,4,'Winter 2019','TBA',900282,10116),(733,'ED3950',30,'Creating Schools for a Just Society - 001',25,4,'Spring 2019','TBA',900283,10116),(734,'ED3950',32,'Creating Schools for a Just Society - 002',25,4,'Summer 2019','TBA',900283,10116),(735,'ED3950',46,'Creating Schools for a Just Society - 003',25,4,'Fall 2019','TBA',900283,10116),(736,'ED3950',30,'Creating Schools for a Just Society - 004',25,4,'Winter 2019','TBA',900283,10116),(737,'ED4085',19,'Methods and Materials of Teaching Science in Secondary School - 001',25,4,'Spring 2019','TBA',900284,10116),(738,'ED4085',39,'Methods and Materials of Teaching Science in Secondary School - 002',25,4,'Summer 2019','TBA',900284,10116),(739,'ED4085',49,'Methods and Materials of Teaching Science in Secondary School - 003',25,4,'Fall 2019','TBA',900284,10116),(740,'ED4085',21,'Methods and Materials of Teaching Science in Secondary School - 004',25,4,'Winter 2019','TBA',900284,10116),(741,'ED4230',47,'Reading Across the Curriculum - 001',25,4,'Spring 2019','TBA',900285,10116),(742,'ED4230',50,'Reading Across the Curriculum - 002',25,4,'Summer 2019','TBA',900285,10116),(743,'ED4230',27,'Reading Across the Curriculum - 003',25,4,'Fall 2019','TBA',900285,10116),(744,'ED4230',25,'Reading Across the Curriculum - 004',25,4,'Winter 2019','TBA',900285,10116),(745,'ED4231',50,'Reading Practicum - 001',25,4,'Spring 2019','TBA',900286,10116),(746,'ED4231',47,'Reading Practicum - 002',25,4,'Summer 2019','TBA',900286,10116),(747,'ED4231',26,'Reading Practicum - 003',25,4,'Fall 2019','TBA',900286,10116),(748,'ED4231',35,'Reading Practicum - 004',25,4,'Winter 2019','TBA',900286,10116),(749,'ED5890',59,'Pre-Teaching Practicum & Seminar - 001',25,4,'Spring 2019','TBA',900287,10116),(750,'ED5890',21,'Pre-Teaching Practicum & Seminar - 002',25,4,'Summer 2019','TBA',900287,10116),(751,'ED5890',29,'Pre-Teaching Practicum & Seminar - 003',25,4,'Fall 2019','TBA',900287,10116),(752,'ED5890',14,'Pre-Teaching Practicum & Seminar - 004',25,4,'Winter 2019','TBA',900287,10116),(753,'ED5900',32,'Student Teaching & Seminar in Adolescence Education (Grades 7-12) - 001',25,4,'Spring 2019','TBA',900288,10116),(754,'ED5900',27,'Student Teaching & Seminar in Adolescence Education (Grades 7-12) - 002',25,4,'Summer 2019','TBA',900288,10116),(755,'ED5900',14,'Student Teaching & Seminar in Adolescence Education (Grades 7-12) - 003',25,4,'Fall 2019','TBA',900288,10116),(756,'ED5900',12,'Student Teaching & Seminar in Adolescence Education (Grades 7-12) - 004',25,4,'Winter 2019','TBA',900288,10116),(757,'ED4230',16,'Reading Across the Curriculum - 001',25,4,'Spring 2019','TBA',900289,10116),(758,'ED4230',30,'Reading Across the Curriculum - 002',25,4,'Summer 2019','TBA',900289,10116),(759,'ED4230',58,'Reading Across the Curriculum - 003',25,4,'Fall 2019','TBA',900289,10116),(760,'ED4230',38,'Reading Across the Curriculum - 004',25,4,'Winter 2019','TBA',900289,10116),(761,'ED4231',24,'Reading Practicum - 001',25,4,'Spring 2019','TBA',900290,10116),(762,'ED4231',59,'Reading Practicum - 002',25,4,'Summer 2019','TBA',900290,10116),(763,'ED4231',32,'Reading Practicum - 003',25,4,'Fall 2019','TBA',900290,10116),(764,'ED4231',58,'Reading Practicum - 004',25,4,'Winter 2019','TBA',900290,10116),(765,'ED4050',50,'Interdisciplinary Instructional Strategies - 001',25,4,'Spring 2019','TBA',900291,10116),(766,'ED4050',37,'Interdisciplinary Instructional Strategies - 002',25,4,'Summer 2019','TBA',900291,10116),(767,'ED4050',13,'Interdisciplinary Instructional Strategies - 003',25,4,'Fall 2019','TBA',900291,10116),(768,'ED4050',21,'Interdisciplinary Instructional Strategies - 004',25,4,'Winter 2019','TBA',900291,10116),(769,'ED5890',26,'Pre-Teaching Practicum & Seminar - 001',25,4,'Spring 2019','TBA',900292,10116),(770,'ED5890',47,'Pre-Teaching Practicum & Seminar - 002',25,4,'Summer 2019','TBA',900292,10116),(771,'ED5890',48,'Pre-Teaching Practicum & Seminar - 003',25,4,'Fall 2019','TBA',900292,10116),(772,'ED5890',19,'Pre-Teaching Practicum & Seminar - 004',25,4,'Winter 2019','TBA',900292,10116),(773,'ED5910',15,'Student Teaching & Seminar in Middle Childhood Education (Grades 5-9 - 001',25,4,'Spring 2019','TBA',900293,10116),(774,'ED5910',29,'Student Teaching & Seminar in Middle Childhood Education (Grades 5-9 - 002',25,4,'Summer 2019','TBA',900293,10116),(775,'ED5910',35,'Student Teaching & Seminar in Middle Childhood Education (Grades 5-9 - 003',25,4,'Fall 2019','TBA',900293,10116),(776,'ED5910',35,'Student Teaching & Seminar in Middle Childhood Education (Grades 5-9 - 004',25,4,'Winter 2019','TBA',900293,10116),(777,'CP2050',11,'The Nature and Development of Science - 001',25,4,'Spring 2019','TBA',900294,10116),(778,'CP2050',46,'The Nature and Development of Science - 002',25,4,'Summer 2019','TBA',900294,10116),(779,'CP2050',41,'The Nature and Development of Science - 003',25,4,'Fall 2019','TBA',900294,10116),(780,'CP2050',36,'The Nature and Development of Science - 004',25,4,'Winter 2019','TBA',900294,10116),(781,'ED4085',43,'Methods and Materials of Teaching Science in Secondary School - 001',25,4,'Spring 2019','TBA',900295,10116),(782,'ED4085',40,'Methods and Materials of Teaching Science in Secondary School - 002',25,4,'Summer 2019','TBA',900295,10116),(783,'ED4085',40,'Methods and Materials of Teaching Science in Secondary School - 003',25,4,'Fall 2019','TBA',900295,10116),(784,'ED4085',54,'Methods and Materials of Teaching Science in Secondary School - 004',25,4,'Winter 2019','TBA',900295,10116),(785,'ED4050',54,'Innovative Instructional Design & Assessment - 001',25,4,'Spring 2019','TBA',900296,10116),(786,'ED4050',45,'Innovative Instructional Design & Assessment - 002',25,4,'Summer 2019','TBA',900296,10116),(787,'ED4050',32,'Innovative Instructional Design & Assessment - 003',25,4,'Fall 2019','TBA',900296,10116),(788,'ED4050',23,'Innovative Instructional Design & Assessment - 004',25,4,'Winter 2019','TBA',900296,10116),(789,'ED4082',14,'Methods and Materials of Teaching Math in Secondary School - 001',25,4,'Spring 2019','TBA',900297,10116),(790,'ED4082',50,'Methods and Materials of Teaching Math in Secondary School - 002',25,4,'Summer 2019','TBA',900297,10116),(791,'ED4082',14,'Methods and Materials of Teaching Math in Secondary School - 003',25,4,'Fall 2019','TBA',900297,10116),(792,'ED4082',12,'Methods and Materials of Teaching Math in Secondary School - 004',25,4,'Winter 2019','TBA',900297,10116),(793,'ED4086',13,'Methods and Materials of Teaching Social Studies in Secondary School - 001',25,4,'Spring 2019','TBA',900298,10116),(794,'ED4086',27,'Methods and Materials of Teaching Social Studies in Secondary School - 002',25,4,'Summer 2019','TBA',900298,10116),(795,'ED4086',25,'Methods and Materials of Teaching Social Studies in Secondary School - 003',25,4,'Fall 2019','TBA',900298,10116),(796,'ED4086',40,'Methods and Materials of Teaching Social Studies in Secondary School - 004',25,4,'Winter 2019','TBA',900298,10116),(797,'ED/ML2600',11,'Spanish & Methods of Teaching Social Studies in Secondary School - 001',25,4,'Spring 2019','TBA',900299,10116),(798,'ED/ML2600',22,'Spanish & Methods of Teaching Social Studies in Secondary School - 002',25,4,'Summer 2019','TBA',900299,10116),(799,'ED/ML2600',59,'Spanish & Methods of Teaching Social Studies in Secondary School - 003',25,4,'Fall 2019','TBA',900299,10116),(800,'ED/ML2600',56,'Spanish & Methods of Teaching Social Studies in Secondary School - 004',25,4,'Winter 2019','TBA',900299,10116),(801,'ED3700',34,'Child Development - 001',25,4,'Spring 2019','TBA',900300,10116),(802,'ED3700',38,'Child Development - 002',25,4,'Summer 2019','TBA',900300,10116),(803,'ED3700',19,'Child Development - 003',25,4,'Fall 2019','TBA',900300,10116),(804,'ED3700',46,'Child Development - 004',25,4,'Winter 2019','TBA',900300,10116),(1349,'CS1500',47,'Intro to Computer Applications - 001',25,4,'Spring 2019','TBA',900437,101104),(1350,'CS1500',59,'Intro to Computer Applications - 002',25,4,'Summer 2019','TBA',900437,101104),(1351,'CS1500',36,'Intro to Computer Applications - 003',25,4,'Fall 2019','TBA',900437,101104),(1352,'CS1500',11,'Intro to Computer Applications - 004',25,4,'Winter 2019','TBA',900437,101104),(1353,'CS2510',15,'Computer Programming I  - 001',25,4,'Spring 2019','TBA',900438,101104),(1354,'CS2510',44,'Computer Programming I  - 002',25,4,'Summer 2019','TBA',900438,101104),(1355,'CS2510',14,'Computer Programming I  - 003',25,4,'Fall 2019','TBA',900438,101104),(1356,'CS2510',20,'Computer Programming I  - 004',25,4,'Winter 2019','TBA',900438,101104),(1357,'CS2511',56,'Computer Programming II - 001',25,4,'Spring 2019','TBA',900439,101104),(1358,'CS2511',54,'Computer Programming II - 002',25,4,'Summer 2019','TBA',900439,101104),(1359,'CS2511',30,'Computer Programming II - 003',25,4,'Fall 2019','TBA',900439,101104),(1360,'CS2511',21,'Computer Programming II - 004',25,4,'Winter 2019','TBA',900439,101104),(1361,'CS3620',57,'Computer Architecture I - 001',25,4,'Spring 2019','TBA',900440,101104),(1362,'CS3620',46,'Computer Architecture I - 002',25,4,'Summer 2019','TBA',900440,101104),(1363,'CS3620',15,'Computer Architecture I - 003',25,4,'Fall 2019','TBA',900440,101104),(1364,'CS3620',52,'Computer Architecture I - 004',25,4,'Winter 2019','TBA',900440,101104),(1365,'CS3810',19,'Data Structures and Algorithms  - 001',25,4,'Spring 2019','TBA',900441,101104),(1366,'CS3810',25,'Data Structures and Algorithms  - 002',25,4,'Summer 2019','TBA',900441,101104),(1367,'CS3810',27,'Data Structures and Algorithms  - 003',25,4,'Fall 2019','TBA',900441,101104),(1368,'CS3810',22,'Data Structures and Algorithms  - 004',25,4,'Winter 2019','TBA',900441,101104),(1369,'CS3910',45,'Java and Object-Oriented Programming - 001',25,4,'Spring 2019','TBA',900442,101104),(1370,'CS3910',21,'Java and Object-Oriented Programming - 002',25,4,'Summer 2019','TBA',900442,101104),(1371,'CS3910',49,'Java and Object-Oriented Programming - 003',25,4,'Fall 2019','TBA',900442,101104),(1372,'CS3910',23,'Java and Object-Oriented Programming - 004',25,4,'Winter 2019','TBA',900442,101104),(1373,'CS3911',44,'C++ and Object-Oriented Programming  - 001',25,4,'Spring 2019','TBA',900443,101104),(1374,'CS3911',30,'C++ and Object-Oriented Programming  - 002',25,4,'Summer 2019','TBA',900443,101104),(1375,'CS3911',42,'C++ and Object-Oriented Programming  - 003',25,4,'Fall 2019','TBA',900443,101104),(1376,'CS3911',28,'C++ and Object-Oriented Programming  - 004',25,4,'Winter 2019','TBA',900443,101104),(1377,'CS4100',25,'Technical Communications  - 001',25,4,'Spring 2019','TBA',900444,101104),(1378,'CS4100',45,'Technical Communications  - 002',25,4,'Summer 2019','TBA',900444,101104),(1379,'CS4100',47,'Technical Communications  - 003',25,4,'Fall 2019','TBA',900444,101104),(1380,'CS4100',27,'Technical Communications  - 004',25,4,'Winter 2019','TBA',900444,101104),(1381,'CS4501',19,'Software Engineering  - 001',25,4,'Spring 2019','TBA',900445,101104),(1382,'CS4501',23,'Software Engineering  - 002',25,4,'Summer 2019','TBA',900445,101104),(1383,'CS4501',50,'Software Engineering  - 003',25,4,'Fall 2019','TBA',900445,101104),(1384,'CS4501',26,'Software Engineering  - 004',25,4,'Winter 2019','TBA',900445,101104),(1385,'CS4550',28,'Database Management Systems - 001',25,4,'Spring 2019','TBA',900446,101104),(1386,'CS4550',53,'Database Management Systems - 002',25,4,'Summer 2019','TBA',900446,101104),(1387,'CS4550',37,'Database Management Systems - 003',25,4,'Fall 2019','TBA',900446,101104),(1388,'CS4550',41,'Database Management Systems - 004',25,4,'Winter 2019','TBA',900446,101104),(1389,'CS4720',56,'Internet and Web Technologies  - 001',25,4,'Spring 2019','TBA',900447,101104),(1390,'CS4720',53,'Internet and Web Technologies  - 002',25,4,'Summer 2019','TBA',900447,101104),(1391,'CS4720',21,'Internet and Web Technologies  - 003',25,4,'Fall 2019','TBA',900447,101104),(1392,'CS4720',41,'Internet and Web Technologies  - 004',25,4,'Winter 2019','TBA',900447,101104),(1393,'CS5910',44,'System Design & Implementation - 001',25,4,'Spring 2019','TBA',900448,101104),(1394,'CS5910',26,'System Design & Implementation - 002',25,4,'Summer 2019','TBA',900448,101104),(1395,'CS5910',26,'System Design & Implementation - 003',25,4,'Fall 2019','TBA',900448,101104),(1396,'CS5910',30,'System Design & Implementation - 004',25,4,'Winter 2019','TBA',900448,101104),(1397,'CS4400',23,'Artificial Intelligence  - 001',25,4,'Spring 2019','TBA',900449,101104),(1398,'CS4400',48,'Artificial Intelligence  - 002',25,4,'Summer 2019','TBA',900449,101104),(1399,'CS4400',57,'Artificial Intelligence  - 003',25,4,'Fall 2019','TBA',900449,101104),(1400,'CS4400',56,'Artificial Intelligence  - 004',25,4,'Winter 2019','TBA',900449,101104),(1401,'CS4705',23,'Computer Security  - 001',25,4,'Spring 2019','TBA',900450,101104),(1402,'CS4705',36,'Computer Security  - 002',25,4,'Summer 2019','TBA',900450,101104),(1403,'CS4705',28,'Computer Security  - 003',25,4,'Fall 2019','TBA',900450,101104),(1404,'CS4705',17,'Computer Security  - 004',25,4,'Winter 2019','TBA',900450,101104),(1405,'CS4710',19,'Applied Cryptography - 001',25,4,'Spring 2019','TBA',900451,101104),(1406,'CS4710',11,'Applied Cryptography - 002',25,4,'Summer 2019','TBA',900451,101104),(1407,'CS4710',13,'Applied Cryptography - 003',25,4,'Fall 2019','TBA',900451,101104),(1408,'CS4710',46,'Applied Cryptography - 004',25,4,'Winter 2019','TBA',900451,101104),(1409,'CS5610',59,'Operating Systems  - 001',25,4,'Spring 2019','TBA',900452,101104),(1410,'CS5610',37,'Operating Systems  - 002',25,4,'Summer 2019','TBA',900452,101104),(1411,'CS5610',30,'Operating Systems  - 003',25,4,'Fall 2019','TBA',900452,101104),(1412,'CS5610',42,'Operating Systems  - 004',25,4,'Winter 2019','TBA',900452,101104),(1413,'CS5710',33,'Computer Networks  - 001',25,4,'Spring 2019','TBA',900453,101104),(1414,'CS5710',55,'Computer Networks  - 002',25,4,'Summer 2019','TBA',900453,101104),(1415,'CS5710',41,'Computer Networks  - 003',25,4,'Fall 2019','TBA',900453,101104),(1416,'CS5710',34,'Computer Networks  - 004',25,4,'Winter 2019','TBA',900453,101104),(1417,'CS5720',47,'Advanced Java Programming and Applications  - 001',25,4,'Spring 2019','TBA',900454,101104),(1418,'CS5720',53,'Advanced Java Programming and Applications  - 002',25,4,'Summer 2019','TBA',900454,101104),(1419,'CS5720',45,'Advanced Java Programming and Applications  - 003',25,4,'Fall 2019','TBA',900454,101104),(1420,'CS5720',52,'Advanced Java Programming and Applications  - 004',25,4,'Winter 2019','TBA',900454,101104),(1421,'CS5730',39,'Computer Network Security  - 001',25,4,'Spring 2019','TBA',900455,101104),(1422,'CS5730',12,'Computer Network Security  - 002',25,4,'Summer 2019','TBA',900455,101104),(1423,'CS5730',15,'Computer Network Security  - 003',25,4,'Fall 2019','TBA',900455,101104),(1424,'CS5730',27,'Computer Network Security  - 004',25,4,'Winter 2019','TBA',900455,101104),(1425,'CS5810',11,'Data Mining   - 001',25,4,'Spring 2019','TBA',900456,101104),(1426,'CS5810',36,'Data Mining   - 002',25,4,'Summer 2019','TBA',900456,101104),(1427,'CS5810',14,'Data Mining   - 003',25,4,'Fall 2019','TBA',900456,101104),(1428,'CS5810',44,'Data Mining   - 004',25,4,'Winter 2019','TBA',900456,101104),(1429,'CS3611',20,'Advanced C#   - 001',25,4,'Spring 2019','TBA',900457,101104),(1430,'CS3611',21,'Advanced C#   - 002',25,4,'Summer 2019','TBA',900457,101104),(1431,'CS3611',47,'Advanced C#   - 003',25,4,'Fall 2019','TBA',900457,101104),(1432,'CS3611',43,'Advanced C#   - 004',25,4,'Winter 2019','TBA',900457,101104),(1433,'CS4501',18,'Software Engineering  - 001',25,4,'Spring 2019','TBA',900458,101104),(1434,'CS4501',27,'Software Engineering  - 002',25,4,'Summer 2019','TBA',37,101104),(1435,'CS4501',16,'Software Engineering  - 003',25,4,'Fall 2019','TBA',900458,101104),(1436,'CS4501',47,'Software Engineering  - 004',25,4,'Winter 2019','TBA',900458,101104),(1437,'CS4550',25,'Database Management Systems - 001',25,4,'Spring 2019','TBA',900459,101104),(1438,'CS4550',36,'Database Management Systems - 002',25,4,'Summer 2019','TBA',900459,101104),(1439,'CS4550',47,'Database Management Systems - 003',25,4,'Fall 2019','TBA',900459,101104),(1440,'CS4550',33,'Database Management Systems - 004',25,4,'Winter 2019','TBA',900459,101104),(1441,'CS5551',58,'MIS Topics - 001',25,4,'Spring 2019','TBA',900460,101104),(1442,'CS5551',49,'MIS Topics - 002',25,4,'Summer 2019','TBA',900460,101104),(1443,'CS5551',45,'MIS Topics - 003',25,4,'Fall 2019','TBA',900460,101104),(1444,'CS5551',56,'MIS Topics - 004',25,4,'Winter 2019','TBA',900460,101104),(1813,'CR4000',35,'Gender, Crime and Justice  - 001',25,4,'Spring 2019','TBA',900553,0),(1814,'CR4000',16,'Gender, Crime and Justice  - 002',25,4,'Summer 2019','TBA',900553,101107),(1815,'CR4000',53,'Gender, Crime and Justice  - 003',25,4,'Fall 2019','TBA',900553,101107),(1816,'CR4000',38,'Gender, Crime and Justice  - 004',25,4,'Winter 2019','TBA',900553,101107),(1817,'CR4091',58,'Punishment and Corrections - 001',25,4,'Spring 2019','TBA',900554,101107),(1818,'CR4091',25,'Punishment and Corrections - 002',25,4,'Summer 2019','TBA',900554,101107),(1819,'CR4091',27,'Punishment and Corrections - 003',25,4,'Fall 2019','TBA',900554,101107),(1820,'CR4091',48,'Punishment and Corrections - 004',25,4,'Winter 2019','TBA',900554,101107),(1821,'CR4999',46,'Issues in Criminology - 001',25,4,'Spring 2019','TBA',900555,101107),(1822,'CR4999',38,'Issues in Criminology - 002',25,4,'Summer 2019','TBA',900555,101107),(1823,'CR4999',53,'Issues in Criminology - 003',25,4,'Fall 2019','TBA',900555,101107),(1824,'CR4999',39,'Issues in Criminology - 004',25,4,'Winter 2019','TBA',900555,101107),(1825,'CR3094',31,'Drugs and Society - 001',25,4,'Spring 2019','TBA',900556,101107),(1826,'CR3094',53,'Drugs and Society - 002',25,4,'Summer 2019','TBA',900556,101107),(1827,'CR3094',54,'Drugs and Society - 003',25,4,'Fall 2019','TBA',900556,101107),(1828,'CR3094',18,'Drugs and Society - 004',25,4,'Winter 2019','TBA',900556,101107),(1829,'CR3200',26,'Crime, Media and Culture  - 001',25,4,'Spring 2019','TBA',900557,101107),(1830,'CR3200',39,'Crime, Media and Culture  - 002',25,4,'Summer 2019','TBA',900557,101107),(1831,'CR3200',24,'Crime, Media and Culture  - 003',25,4,'Fall 2019','TBA',900557,101107),(1832,'CR3200',20,'Crime, Media and Culture  - 004',25,4,'Winter 2019','TBA',900557,101107),(1833,'CR1500',52,'Introduction to Criminology  - 001',25,4,'Spring 2019','TBA',900558,101107),(1834,'CR1500',12,'Introduction to Criminology  - 002',25,4,'Summer 2019','TBA',900558,101107),(1835,'CR1500',48,'Introduction to Criminology  - 003',25,4,'Fall 2019','TBA',900558,101107),(1836,'CR1500',26,'Introduction to Criminology  - 004',25,4,'Winter 2019','TBA',900558,101107),(1837,'CR4550',35,'Theories of Crime  - 001',25,4,'Spring 2019','TBA',900559,101107),(1838,'CR4550',35,'Theories of Crime  - 002',25,4,'Summer 2019','TBA',900559,101107),(1839,'CR4550',49,'Theories of Crime  - 003',25,4,'Fall 2019','TBA',900559,101107),(1840,'CR4550',12,'Theories of Crime  - 004',25,4,'Winter 2019','TBA',900559,101107),(1841,'PY5210',21,'Advanced Perspectives in Developmental Psychology - 001',25,4,'Spring 2019','TBA',900560,10117),(1842,'PY5210',28,'Advanced Perspectives in Developmental Psychology - 002',25,4,'Summer 2019','TBA',900560,10117),(1843,'PY5210',27,'Advanced Perspectives in Developmental Psychology - 003',25,4,'Fall 2019','TBA',900560,10117),(1844,'PY5210',16,'Advanced Perspectives in Developmental Psychology - 004',25,4,'Winter 2019','TBA',900560,10117),(1845,'PY5310',53,'Approaches to Psychotherapy  - 001',25,4,'Spring 2019','TBA',900561,10117),(1846,'PY5310',15,'Approaches to Psychotherapy  - 002',25,4,'Summer 2019','TBA',900561,10117),(1847,'PY5310',22,'Approaches to Psychotherapy  - 003',25,4,'Fall 2019','TBA',900561,10117),(1848,'PY5310',15,'Approaches to Psychotherapy  - 004',25,4,'Winter 2019','TBA',900561,10117),(1849,'PY5320',56,'Advanced Issues in Clinical Psychology  - 001',25,4,'Spring 2019','TBA',900562,10117),(1850,'PY5320',19,'Advanced Issues in Clinical Psychology  - 002',25,4,'Summer 2019','TBA',900562,10117),(1851,'PY5320',27,'Advanced Issues in Clinical Psychology  - 003',25,4,'Fall 2019','TBA',900562,10117),(1852,'PY5320',39,'Advanced Issues in Clinical Psychology  - 004',25,4,'Winter 2019','TBA',900562,10117),(1853,'PY5330',47,'Topics in Personality Theory  - 001',25,4,'Spring 2019','TBA',900563,10117),(1854,'PY5330',34,'Topics in Personality Theory  - 002',25,4,'Summer 2019','TBA',900563,10117),(1855,'PY5330',46,'Topics in Personality Theory  - 003',25,4,'Fall 2019','TBA',900563,10117),(1856,'PY5330',25,'Topics in Personality Theory  - 004',25,4,'Winter 2019','TBA',900563,10117),(1857,'PY5404',37,'Environmental Neuroplasticity  - 001',25,4,'Spring 2019','TBA',900564,10117),(1858,'PY5404',29,'Environmental Neuroplasticity  - 002',25,4,'Summer 2019','TBA',900564,10117),(1859,'PY5404',14,'Environmental Neuroplasticity  - 003',25,4,'Fall 2019','TBA',900564,10117),(1860,'PY5404',52,'Environmental Neuroplasticity  - 004',25,4,'Winter 2019','TBA',900564,10117),(1861,'PY5410',55,'The Psychology of Language  - 001',25,4,'Spring 2019','TBA',900565,10117),(1862,'PY5410',22,'The Psychology of Language  - 002',25,4,'Summer 2019','TBA',900565,10117),(1863,'PY5410',53,'The Psychology of Language  - 003',25,4,'Fall 2019','TBA',900565,10117),(1864,'PY5410',30,'The Psychology of Language  - 004',25,4,'Winter 2019','TBA',900565,10117),(1865,'PY5510',45,'Advanced Issues in Social Psychology - 001',25,4,'Spring 2019','TBA',900566,10117),(1866,'PY5510',38,'Advanced Issues in Social Psychology - 002',25,4,'Summer 2019','TBA',900566,10117),(1867,'PY5510',54,'Advanced Issues in Social Psychology - 003',25,4,'Fall 2019','TBA',900566,10117),(1868,'PY5510',24,'Advanced Issues in Social Psychology - 004',25,4,'Winter 2019','TBA',900566,10117),(1869,'PY5520',43,'Families & Public Policy  - 001',25,4,'Spring 2019','TBA',900567,10117),(1870,'PY5520',43,'Families & Public Policy  - 002',25,4,'Summer 2019','TBA',900567,10117),(1871,'PY5520',59,'Families & Public Policy  - 003',25,4,'Fall 2019','TBA',900567,10117),(1872,'PY5520',17,'Families & Public Policy  - 004',25,4,'Winter 2019','TBA',900567,10117),(1873,'PY5610',45,'Research Perspectives in Neuropsychology - 001',25,4,'Spring 2019','TBA',900568,10117),(1874,'PY5610',35,'Research Perspectives in Neuropsychology - 002',25,4,'Summer 2019','TBA',900568,10117),(1875,'PY5610',55,'Research Perspectives in Neuropsychology - 003',25,4,'Fall 2019','TBA',900568,10117),(1876,'PY5610',32,'Research Perspectives in Neuropsychology - 004',25,4,'Winter 2019','TBA',900568,10117),(1877,'PY5770',14,'Cross-Cultural Psychology - 001',25,4,'Spring 2019','TBA',900569,10117),(1878,'PY5770',59,'Cross-Cultural Psychology - 002',25,4,'Summer 2019','TBA',900569,10117),(1879,'PY5770',31,'Cross-Cultural Psychology - 003',25,4,'Fall 2019','TBA',900569,10117),(1880,'PY5770',50,'Cross-Cultural Psychology - 004',25,4,'Winter 2019','TBA',900569,10117),(1881,'PY3410',58,'Cognitive Psychology  - 001',25,4,'Spring 2019','TBA',900570,10117),(1882,'PY3410',28,'Cognitive Psychology  - 002',25,4,'Summer 2019','TBA',900570,10117),(1883,'PY3410',42,'Cognitive Psychology  - 003',25,4,'Fall 2019','TBA',900570,10117),(1884,'PY3410',45,'Cognitive Psychology  - 004',25,4,'Winter 2019','TBA',900570,10117),(1885,'PY3420',36,'Learning & Motivation - 001',25,4,'Spring 2019','TBA',900571,10117),(1886,'PY3420',39,'Learning & Motivation - 002',25,4,'Summer 2019','TBA',900571,10117),(1887,'PY3420',28,'Learning & Motivation - 003',25,4,'Fall 2019','TBA',900571,10117),(1888,'PY3420',58,'Learning & Motivation - 004',25,4,'Winter 2019','TBA',900571,10117),(1889,'PY3610',14,'Brain & Behavior  - 001',25,4,'Spring 2019','TBA',900572,10117),(1890,'PY3610',18,'Brain & Behavior  - 002',25,4,'Summer 2019','TBA',900572,10117),(1891,'PY3610',51,'Brain & Behavior  - 003',25,4,'Fall 2019','TBA',900572,10117),(1892,'PY3610',13,'Brain & Behavior  - 004',25,4,'Winter 2019','TBA',900572,10117),(1893,'PY3620',23,'Drugs and Behavior  - 001',25,4,'Spring 2019','TBA',900573,10117),(1894,'PY3620',32,'Drugs and Behavior  - 002',25,4,'Summer 2019','TBA',900573,10117),(1895,'PY3620',55,'Drugs and Behavior  - 003',25,4,'Fall 2019','TBA',900573,10117),(1896,'PY3620',53,'Drugs and Behavior  - 004',25,4,'Winter 2019','TBA',900573,10117),(1897,'PY3215',42,'Foundations of Child Development  - 001',25,4,'Spring 2019','TBA',900574,10117),(1898,'PY3215',38,'Foundations of Child Development  - 002',25,4,'Summer 2019','TBA',900574,10117),(1899,'PY3215',44,'Foundations of Child Development  - 003',25,4,'Fall 2019','TBA',900574,10117),(1900,'PY3215',38,'Foundations of Child Development  - 004',25,4,'Winter 2019','TBA',900574,10117),(1901,'PY3310',40,'Abnormal Human Behavior - 001',25,4,'Spring 2019','TBA',900575,10117),(1902,'PY3310',14,'Abnormal Human Behavior - 002',25,4,'Summer 2019','TBA',900575,10117),(1903,'PY3310',55,'Abnormal Human Behavior - 003',25,4,'Fall 2019','TBA',900575,10117),(1904,'PY3310',15,'Abnormal Human Behavior - 004',25,4,'Winter 2019','TBA',900575,10117),(1905,'PY3311',32,'Theories of Personality - 001',25,4,'Spring 2019','TBA',900576,10117),(1906,'PY3311',56,'Theories of Personality - 002',25,4,'Summer 2019','TBA',900576,10117),(1907,'PY3311',45,'Theories of Personality - 003',25,4,'Fall 2019','TBA',900576,10117),(1908,'PY3311',49,'Theories of Personality - 004',25,4,'Winter 2019','TBA',900576,10117),(1909,'PY3510',16,'Social Psychology  - 001',25,4,'Spring 2019','TBA',900577,10117),(1910,'PY3510',52,'Social Psychology  - 002',25,4,'Summer 2019','TBA',900577,10117),(1911,'PY3510',13,'Social Psychology  - 003',25,4,'Fall 2019','TBA',900577,10117),(1912,'PY3510',34,'Social Psychology  - 004',25,4,'Winter 2019','TBA',900577,10117),(1913,'PY2340',13,'Community Psychology  - 001',25,4,'Spring 2019','TBA',900578,10117),(1914,'PY2340',56,'Community Psychology  - 002',25,4,'Summer 2019','TBA',900578,10117),(1915,'PY2340',35,'Community Psychology  - 003',25,4,'Fall 2019','TBA',900578,10117),(1916,'PY2340',59,'Community Psychology  - 004',25,4,'Winter 2019','TBA',900578,10117),(1917,'PY2530',29,'Psychology of Prejudice and Discrimination - 001',25,4,'Spring 2019','TBA',900579,10117),(1918,'PY2530',52,'Psychology of Prejudice and Discrimination - 002',25,4,'Summer 2019','TBA',900579,10117),(1919,'PY2530',27,'Psychology of Prejudice and Discrimination - 003',25,4,'Fall 2019','TBA',900579,10117),(1920,'PY2530',55,'Psychology of Prejudice and Discrimination - 004',25,4,'Winter 2019','TBA',900579,10117),(1921,'PY2720',37,'Psychology of Gender  - 001',25,4,'Spring 2019','TBA',900580,10117),(1922,'PY2720',24,'Psychology of Gender  - 002',25,4,'Summer 2019','TBA',900580,10117),(1923,'PY2720',55,'Psychology of Gender  - 003',25,4,'Fall 2019','TBA',900580,10117),(1924,'PY2720',43,'Psychology of Gender  - 004',25,4,'Winter 2019','TBA',900580,10117),(1925,'PY3710',32,'Psychology & Social Justice - 001',25,4,'Spring 2019','TBA',900581,10117),(1926,'PY3710',22,'Psychology & Social Justice - 002',25,4,'Summer 2019','TBA',900581,10117),(1927,'PY3710',12,'Psychology & Social Justice - 003',25,4,'Fall 2019','TBA',900581,10117),(1928,'PY3710',57,'Psychology & Social Justice - 004',25,4,'Winter 2019','TBA',900581,10117),(1929,'PY4320',30,'Counseling Psychology - 001',25,4,'Spring 2019','TBA',900582,10117),(1930,'PY4320',43,'Counseling Psychology - 002',25,4,'Summer 2019','TBA',900582,10117),(1931,'PY4320',11,'Counseling Psychology - 003',25,4,'Fall 2019','TBA',900582,10117),(1932,'PY4320',38,'Counseling Psychology - 004',25,4,'Winter 2019','TBA',900582,10117),(1933,'PY4330',22,'Behavior Modification  - 001',25,4,'Spring 2019','TBA',900583,10117),(1934,'PY4330',29,'Behavior Modification  - 002',25,4,'Summer 2019','TBA',900583,10117),(1935,'PY4330',45,'Behavior Modification  - 003',25,4,'Fall 2019','TBA',900583,10117),(1936,'PY4330',32,'Behavior Modification  - 004',25,4,'Winter 2019','TBA',900583,10117),(1937,'PY4340',57,'Clinical & Educational Assessment - 001',25,4,'Spring 2019','TBA',900584,10117),(1938,'PY4340',27,'Clinical & Educational Assessment - 002',25,4,'Summer 2019','TBA',900584,10117),(1939,'PY4340',37,'Clinical & Educational Assessment - 003',25,4,'Fall 2019','TBA',900584,10117),(1940,'PY4340',15,'Clinical & Educational Assessment - 004',25,4,'Winter 2019','TBA',900584,10117),(1941,'PY4520',30,'Family Dynamics  - 001',25,4,'Spring 2019','TBA',900585,10117),(1942,'PY4520',46,'Family Dynamics  - 002',25,4,'Summer 2019','TBA',900585,10117),(1943,'PY4520',54,'Family Dynamics  - 003',25,4,'Fall 2019','TBA',900585,10117),(1944,'PY4520',17,'Family Dynamics  - 004',25,4,'Winter 2019','TBA',900585,10117),(1945,'PY3230',39,'Adulthood & Aging  - 001',25,4,'Spring 2019','TBA',900586,10117),(1946,'PY3230',39,'Adulthood & Aging  - 002',25,4,'Summer 2019','TBA',900586,10117),(1947,'PY3230',39,'Adulthood & Aging  - 003',25,4,'Fall 2019','TBA',900586,10117),(1948,'PY3230',33,'Adulthood & Aging  - 004',25,4,'Winter 2019','TBA',900586,10117),(1949,'PY4210',18,'The Exceptional Child  - 001',25,4,'Spring 2019','TBA',900587,10117),(1950,'PY4210',15,'The Exceptional Child  - 002',25,4,'Summer 2019','TBA',900587,10117),(1951,'PY4210',13,'The Exceptional Child  - 003',25,4,'Fall 2019','TBA',900587,10117),(1952,'PY4210',49,'The Exceptional Child  - 004',25,4,'Winter 2019','TBA',900587,10117),(1953,'PY4420',12,'Adolescent Development - 001',25,4,'Spring 2019','TBA',900588,10117),(1954,'PY4420',51,'Adolescent Development - 002',25,4,'Summer 2019','TBA',900588,10117),(1955,'PY4420',12,'Adolescent Development - 003',25,4,'Fall 2019','TBA',900588,10117),(1956,'PY4420',46,'Adolescent Development - 004',25,4,'Winter 2019','TBA',900588,10117),(1957,'PY4450',35,'Infants & Toddlers  - 001',25,4,'Spring 2019','TBA',900589,10117),(1958,'PY4450',59,'Infants & Toddlers  - 002',25,4,'Summer 2019','TBA',900589,10117),(1959,'PY4450',27,'Infants & Toddlers  - 003',25,4,'Fall 2019','TBA',900589,10117),(1960,'PY4450',12,'Infants & Toddlers  - 004',25,4,'Winter 2019','TBA',900589,10117),(1961,'PY3500',26,'Personal & Professional Decision Making  - 001',25,4,'Spring 2019','TBA',900590,10117),(1962,'PY3500',42,'Personal & Professional Decision Making  - 002',25,4,'Summer 2019','TBA',900590,10117),(1963,'PY3500',50,'Personal & Professional Decision Making  - 003',25,4,'Fall 2019','TBA',900590,10117),(1964,'PY3500',19,'Personal & Professional Decision Making  - 004',25,4,'Winter 2019','TBA',900590,10117),(1965,'PY3510',34,'Social Psychology - 001',25,4,'Spring 2019','TBA',900591,10117),(1966,'PY3510',20,'Social Psychology - 002',25,4,'Summer 2019','TBA',900591,10117),(1967,'PY3510',27,'Social Psychology - 003',25,4,'Fall 2019','TBA',900591,10117),(1968,'PY3510',52,'Social Psychology - 004',25,4,'Winter 2019','TBA',900591,10117),(1969,'PY3520',37,'Group Process  - 001',25,4,'Spring 2019','TBA',900592,10117),(1970,'PY3520',52,'Group Process  - 002',25,4,'Summer 2019','TBA',900592,10117),(1971,'PY3520',18,'Group Process  - 003',25,4,'Fall 2019','TBA',900592,10117),(1972,'PY3520',59,'Group Process  - 004',25,4,'Winter 2019','TBA',900592,10117),(1973,'PY3550',39,'Social Psychology of Work  - 001',25,4,'Spring 2019','TBA',900593,10117),(1974,'PY3550',46,'Social Psychology of Work  - 002',25,4,'Summer 2019','TBA',900593,10117),(1975,'PY3550',17,'Social Psychology of Work  - 003',25,4,'Fall 2019','TBA',900593,10117),(1976,'PY3550',58,'Social Psychology of Work  - 004',25,4,'Winter 2019','TBA',900593,10117),(1977,'PY3565',21,'Organizational Psychology - 001',25,4,'Spring 2019','TBA',900594,10117),(1978,'PY3565',49,'Organizational Psychology - 002',25,4,'Summer 2019','TBA',900594,10117),(1979,'PY3565',36,'Organizational Psychology - 003',25,4,'Fall 2019','TBA',900594,10117),(1980,'PY3565',31,'Organizational Psychology - 004',25,4,'Winter 2019','TBA',900594,10117),(1981,'PY4010',55,'History of Psychology - 001',25,4,'Spring 2019','TBA',900595,10117),(1982,'PY4010',43,'History of Psychology - 002',25,4,'Summer 2019','TBA',900595,10117),(1983,'PY4010',25,'History of Psychology - 003',25,4,'Fall 2019','TBA',900595,10117),(1984,'PY4010',24,'History of Psychology - 004',25,4,'Winter 2019','TBA',900595,10117),(1985,'PY4350',52,'Psychology of Violence  - 001',25,4,'Spring 2019','TBA',900596,10117),(1986,'PY4350',57,'Psychology of Violence  - 002',25,4,'Summer 2019','TBA',900596,10117),(1987,'PY4350',40,'Psychology of Violence  - 003',25,4,'Fall 2019','TBA',900596,10117),(1988,'PY4350',59,'Psychology of Violence  - 004',25,4,'Winter 2019','TBA',900596,10117),(1989,'PY4560',32,'Psychological Traumatization  - 001',25,4,'Spring 2019','TBA',900597,10117),(1990,'PY4560',24,'Psychological Traumatization  - 002',25,4,'Summer 2019','TBA',900597,10117),(1991,'PY4560',40,'Psychological Traumatization  - 003',25,4,'Fall 2019','TBA',900597,10117),(1992,'PY4560',26,'Psychological Traumatization  - 004',25,4,'Winter 2019','TBA',900597,10117),(1993,'PY2730',22,'Psychology of Families of African Descent - 001',25,4,'Spring 2019','TBA',900598,10117),(1994,'PY2730',28,'Psychology of Families of African Descent - 002',25,4,'Summer 2019','TBA',900598,10117),(1995,'PY2730',38,'Psychology of Families of African Descent - 003',25,4,'Fall 2019','TBA',900598,10117),(1996,'PY2730',42,'Psychology of Families of African Descent - 004',25,4,'Winter 2019','TBA',900598,10117),(1997,'PY3740',50,'Psychology of Latinos  - 001',25,4,'Spring 2019','TBA',900599,10117),(1998,'PY3740',54,'Psychology of Latinos  - 002',25,4,'Summer 2019','TBA',900599,10117),(1999,'PY3740',50,'Psychology of Latinos  - 003',25,4,'Fall 2019','TBA',900599,10117),(2000,'PY3740',52,'Psychology of Latinos  - 004',25,4,'Winter 2019','TBA',900599,10117),(2001,'PY3750',31,'Psychology of Asian Americans - 001',25,4,'Spring 2019','TBA',900600,10117),(2002,'PY3750',33,'Psychology of Asian Americans - 002',25,4,'Summer 2019','TBA',900600,10117),(2003,'PY3750',59,'Psychology of Asian Americans - 003',25,4,'Fall 2019','TBA',900600,10117),(2004,'PY3750',12,'Psychology of Asian Americans - 004',25,4,'Winter 2019','TBA',900600,10117),(2005,'PY4720',43,'Psychology of Women  - 001',25,4,'Spring 2019','TBA',900601,10117),(2006,'PY4720',38,'Psychology of Women  - 002',25,4,'Summer 2019','TBA',900601,10117),(2007,'PY4720',39,'Psychology of Women  - 003',25,4,'Fall 2019','TBA',900601,10117),(2008,'PY4720',54,'Psychology of Women  - 004',25,4,'Winter 2019','TBA',900601,10117),(2009,'PY4730',27,'African-American Family Dynamics - 001',25,4,'Spring 2019','TBA',900602,10117),(2010,'PY4730',55,'African-American Family Dynamics - 002',25,4,'Summer 2019','TBA',900602,10117),(2011,'PY4730',59,'African-American Family Dynamics - 003',25,4,'Fall 2019','TBA',900602,10117),(2012,'PY4730',25,'African-American Family Dynamics - 004',25,4,'Winter 2019','TBA',900602,10117),(2013,'PY3430',39,'Decision- Making and Judgment  - 001',25,4,'Spring 2019','TBA',900603,10117),(2014,'PY3430',47,'Decision- Making and Judgment  - 002',25,4,'Summer 2019','TBA',900603,10117),(2015,'PY3430',43,'Decision- Making and Judgment  - 003',25,4,'Fall 2019','TBA',900603,10117),(2016,'PY3430',23,'Decision- Making and Judgment  - 004',25,4,'Winter 2019','TBA',900603,10117),(2017,'PY4403',29,'Cognitive Neuroscience  - 001',25,4,'Spring 2019','TBA',900604,10117),(2018,'PY4403',12,'Cognitive Neuroscience  - 002',25,4,'Summer 2019','TBA',900604,10117),(2019,'PY4403',17,'Cognitive Neuroscience  - 003',25,4,'Fall 2019','TBA',900604,10117),(2020,'PY4403',25,'Cognitive Neuroscience  - 004',25,4,'Winter 2019','TBA',900604,10117),(2021,'PY4410',21,'Psychology of Teaching and Learning - 001',25,4,'Spring 2019','TBA',900605,10117),(2022,'PY4410',47,'Psychology of Teaching and Learning - 002',25,4,'Summer 2019','TBA',900605,10117),(2023,'PY4410',33,'Psychology of Teaching and Learning - 003',25,4,'Fall 2019','TBA',900605,10117),(2024,'PY4410',38,'Psychology of Teaching and Learning - 004',25,4,'Winter 2019','TBA',900605,10117),(2025,'PY4230',54,'The Psychobiology of Aging  - 001',25,4,'Spring 2019','TBA',900606,10117),(2026,'PY4230',48,'The Psychobiology of Aging  - 002',25,4,'Summer 2019','TBA',900606,10117),(2027,'PY4230',13,'The Psychobiology of Aging  - 003',25,4,'Fall 2019','TBA',900606,10117),(2028,'PY4230',43,'The Psychobiology of Aging  - 004',25,4,'Winter 2019','TBA',900606,10117),(2029,'PY4401',54,'Developmental Neuropathology - 001',25,4,'Spring 2019','TBA',900607,10117),(2030,'PY4401',46,'Developmental Neuropathology - 002',25,4,'Summer 2019','TBA',900607,10117),(2031,'PY4401',35,'Developmental Neuropathology - 003',25,4,'Fall 2019','TBA',900607,10117),(2032,'PY4401',54,'Developmental Neuropathology - 004',25,4,'Winter 2019','TBA',900607,10117),(2033,'PY4402',41,'Neuropsychopharmacology - 001',25,4,'Spring 2019','TBA',900608,10117),(2034,'PY4402',30,'Neuropsychopharmacology - 002',25,4,'Summer 2019','TBA',900608,10117),(2035,'PY4402',40,'Neuropsychopharmacology - 003',25,4,'Fall 2019','TBA',900608,10117),(2036,'PY4402',14,'Neuropsychopharmacology - 004',25,4,'Winter 2019','TBA',900608,10117),(2037,'PY3020',53,'Health Psychology - 001',25,4,'Spring 2019','TBA',900609,10117),(2038,'PY3020',46,'Health Psychology - 002',25,4,'Summer 2019','TBA',900609,10117),(2039,'PY3020',54,'Health Psychology - 003',25,4,'Fall 2019','TBA',900609,10117),(2040,'PY3020',51,'Health Psychology - 004',25,4,'Winter 2019','TBA',900609,10117),(2041,'PY3330',54,'Psychology of Addictions - 001',25,4,'Spring 2019','TBA',900610,10117),(2042,'PY3330',41,'Psychology of Addictions - 002',25,4,'Summer 2019','TBA',900610,10117),(2043,'PY3330',42,'Psychology of Addictions - 003',25,4,'Fall 2019','TBA',900610,10117),(2044,'PY3330',14,'Psychology of Addictions - 004',25,4,'Winter 2019','TBA',900610,10117),(2045,'PY3530',19,'Forensic Psychology  - 001',25,4,'Spring 2019','TBA',900611,10117),(2046,'PY3530',58,'Forensic Psychology  - 002',25,4,'Summer 2019','TBA',900611,10117),(2047,'PY3530',46,'Forensic Psychology  - 003',25,4,'Fall 2019','TBA',900611,10117),(2048,'PY3530',24,'Forensic Psychology  - 004',25,4,'Winter 2019','TBA',900611,10117),(2049,'PS3625',28,'Nonprofit Stewardship and Development - 001',25,4,'Spring 2019','TBA',900612,10118),(2050,'PS3625',46,'Nonprofit Stewardship and Development - 002',25,4,'Summer 2019','TBA',900612,10118),(2051,'PS3625',49,'Nonprofit Stewardship and Development - 003',25,4,'Fall 2019','TBA',900612,10118),(2052,'PS3625',52,'Nonprofit Stewardship and Development - 004',25,4,'Winter 2019','TBA',900612,10118),(2053,'PS3675',32,'Introduction to Social Entrepreneurship - 001',25,4,'Spring 2019','TBA',900613,10118),(2054,'PS3675',38,'Introduction to Social Entrepreneurship - 002',25,4,'Summer 2019','TBA',900613,10118),(2055,'PS3675',11,'Introduction to Social Entrepreneurship - 003',25,4,'Fall 2019','TBA',900613,10118),(2056,'PS3675',39,'Introduction to Social Entrepreneurship - 004',25,4,'Winter 2019','TBA',900613,10118),(2057,'PS4420',56,'Entertainment and Sports Management - 001',25,4,'Spring 2019','TBA',900614,10118),(2058,'PS4420',22,'Entertainment and Sports Management - 002',25,4,'Summer 2019','TBA',900614,10118),(2059,'PS4420',24,'Entertainment and Sports Management - 003',25,4,'Fall 2019','TBA',900614,10118),(2060,'PS4420',49,'Entertainment and Sports Management - 004',25,4,'Winter 2019','TBA',900614,10118),(2061,'PS4430',18,'Entertainment and Sports Marketing  - 001',25,4,'Spring 2019','TBA',900615,10118),(2062,'PS4430',28,'Entertainment and Sports Marketing  - 002',25,4,'Summer 2019','TBA',900615,10118),(2063,'PS4430',47,'Entertainment and Sports Marketing  - 003',25,4,'Fall 2019','TBA',900615,10118),(2064,'PS4430',50,'Entertainment and Sports Marketing  - 004',25,4,'Winter 2019','TBA',900615,10118),(2065,'PS4440',31,'Entertainment and Sports Media  - 001',25,4,'Spring 2019','TBA',900616,10118),(2066,'PS4440',39,'Entertainment and Sports Media  - 002',25,4,'Summer 2019','TBA',900616,10118),(2067,'PS4440',37,'Entertainment and Sports Media  - 003',25,4,'Fall 2019','TBA',900616,10118),(2068,'PS4440',30,'Entertainment and Sports Media  - 004',25,4,'Winter 2019','TBA',900616,10118),(2069,'PS4630',16,'Financial Administration of Nonprofits - 001',25,4,'Spring 2019','TBA',900617,10118),(2070,'PS4630',13,'Financial Administration of Nonprofits - 002',25,4,'Summer 2019','TBA',900617,10118),(2071,'PS4630',38,'Financial Administration of Nonprofits - 003',25,4,'Fall 2019','TBA',900617,10118),(2072,'PS4630',30,'Financial Administration of Nonprofits - 004',25,4,'Winter 2019','TBA',900617,10118),(2073,'PS4660',32,'Business Leadership and Ethics  - 001',25,4,'Spring 2019','TBA',900618,10118),(2074,'PS4660',12,'Business Leadership and Ethics  - 002',25,4,'Summer 2019','TBA',900618,10118),(2075,'PS4660',45,'Business Leadership and Ethics  - 003',25,4,'Fall 2019','TBA',900618,10118),(2076,'PS4660',40,'Business Leadership and Ethics  - 004',25,4,'Winter 2019','TBA',900618,10118),(2077,'PS5425',33,'Entertainment and Sports Law  - 001',25,4,'Spring 2019','TBA',900619,10118),(2078,'PS5425',19,'Entertainment and Sports Law  - 002',25,4,'Summer 2019','TBA',900619,10118),(2079,'PS5425',59,'Entertainment and Sports Law  - 003',25,4,'Fall 2019','TBA',900619,10118),(2080,'PS5425',13,'Entertainment and Sports Law  - 004',25,4,'Winter 2019','TBA',900619,10118),(2081,'PS5435',37,'Entertainment and Sports Finance - 001',25,4,'Spring 2019','TBA',900620,10118),(2082,'PS5435',34,'Entertainment and Sports Finance - 002',25,4,'Summer 2019','TBA',900620,10118),(2083,'PS5435',12,'Entertainment and Sports Finance - 003',25,4,'Fall 2019','TBA',900620,10118),(2084,'PS5435',59,'Entertainment and Sports Finance - 004',25,4,'Winter 2019','TBA',900620,10118),(2085,'PS2330',24,'Fundamentals of Economics - 001',25,4,'Spring 2019','TBA',900621,10118),(2086,'PS2330',27,'Fundamentals of Economics - 002',25,4,'Summer 2019','TBA',900621,10118),(2087,'PS2330',49,'Fundamentals of Economics - 003',25,4,'Fall 2019','TBA',900621,10118),(2088,'PS2330',26,'Fundamentals of Economics - 004',25,4,'Winter 2019','TBA',900621,10118),(2089,'PS3130',50,'Accounting for Professionals - 001',25,4,'Spring 2019','TBA',900622,10118),(2090,'PS3130',17,'Accounting for Professionals - 002',25,4,'Summer 2019','TBA',900622,10118),(2091,'PS3130',27,'Accounting for Professionals - 003',25,4,'Fall 2019','TBA',900622,10118),(2092,'PS3130',49,'Accounting for Professionals - 004',25,4,'Winter 2019','TBA',900622,10118),(2093,'PS3230',48,'Professional Communications - 001',25,4,'Spring 2019','TBA',900623,10118),(2094,'PS3230',14,'Professional Communications - 002',25,4,'Summer 2019','TBA',900623,10118),(2095,'PS3230',49,'Professional Communications - 003',25,4,'Fall 2019','TBA',900623,10118),(2096,'PS3230',43,'Professional Communications - 004',25,4,'Winter 2019','TBA',900623,10118),(2097,'PS3260',36,'Information Technology for Professionals  - 001',25,4,'Spring 2019','TBA',900624,10118),(2098,'PS3260',13,'Information Technology for Professionals  - 002',25,4,'Summer 2019','TBA',900624,10118),(2099,'PS3260',33,'Information Technology for Professionals  - 003',25,4,'Fall 2019','TBA',900624,10118),(2100,'PS3260',54,'Information Technology for Professionals  - 004',25,4,'Winter 2019','TBA',900624,10118),(2101,'PS3330',16,'Professional Supervision  - 001',25,4,'Spring 2019','TBA',900625,10118),(2102,'PS3330',25,'Professional Supervision  - 002',25,4,'Summer 2019','TBA',900625,10118),(2103,'PS3330',15,'Professional Supervision  - 003',25,4,'Fall 2019','TBA',900625,10118),(2104,'PS3330',30,'Professional Supervision  - 004',25,4,'Winter 2019','TBA',900625,10118),(2105,'PS3430',56,'Marketing for Professionals - 001',25,4,'Spring 2019','TBA',900626,10118),(2106,'PS3430',20,'Marketing for Professionals - 002',25,4,'Summer 2019','TBA',900626,10118),(2107,'PS3430',56,'Marketing for Professionals - 003',25,4,'Fall 2019','TBA',900626,10118),(2108,'PS3430',28,'Marketing for Professionals - 004',25,4,'Winter 2019','TBA',900626,10118),(2109,'PS4225',56,'The Law for Professionals - 001',25,4,'Spring 2019','TBA',900627,10118),(2110,'PS4225',42,'The Law for Professionals - 002',25,4,'Summer 2019','TBA',900627,10118),(2111,'PS4225',13,'The Law for Professionals - 003',25,4,'Fall 2019','TBA',900627,10118),(2112,'PS4225',52,'The Law for Professionals - 004',25,4,'Winter 2019','TBA',900627,10118),(2113,'PS4325',41,'The Financial System  - 001',25,4,'Spring 2019','TBA',900628,10118),(2114,'PS4325',14,'The Financial System  - 002',25,4,'Summer 2019','TBA',900628,10118),(2115,'PS4325',38,'The Financial System  - 003',25,4,'Fall 2019','TBA',900628,10118),(2116,'PS4325',46,'The Financial System  - 004',25,4,'Winter 2019','TBA',900628,10118),(2117,'PH3600',46,'Introduction to the Social Determinants of Health - 001',25,4,'Spring 2019','TBA',900629,101102),(2118,'PH3600',18,'Introduction to the Social Determinants of Health - 002',25,4,'Summer 2019','TBA',900629,101102),(2119,'PH3600',43,'Introduction to the Social Determinants of Health - 003',25,4,'Fall 2019','TBA',900629,101102),(2120,'PH3600',50,'Introduction to the Social Determinants of Health - 004',25,4,'Winter 2019','TBA',900629,101102),(2121,'PH3610',41,'Introduction to the U.S. HealthCare System - 001',25,4,'Spring 2019','TBA',900630,101102),(2122,'PH3610',16,'Introduction to the U.S. HealthCare System - 002',25,4,'Summer 2019','TBA',900630,101102),(2123,'PH3610',13,'Introduction to the U.S. HealthCare System - 003',25,4,'Fall 2019','TBA',900630,101102),(2124,'PH3610',45,'Introduction to the U.S. HealthCare System - 004',25,4,'Winter 2019','TBA',900630,101102),(2125,'PH4670',15,'Biostatistics Epidemiology  - 001',25,4,'Spring 2019','TBA',900631,101102),(2126,'PH4670',24,'Biostatistics Epidemiology  - 002',25,4,'Summer 2019','TBA',900631,101102),(2127,'PH4670',43,'Biostatistics Epidemiology  - 003',25,4,'Fall 2019','TBA',900631,101102),(2128,'PH4670',59,'Biostatistics Epidemiology  - 004',25,4,'Winter 2019','TBA',900631,101102),(2129,'PH4800',33,'Field Placement  - 001',25,4,'Spring 2019','TBA',900632,101102),(2130,'PH4800',32,'Field Placement  - 002',25,4,'Summer 2019','TBA',900632,101102),(2131,'PH4800',59,'Field Placement  - 003',25,4,'Fall 2019','TBA',900632,101102),(2132,'PH4800',45,'Field Placement  - 004',25,4,'Winter 2019','TBA',900632,101102),(2133,'PH4900',35,'Research Methods Senior Seminar - 001',25,4,'Spring 2019','TBA',900633,101102),(2134,'PH4900',31,'Research Methods Senior Seminar - 002',25,4,'Summer 2019','TBA',900633,101102),(2135,'PH4900',44,'Research Methods Senior Seminar - 003',25,4,'Fall 2019','TBA',900633,101102),(2136,'PH4900',52,'Research Methods Senior Seminar - 004',25,4,'Winter 2019','TBA',900633,101102),(2137,'PH5900',48,'Basic Biological Sciences II - 001',25,4,'Spring 2019','TBA',900634,101102),(2138,'PH5900',41,'Basic Biological Sciences II - 002',25,4,'Summer 2019','TBA',900634,101102),(2139,'PH5900',25,'Basic Biological Sciences II - 003',25,4,'Fall 2019','TBA',900634,101102),(2140,'PH5900',57,'Basic Biological Sciences II - 004',25,4,'Winter 2019','TBA',900634,101102),(2141,'PH3200',50,'Nutrition and Society - 001',25,4,'Spring 2019','TBA',900635,101102),(2142,'PH3200',26,'Nutrition and Society - 002',25,4,'Summer 2019','TBA',900635,101102),(2143,'PH3200',22,'Nutrition and Society - 003',25,4,'Fall 2019','TBA',900635,101102),(2144,'PH3200',36,'Nutrition and Society - 004',25,4,'Winter 2019','TBA',900635,101102),(2145,'PH4450',56,'Human Sexuality - 001',25,4,'Spring 2019','TBA',900636,101102),(2146,'PH4450',55,'Human Sexuality - 002',25,4,'Summer 2019','TBA',900636,101102),(2147,'PH4450',25,'Human Sexuality - 003',25,4,'Fall 2019','TBA',900636,101102),(2148,'PH4450',50,'Human Sexuality - 004',25,4,'Winter 2019','TBA',900636,101102),(2149,'PH4600',25,'Health Program Planning and Evaluation - 001',25,4,'Spring 2019','TBA',900637,101102),(2150,'PH4600',22,'Health Program Planning and Evaluation - 002',25,4,'Summer 2019','TBA',900637,101102),(2151,'PH4600',36,'Health Program Planning and Evaluation - 003',25,4,'Fall 2019','TBA',900637,101102),(2152,'PH4600',21,'Health Program Planning and Evaluation - 004',25,4,'Winter 2019','TBA',900637,101102),(2153,'PH4610',14,'Womens Health - 001',25,4,'Spring 2019','TBA',900638,101102),(2154,'PH4610',19,'Womens Health - 002',25,4,'Summer 2019','TBA',900638,101102),(2155,'PH4610',35,'Womens Health - 003',25,4,'Fall 2019','TBA',900638,101102),(2156,'PH4610',53,'Womens Health - 004',25,4,'Winter 2019','TBA',900638,101102),(2157,'PH4631',49,'Mental Health - 001',25,4,'Spring 2019','TBA',900639,101102),(2158,'PH4631',41,'Mental Health - 002',25,4,'Summer 2019','TBA',900639,101102),(2159,'PH4631',26,'Mental Health - 003',25,4,'Fall 2019','TBA',900639,101102),(2160,'PH4631',55,'Mental Health - 004',25,4,'Winter 2019','TBA',900639,101102),(2161,'PH4650',19,'Substance Use and Abuse - 001',25,4,'Spring 2019','TBA',900640,101102),(2162,'PH4650',31,'Substance Use and Abuse - 002',25,4,'Summer 2019','TBA',900640,101102),(2163,'PH4650',27,'Substance Use and Abuse - 003',25,4,'Fall 2019','TBA',900640,101102),(2164,'PH4650',41,'Substance Use and Abuse - 004',25,4,'Winter 2019','TBA',900640,101102),(2165,'PH4661',38,'Health Education - 001',25,4,'Spring 2019','TBA',900641,101102),(2166,'PH4661',58,'Health Education - 002',25,4,'Summer 2019','TBA',900641,101102),(2167,'PH4661',21,'Health Education - 003',25,4,'Fall 2019','TBA',900641,101102),(2168,'PH4661',55,'Health Education - 004',25,4,'Winter 2019','TBA',900641,101102),(2169,'PH4680',47,'Environmental Health - 001',25,4,'Spring 2019','TBA',900642,101102),(2170,'PH4680',51,'Environmental Health - 002',25,4,'Summer 2019','TBA',900642,101102),(2171,'PH4680',44,'Environmental Health - 003',25,4,'Fall 2019','TBA',900642,101102),(2172,'PH4680',44,'Environmental Health - 004',25,4,'Winter 2019','TBA',900642,101102),(2173,'PH4700',47,'Medical Anthropology - 001',25,4,'Spring 2019','TBA',900643,101102),(2174,'PH4700',14,'Medical Anthropology - 002',25,4,'Summer 2019','TBA',900643,101102),(2175,'PH4700',21,'Medical Anthropology - 003',25,4,'Fall 2019','TBA',900643,101102),(2176,'PH4700',40,'Medical Anthropology - 004',25,4,'Winter 2019','TBA',900643,101102),(2177,'PH4750',52,'Aging and Social Policy - 001',25,4,'Spring 2019','TBA',900644,101102),(2178,'PH4750',11,'Aging and Social Policy - 002',25,4,'Summer 2019','TBA',900644,101102),(2179,'PH4750',11,'Aging and Social Policy - 003',25,4,'Fall 2019','TBA',900644,101102),(2180,'PH4750',44,'Aging and Social Policy - 004',25,4,'Winter 2019','TBA',900644,101102),(2181,'PH4760',25,'Health Administration - 001',25,4,'Spring 2019','TBA',900645,101102),(2182,'PH4760',22,'Health Administration - 002',25,4,'Summer 2019','TBA',900645,101102),(2183,'PH4760',27,'Health Administration - 003',25,4,'Fall 2019','TBA',900645,101102),(2184,'PH4760',37,'Health Administration - 004',25,4,'Winter 2019','TBA',900645,101102),(2185,'PH4770',57,'Occupational Health - 001',25,4,'Spring 2019','TBA',900646,101102),(2186,'PH4770',41,'Occupational Health - 002',25,4,'Summer 2019','TBA',900646,101102),(2187,'PH4770',29,'Occupational Health - 003',25,4,'Fall 2019','TBA',900646,101102),(2188,'PH4770',20,'Occupational Health - 004',25,4,'Winter 2019','TBA',900646,101102),(2189,'PH4790',45,'Health Policy - 001',25,4,'Spring 2019','TBA',900647,101102),(2190,'PH4790',34,'Health Policy - 002',25,4,'Summer 2019','TBA',900647,101102),(2191,'PH4790',38,'Health Policy - 003',25,4,'Fall 2019','TBA',900647,101102),(2192,'PH4790',37,'Health Policy - 004',25,4,'Winter 2019','TBA',900647,101102),(2193,'PH4810',49,'Ethics in Public Health - 001',25,4,'Spring 2019','TBA',900648,101102),(2194,'PH4810',58,'Ethics in Public Health - 002',25,4,'Summer 2019','TBA',900648,101102),(2195,'PH4810',36,'Ethics in Public Health - 003',25,4,'Fall 2019','TBA',900648,101102),(2196,'PH4810',31,'Ethics in Public Health - 004',25,4,'Winter 2019','TBA',900648,101102),(2197,'PH4820',44,'Health Law - 001',25,4,'Spring 2019','TBA',900649,101102),(2198,'PH4820',29,'Health Law - 002',25,4,'Summer 2019','TBA',900649,101102),(2199,'PH4820',51,'Health Law - 003',25,4,'Fall 2019','TBA',900649,101102),(2200,'PH4820',40,'Health Law - 004',25,4,'Winter 2019','TBA',900649,101102),(2201,'PH4850',39,'Global Health - 001',25,4,'Spring 2019','TBA',900650,101102),(2202,'PH4850',16,'Global Health - 002',25,4,'Summer 2019','TBA',900650,101102),(2203,'PH4850',44,'Global Health - 003',25,4,'Fall 2019','TBA',900650,101102),(2204,'PH4850',11,'Global Health - 004',25,4,'Winter 2019','TBA',900650,101102),(2205,'PH4890',40,'Environmental Justice - 001',25,4,'Spring 2019','TBA',900651,101102),(2206,'PH4890',58,'Environmental Justice - 002',25,4,'Summer 2019','TBA',900651,101102),(2207,'PH4890',51,'Environmental Justice - 003',25,4,'Fall 2019','TBA',900651,101102),(2208,'PH4890',17,'Environmental Justice - 004',25,4,'Winter 2019','TBA',900651,101102),(2209,'PH4920',43,'Special Topics in Public Health  - 001',25,4,'Spring 2019','TBA',900652,101102),(2210,'PH4920',42,'Special Topics in Public Health  - 002',25,4,'Summer 2019','TBA',900652,101102),(2211,'PH4920',53,'Special Topics in Public Health  - 003',25,4,'Fall 2019','TBA',900652,101102),(2212,'PH4920',37,'Special Topics in Public Health  - 004',25,4,'Winter 2019','TBA',900652,101102),(2213,'PH4930',59,'Immigrant and Refugee Health - 001',25,4,'Spring 2019','TBA',900653,101102),(2214,'PH4930',53,'Immigrant and Refugee Health - 002',25,4,'Summer 2019','TBA',900653,101102),(2215,'PH4930',37,'Immigrant and Refugee Health - 003',25,4,'Fall 2019','TBA',900653,101102),(2216,'PH4930',34,'Immigrant and Refugee Health - 004',25,4,'Winter 2019','TBA',900653,101102),(2217,'BS3531',33,'Comparative Genomics Lab - 001',25,4,'Spring 2019','TBA',900654,101102),(2218,'BS3531',35,'Comparative Genomics Lab - 002',25,4,'Summer 2019','TBA',900654,101102),(2219,'BS3531',56,'Comparative Genomics Lab - 003',25,4,'Fall 2019','TBA',900654,101102),(2220,'BS3531',34,'Comparative Genomics Lab - 004',25,4,'Winter 2019','TBA',900654,101102),(2221,'BS3710',15,'Environmental Physiology  - 001',25,4,'Spring 2019','TBA',900655,101102),(2222,'BS3710',57,'Environmental Physiology  - 002',25,4,'Summer 2019','TBA',900655,101102),(2223,'BS3710',56,'Environmental Physiology  - 003',25,4,'Fall 2019','TBA',900655,101102),(2224,'BS3710',16,'Environmental Physiology  - 004',25,4,'Winter 2019','TBA',900655,101102),(2225,'BS3810',38,'Biological Aspects of Aging  - 001',25,4,'Spring 2019','TBA',900656,101102),(2226,'BS3810',55,'Biological Aspects of Aging  - 002',25,4,'Summer 2019','TBA',900656,101102),(2227,'BS3810',52,'Biological Aspects of Aging  - 003',25,4,'Fall 2019','TBA',900656,101102),(2228,'BS3810',29,'Biological Aspects of Aging  - 004',25,4,'Winter 2019','TBA',900656,101102),(2229,'BS3910',56,'Introduction to Bioinformatics - 001',25,4,'Spring 2019','TBA',900657,101102),(2230,'BS3910',56,'Introduction to Bioinformatics - 002',25,4,'Summer 2019','TBA',900657,101102),(2231,'BS3910',41,'Introduction to Bioinformatics - 003',25,4,'Fall 2019','TBA',900657,101102),(2232,'BS3910',45,'Introduction to Bioinformatics - 004',25,4,'Winter 2019','TBA',900657,101102),(2233,'BS4400',26,'Cell Biology - 001',25,4,'Spring 2019','TBA',900658,101102),(2234,'BS4400',14,'Cell Biology - 002',25,4,'Summer 2019','TBA',900658,101102),(2235,'BS4400',34,'Cell Biology - 003',25,4,'Fall 2019','TBA',900658,101102),(2236,'BS4400',25,'Cell Biology - 004',25,4,'Winter 2019','TBA',900658,101102),(2237,'BS4410',12,'Histology - 001',25,4,'Spring 2019','TBA',900659,101102),(2238,'BS4410',49,'Histology - 002',25,4,'Summer 2019','TBA',900659,101102),(2239,'BS4410',24,'Histology - 003',25,4,'Fall 2019','TBA',900659,101102),(2240,'BS4410',25,'Histology - 004',25,4,'Winter 2019','TBA',900659,101102),(2241,'BS4420',47,'Microbiology - 001',25,4,'Spring 2019','TBA',900660,101102),(2242,'BS4420',48,'Microbiology - 002',25,4,'Summer 2019','TBA',900660,101102),(2243,'BS4420',19,'Microbiology - 003',25,4,'Fall 2019','TBA',900660,101102),(2244,'BS4420',15,'Microbiology - 004',25,4,'Winter 2019','TBA',900660,101102),(2245,'BS4430',34,'Developmental Biology - 001',25,4,'Spring 2019','TBA',900661,101102),(2246,'BS4430',18,'Developmental Biology - 002',25,4,'Summer 2019','TBA',900661,101102),(2247,'BS4430',26,'Developmental Biology - 003',25,4,'Fall 2019','TBA',900661,101102),(2248,'BS4430',19,'Developmental Biology - 004',25,4,'Winter 2019','TBA',900661,101102),(2249,'BS4440',39,'Evolution - 001',25,4,'Spring 2019','TBA',900662,101102),(2250,'BS4440',51,'Evolution - 002',25,4,'Summer 2019','TBA',900662,101102),(2251,'BS4440',57,'Evolution - 003',25,4,'Fall 2019','TBA',900662,101102),(2252,'BS4440',18,'Evolution - 004',25,4,'Winter 2019','TBA',900662,101102),(2253,'BS4460',46,'Genetics - 001',25,4,'Spring 2019','TBA',900663,101102),(2254,'BS4460',16,'Genetics - 002',25,4,'Summer 2019','TBA',900663,101102),(2255,'BS4460',13,'Genetics - 003',25,4,'Fall 2019','TBA',900663,101102),(2256,'BS4460',57,'Genetics - 004',25,4,'Winter 2019','TBA',900663,101102),(2257,'BS4461',24,'Immunology - 001',25,4,'Spring 2019','TBA',900664,101102),(2258,'BS4461',52,'Immunology - 002',25,4,'Summer 2019','TBA',900664,101102),(2259,'BS4461',36,'Immunology - 003',25,4,'Fall 2019','TBA',900664,101102),(2260,'BS4461',23,'Immunology - 004',25,4,'Winter 2019','TBA',900664,101102),(2261,'BS4470',32,'Ecology - 001',25,4,'Spring 2019','TBA',900665,101102),(2262,'BS4470',20,'Ecology - 002',25,4,'Summer 2019','TBA',900665,101102),(2263,'BS4470',25,'Ecology - 003',25,4,'Fall 2019','TBA',900665,101102),(2264,'BS4470',53,'Ecology - 004',25,4,'Winter 2019','TBA',900665,101102),(2265,'BS4471',41,'Freshwater Ecology (Limnology)  - 001',25,4,'Spring 2019','TBA',900666,101102),(2266,'BS4471',15,'Freshwater Ecology (Limnology)  - 002',25,4,'Summer 2019','TBA',900666,101102),(2267,'BS4471',14,'Freshwater Ecology (Limnology)  - 003',25,4,'Fall 2019','TBA',900666,101102),(2268,'BS4471',45,'Freshwater Ecology (Limnology)  - 004',25,4,'Winter 2019','TBA',900666,101102),(2269,'BS4474',46,'Microbial Ecology - 001',25,4,'Spring 2019','TBA',900667,101102),(2270,'BS4474',15,'Microbial Ecology - 002',25,4,'Summer 2019','TBA',900667,101102),(2271,'BS4474',26,'Microbial Ecology - 003',25,4,'Fall 2019','TBA',900667,101102),(2272,'BS4474',43,'Microbial Ecology - 004',25,4,'Winter 2019','TBA',900667,101102),(2273,'BS4480',44,'Animal Behavior - 001',25,4,'Spring 2019','TBA',900668,101102),(2274,'BS4480',41,'Animal Behavior - 002',25,4,'Summer 2019','TBA',900668,101102),(2275,'BS4480',22,'Animal Behavior - 003',25,4,'Fall 2019','TBA',900668,101102),(2276,'BS4480',32,'Animal Behavior - 004',25,4,'Winter 2019','TBA',900668,101102),(2277,'BS4491',23,'Human Ecology - 001',25,4,'Spring 2019','TBA',900669,101102),(2278,'BS4491',56,'Human Ecology - 002',25,4,'Summer 2019','TBA',900669,101102),(2279,'BS4491',27,'Human Ecology - 003',25,4,'Fall 2019','TBA',900669,101102),(2280,'BS4491',55,'Human Ecology - 004',25,4,'Winter 2019','TBA',900669,101102),(2281,'BS4500',16,'Cell and Molecular Neurobiology - 001',25,4,'Spring 2019','TBA',900670,101102),(2282,'BS4500',15,'Cell and Molecular Neurobiology - 002',25,4,'Summer 2019','TBA',900670,101102),(2283,'BS4500',29,'Cell and Molecular Neurobiology - 003',25,4,'Fall 2019','TBA',900670,101102),(2284,'BS4500',52,'Cell and Molecular Neurobiology - 004',25,4,'Winter 2019','TBA',900670,101102),(2285,'BS4550',11,'Cancer Cell Biology - 001',25,4,'Spring 2019','TBA',900671,101102),(2286,'BS4550',21,'Cancer Cell Biology - 002',25,4,'Summer 2019','TBA',900671,101102),(2287,'BS4550',36,'Cancer Cell Biology - 003',25,4,'Fall 2019','TBA',900671,101102),(2288,'BS4550',31,'Cancer Cell Biology - 004',25,4,'Winter 2019','TBA',900671,101102),(2289,'BS4560',43,'Molecular Biology - 001',25,4,'Spring 2019','TBA',900672,101102),(2290,'BS4560',42,'Molecular Biology - 002',25,4,'Summer 2019','TBA',900672,101102),(2291,'BS4560',49,'Molecular Biology - 003',25,4,'Fall 2019','TBA',900672,101102),(2292,'BS4560',49,'Molecular Biology - 004',25,4,'Winter 2019','TBA',900672,101102),(2293,'BS4651',18,'Toxicology - 001',25,4,'Spring 2019','TBA',900673,101102),(2294,'BS4651',41,'Toxicology - 002',25,4,'Summer 2019','TBA',900673,101102),(2295,'BS4651',24,'Toxicology - 003',25,4,'Fall 2019','TBA',900673,101102),(2296,'BS4651',46,'Toxicology - 004',25,4,'Winter 2019','TBA',900673,101102),(2297,'BS4680',26,'Environmental Health - 001',25,4,'Spring 2019','TBA',900674,101102),(2298,'BS4680',58,'Environmental Health - 002',25,4,'Summer 2019','TBA',900674,101102),(2299,'BS4680',14,'Environmental Health - 003',25,4,'Fall 2019','TBA',900674,101102),(2300,'BS4680',18,'Environmental Health - 004',25,4,'Winter 2019','TBA',900674,101102),(2301,'BS5590',38,'Advanced Research - 001',25,4,'Spring 2019','TBA',900675,101102),(2302,'BS5590',55,'Advanced Research - 002',25,4,'Summer 2019','TBA',900675,101102),(2303,'BS5590',51,'Advanced Research - 003',25,4,'Fall 2019','TBA',900675,101102),(2304,'BS5590',56,'Advanced Research - 004',25,4,'Winter 2019','TBA',900675,101102),(2305,'BS5591',40,'Environmental Research - 001',25,4,'Spring 2019','TBA',900676,101102),(2306,'BS5591',18,'Environmental Research - 002',25,4,'Summer 2019','TBA',900676,101102),(2307,'BS5591',17,'Environmental Research - 003',25,4,'Fall 2019','TBA',900676,101102),(2308,'BS5591',15,'Environmental Research - 004',25,4,'Winter 2019','TBA',900676,101102),(2309,'BS2400',18,'Basic Biology I - 001',25,4,'Spring 2019','TBA',900677,101102),(2310,'BS2400',23,'Basic Biology I - 002',25,4,'Summer 2019','TBA',900677,101102),(2311,'BS2400',13,'Basic Biology I - 003',25,4,'Fall 2019','TBA',900677,101102),(2312,'BS2400',55,'Basic Biology I - 004',25,4,'Winter 2019','TBA',900677,101102),(2313,'BS2401',30,'Basic Biology I Lab - 001',25,4,'Spring 2019','TBA',900678,101102),(2314,'BS2401',14,'Basic Biology I Lab - 002',25,4,'Summer 2019','TBA',900678,101102),(2315,'BS2401',29,'Basic Biology I Lab - 003',25,4,'Fall 2019','TBA',900678,101102),(2316,'BS2401',45,'Basic Biology I Lab - 004',25,4,'Winter 2019','TBA',900678,101102),(2317,'BS2411',22,'Basic Biology II Lab - 001',25,4,'Spring 2019','TBA',900679,101102),(2318,'BS2411',12,'Basic Biology II Lab - 002',25,4,'Summer 2019','TBA',900679,101102),(2319,'BS2411',25,'Basic Biology II Lab - 003',25,4,'Fall 2019','TBA',900679,101102),(2320,'BS2411',53,'Basic Biology II Lab - 004',25,4,'Winter 2019','TBA',900679,101102),(2321,'BS2410',17,'Basic Biology II  - 001',25,4,'Spring 2019','TBA',900680,101102),(2322,'BS2410',23,'Basic Biology II  - 002',25,4,'Summer 2019','TBA',900680,101102),(2323,'BS2410',57,'Basic Biology II  - 003',25,4,'Fall 2019','TBA',900680,101102),(2324,'BS2410',22,'Basic Biology II  - 004',25,4,'Winter 2019','TBA',900680,101102),(2325,'BS5410',57,'Seminar I: Reading in the Discipline  - 001',25,4,'Spring 2019','TBA',900681,101102),(2326,'BS5410',14,'Seminar I: Reading in the Discipline  - 002',25,4,'Summer 2019','TBA',900681,101102),(2327,'BS5410',31,'Seminar I: Reading in the Discipline  - 003',25,4,'Fall 2019','TBA',900681,101102),(2328,'BS5410',50,'Seminar I: Reading in the Discipline  - 004',25,4,'Winter 2019','TBA',900681,101102),(2329,'BS5420',14,'Seminar II: Writing in the Discipline  - 001',25,4,'Spring 2019','TBA',900682,101102),(2330,'BS5420',12,'Seminar II: Writing in the Discipline  - 002',25,4,'Summer 2019','TBA',900682,101102),(2331,'BS5420',42,'Seminar II: Writing in the Discipline  - 003',25,4,'Fall 2019','TBA',900682,101102),(2332,'BS5420',44,'Seminar II: Writing in the Discipline  - 004',25,4,'Winter 2019','TBA',900682,101102),(2333,'BS4400',16,'Cell Biology - 001',25,4,'Spring 2019','TBA',900683,101102),(2334,'BS4400',32,'Cell Biology - 002',25,4,'Summer 2019','TBA',900683,101102),(2335,'BS4400',29,'Cell Biology - 003',25,4,'Fall 2019','TBA',900683,101102),(2336,'BS4400',50,'Cell Biology - 004',25,4,'Winter 2019','TBA',900683,101102),(2337,'BS4460',13,'Genetics  - 001',25,4,'Spring 2019','TBA',900684,101102),(2338,'BS4460',47,'Genetics  - 002',25,4,'Summer 2019','TBA',900684,101102),(2339,'BS4460',36,'Genetics  - 003',25,4,'Fall 2019','TBA',900684,101102),(2340,'BS4460',44,'Genetics  - 004',25,4,'Winter 2019','TBA',900684,101102),(2341,'BS3400',26,'Vertebrate Physiology  - 001',25,4,'Spring 2019','TBA',900685,101102),(2342,'BS3400',25,'Vertebrate Physiology  - 002',25,4,'Summer 2019','TBA',900685,101102),(2343,'BS3400',28,'Vertebrate Physiology  - 003',25,4,'Fall 2019','TBA',900685,101102),(2344,'BS3400',49,'Vertebrate Physiology  - 004',25,4,'Winter 2019','TBA',900685,101102),(2345,'BS3520',52,'Comparative Anatomy - 001',25,4,'Spring 2019','TBA',900686,101102),(2346,'BS3520',45,'Comparative Anatomy - 002',25,4,'Summer 2019','TBA',900686,101102),(2347,'BS3520',24,'Comparative Anatomy - 003',25,4,'Fall 2019','TBA',900686,101102),(2348,'BS3520',55,'Comparative Anatomy - 004',25,4,'Winter 2019','TBA',900686,101102),(2349,'BS4440',54,'Evolution - 001',25,4,'Spring 2019','TBA',900687,101102),(2350,'BS4440',22,'Evolution - 002',25,4,'Summer 2019','TBA',900687,101102),(2351,'BS4440',30,'Evolution - 003',25,4,'Fall 2019','TBA',900687,101102),(2352,'BS4440',22,'Evolution - 004',25,4,'Winter 2019','TBA',900687,101102),(2353,'BS4470',15,'Ecology - 001',25,4,'Spring 2019','TBA',900688,101102),(2354,'BS4470',25,'Ecology - 002',25,4,'Summer 2019','TBA',900688,101102),(2355,'BS4470',20,'Ecology - 003',25,4,'Fall 2019','TBA',900688,101102),(2356,'BS4470',29,'Ecology - 004',25,4,'Winter 2019','TBA',900688,101102),(2357,'BS2490',56,'Environmental Science - 001',25,4,'Spring 2019','TBA',900689,101102),(2358,'BS2490',55,'Environmental Science - 002',25,4,'Summer 2019','TBA',900689,101102),(2359,'BS2490',21,'Environmental Science - 003',25,4,'Fall 2019','TBA',900689,101102),(2360,'BS2490',22,'Environmental Science - 004',25,4,'Winter 2019','TBA',900689,101102),(2361,'BS3450',51,'Plant Biology - 001',25,4,'Spring 2019','TBA',900690,101102),(2362,'BS3450',48,'Plant Biology - 002',25,4,'Summer 2019','TBA',900690,101102),(2363,'BS3450',29,'Plant Biology - 003',25,4,'Fall 2019','TBA',900690,101102),(2364,'BS3450',12,'Plant Biology - 004',25,4,'Winter 2019','TBA',900690,101102),(2365,'BS3510',52,'Parasitology  - 001',25,4,'Spring 2019','TBA',900691,101102),(2366,'BS3510',13,'Parasitology  - 002',25,4,'Summer 2019','TBA',900691,101102),(2367,'BS3510',14,'Parasitology  - 003',25,4,'Fall 2019','TBA',900691,101102),(2368,'BS3510',44,'Parasitology  - 004',25,4,'Winter 2019','TBA',900691,101102),(2369,'BS3520',22,'Comparative Anatomy  - 001',25,4,'Spring 2019','TBA',900692,101102),(2370,'BS3520',49,'Comparative Anatomy  - 002',25,4,'Summer 2019','TBA',900692,101102),(2371,'BS3520',24,'Comparative Anatomy  - 003',25,4,'Fall 2019','TBA',900692,101102),(2372,'BS3520',36,'Comparative Anatomy  - 004',25,4,'Winter 2019','TBA',900692,101102),(2373,'BS3530',12,'Comparative Genomics  - 001',25,4,'Spring 2019','TBA',900693,101102),(2374,'BS3530',54,'Comparative Genomics  - 002',25,4,'Summer 2019','TBA',900693,101102),(2375,'BS3530',29,'Comparative Genomics  - 003',25,4,'Fall 2019','TBA',900693,101102),(2376,'BS3530',25,'Comparative Genomics  - 004',25,4,'Winter 2019','TBA',900693,101102),(2377,'BS3450',45,'Plant Biology - 001',25,4,'Spring 2019','TBA',900694,101102),(2378,'BS3450',53,'Plant Biology - 002',25,4,'Summer 2019','TBA',900694,101102),(2379,'BS3450',50,'Plant Biology - 003',25,4,'Fall 2019','TBA',900694,101102),(2380,'BS3450',28,'Plant Biology - 004',25,4,'Winter 2019','TBA',900694,101102),(2381,'BS3500',36,'Invertebrate Zoology - 001',25,4,'Spring 2019','TBA',900695,101102),(2382,'BS3500',37,'Invertebrate Zoology - 002',25,4,'Summer 2019','TBA',900695,101102),(2383,'BS3500',17,'Invertebrate Zoology - 003',25,4,'Fall 2019','TBA',900695,101102),(2384,'BS3500',24,'Invertebrate Zoology - 004',25,4,'Winter 2019','TBA',900695,101102),(2385,'BS5591',12,'Environmental Research - 001',25,4,'Spring 2019','TBA',900696,101102),(2386,'BS5591',35,'Environmental Research - 002',25,4,'Summer 2019','TBA',900696,101102),(2387,'BS5591',11,'Environmental Research - 003',25,4,'Fall 2019','TBA',900696,101102),(2388,'BS5591',37,'Environmental Research - 004',25,4,'Winter 2019','TBA',900696,101102),(2389,'BS3400',53,'Vertebrate Physiology - 001',25,4,'Spring 2019','TBA',900697,101102),(2390,'BS3400',34,'Vertebrate Physiology - 002',25,4,'Summer 2019','TBA',900697,101102),(2391,'BS3400',46,'Vertebrate Physiology - 003',25,4,'Fall 2019','TBA',900697,101102),(2392,'BS3400',57,'Vertebrate Physiology - 004',25,4,'Winter 2019','TBA',900697,101102),(2393,'BS3520',46,'Comparative Anatomy - 001',25,4,'Spring 2019','TBA',900698,101102),(2394,'BS3520',34,'Comparative Anatomy - 002',25,4,'Summer 2019','TBA',900698,101102),(2395,'BS3520',38,'Comparative Anatomy - 003',25,4,'Fall 2019','TBA',900698,101102),(2396,'BS3520',48,'Comparative Anatomy - 004',25,4,'Winter 2019','TBA',900698,101102),(2397,'PE2300',30,'Introduction to Law - 001',25,4,'Spring 2019','TBA',900699,10112),(2398,'PE2300',37,'Introduction to Law - 002',25,4,'Summer 2019','TBA',900699,10112),(2399,'PE2300',15,'Introduction to Law - 003',25,4,'Fall 2019','TBA',900699,10112),(2400,'PE2300',27,'Introduction to Law - 004',25,4,'Winter 2019','TBA',900699,10112),(2401,'PE2420',42,'Principles of Microeconomics - 001',25,4,'Spring 2019','TBA',900700,10112),(2402,'PE2420',38,'Principles of Microeconomics - 002',25,4,'Summer 2019','TBA',900700,10112),(2403,'PE2420',12,'Principles of Microeconomics - 003',25,4,'Fall 2019','TBA',900700,10112),(2404,'PE2420',17,'Principles of Microeconomics - 004',25,4,'Winter 2019','TBA',900700,10112),(2405,'PE2430',19,'Principles of Macroeconomics - 001',25,4,'Spring 2019','TBA',900701,10112),(2406,'PE2430',19,'Principles of Macroeconomics - 002',25,4,'Summer 2019','TBA',900701,10112),(2407,'PE2430',17,'Principles of Macroeconomics - 003',25,4,'Fall 2019','TBA',900701,10112),(2408,'PE2430',51,'Principles of Macroeconomics - 004',25,4,'Winter 2019','TBA',900701,10112),(2409,'PE2650',26,'Introduction to U.S. Politics - 001',25,4,'Spring 2019','TBA',900702,10112),(2410,'PE2650',47,'Introduction to U.S. Politics - 002',25,4,'Summer 2019','TBA',900702,10112),(2411,'PE2650',25,'Introduction to U.S. Politics - 003',25,4,'Fall 2019','TBA',900702,10112),(2412,'PE2650',11,'Introduction to U.S. Politics - 004',25,4,'Winter 2019','TBA',900702,10112),(2413,'PE2220',59,'Introduction to Urban Issues - 001',25,4,'Spring 2019','TBA',900703,10112),(2414,'PE2220',48,'Introduction to Urban Issues - 002',25,4,'Summer 2019','TBA',900703,10112),(2415,'PE2220',40,'Introduction to Urban Issues - 003',25,4,'Fall 2019','TBA',900703,10112),(2416,'PE2220',22,'Introduction to Urban Issues - 004',25,4,'Winter 2019','TBA',900703,10112),(2417,'PE2400',36,'Introduction to Political Economy - 001',25,4,'Spring 2019','TBA',900704,10112),(2418,'PE2400',14,'Introduction to Political Economy - 002',25,4,'Summer 2019','TBA',900704,10112),(2419,'PE2400',50,'Introduction to Political Economy - 003',25,4,'Fall 2019','TBA',900704,10112),(2420,'PE2400',14,'Introduction to Political Economy - 004',25,4,'Winter 2019','TBA',900704,10112),(2421,'PE3100',51,'International Relations - 001',25,4,'Spring 2019','TBA',900705,10112),(2422,'PE3100',42,'International Relations - 002',25,4,'Summer 2019','TBA',900705,10112),(2423,'PE3100',13,'International Relations - 003',25,4,'Fall 2019','TBA',900705,10112),(2424,'PE3100',43,'International Relations - 004',25,4,'Winter 2019','TBA',900705,10112),(2425,'PE3400',37,'Political Economy of the Global South - 001',25,4,'Spring 2019','TBA',900706,10112),(2426,'PE3400',28,'Political Economy of the Global South - 002',25,4,'Summer 2019','TBA',900706,10112),(2427,'PE3400',33,'Political Economy of the Global South - 003',25,4,'Fall 2019','TBA',900706,10112),(2428,'PE3400',44,'Political Economy of the Global South - 004',25,4,'Winter 2019','TBA',900706,10112),(2429,'PE3410',46,'U.S. Political Economy - 001',25,4,'Spring 2019','TBA',900707,10112),(2430,'PE3410',23,'U.S. Political Economy - 002',25,4,'Summer 2019','TBA',900707,10112),(2431,'PE3410',26,'U.S. Political Economy - 003',25,4,'Fall 2019','TBA',900707,10112),(2432,'PE3410',35,'U.S. Political Economy - 004',25,4,'Winter 2019','TBA',900707,10112),(2433,'PE4320',45,'Jurisprudence: Legal Thought - 001',25,4,'Spring 2019','TBA',900708,10112),(2434,'PE4320',28,'Jurisprudence: Legal Thought - 002',25,4,'Summer 2019','TBA',900708,10112),(2435,'PE4320',13,'Jurisprudence: Legal Thought - 003',25,4,'Fall 2019','TBA',900708,10112),(2436,'PE4320',28,'Jurisprudence: Legal Thought - 004',25,4,'Winter 2019','TBA',900708,10112),(2437,'PE4470',13,'History of Economic Thought - 001',25,4,'Spring 2019','TBA',900709,10112),(2438,'PE4470',21,'History of Economic Thought - 002',25,4,'Summer 2019','TBA',900709,10112),(2439,'PE4470',51,'History of Economic Thought - 003',25,4,'Fall 2019','TBA',900709,10112),(2440,'PE4470',54,'History of Economic Thought - 004',25,4,'Winter 2019','TBA',900709,10112),(2441,'PE4620',14,'Political and Social Thought - 001',25,4,'Spring 2019','TBA',900710,10112),(2442,'PE4620',16,'Political and Social Thought - 002',25,4,'Summer 2019','TBA',900710,10112),(2443,'PE4620',44,'Political and Social Thought - 003',25,4,'Fall 2019','TBA',900710,10112),(2444,'PE4620',27,'Political and Social Thought - 004',25,4,'Winter 2019','TBA',900710,10112),(2445,'PE4580',56,'Origins of the Capitalist Economy - 001',25,4,'Spring 2019','TBA',900711,10112),(2446,'PE4580',19,'Origins of the Capitalist Economy - 002',25,4,'Summer 2019','TBA',900711,10112),(2447,'PE4580',34,'Origins of the Capitalist Economy - 003',25,4,'Fall 2019','TBA',900711,10112),(2448,'PE4580',34,'Origins of the Capitalist Economy - 004',25,4,'Winter 2019','TBA',900711,10112),(2449,'PE4590',44,'Global Economy in the 20th Century - 001',25,4,'Spring 2019','TBA',900712,10112),(2450,'PE4590',48,'Global Economy in the 20th Century - 002',25,4,'Summer 2019','TBA',900712,10112),(2451,'PE4590',26,'Global Economy in the 20th Century - 003',25,4,'Fall 2019','TBA',900712,10112),(2452,'PE4590',13,'Global Economy in the 20th Century - 004',25,4,'Winter 2019','TBA',900712,10112),(2453,'PE3160',58,'Ethnopolitics in the World - 001',25,4,'Spring 2019','TBA',900713,10112),(2454,'PE3160',21,'Ethnopolitics in the World - 002',25,4,'Summer 2019','TBA',900713,10112),(2455,'PE3160',55,'Ethnopolitics in the World - 003',25,4,'Fall 2019','TBA',900713,10112),(2456,'PE3160',48,'Ethnopolitics in the World - 004',25,4,'Winter 2019','TBA',900713,10112),(2457,'PE3250',56,'Topics in Latin American Politics - 001',25,4,'Spring 2019','TBA',900714,10112),(2458,'PE3250',57,'Topics in Latin American Politics - 002',25,4,'Summer 2019','TBA',900714,10112),(2459,'PE3250',23,'Topics in Latin American Politics - 003',25,4,'Fall 2019','TBA',900714,10112),(2460,'PE3250',34,'Topics in Latin American Politics - 004',25,4,'Winter 2019','TBA',900714,10112),(2461,'PE4100',13,'International Organizations - 001',25,4,'Spring 2019','TBA',900715,10112),(2462,'PE4100',15,'International Organizations - 002',25,4,'Summer 2019','TBA',900715,10112),(2463,'PE4100',22,'International Organizations - 003',25,4,'Fall 2019','TBA',900715,10112),(2464,'PE4100',20,'International Organizations - 004',25,4,'Winter 2019','TBA',900715,10112),(2465,'PE4325',42,'Jurisprudence: Legal Thought - 001',25,4,'Spring 2019','TBA',900716,10112),(2466,'PE4325',11,'Jurisprudence: Legal Thought - 002',25,4,'Summer 2019','TBA',900716,10112),(2467,'PE4325',55,'Jurisprudence: Legal Thought - 003',25,4,'Fall 2019','TBA',900716,10112),(2468,'PE4325',21,'Jurisprudence: Legal Thought - 004',25,4,'Winter 2019','TBA',900716,10112),(2469,'PE5990',47,'Internship - 001',25,4,'Spring 2019','TBA',900717,10112),(2470,'PE5990',16,'Internship - 002',25,4,'Summer 2019','TBA',900717,10112),(2471,'PE5990',55,'Internship - 003',25,4,'Fall 2019','TBA',900717,10112),(2472,'PE5990',42,'Internship - 004',25,4,'Winter 2019','TBA',900717,10112),(2473,'CL2000',31,'Community Learning  - 001',25,4,'Spring 2019','TBA',900718,101109),(2474,'CL2000',48,'Community Learning  - 002',25,4,'Summer 2019','TBA',900718,101109),(2475,'CL2000',42,'Community Learning  - 003',25,4,'Fall 2019','TBA',900718,101109),(2476,'CL2000',37,'Community Learning  - 004',25,4,'Winter 2019','TBA',900718,101109),(2477,'CL2010',40,'Community Learning  - 001',25,4,'Spring 2019','TBA',900719,101109),(2478,'CL2010',51,'Community Learning  - 002',25,4,'Summer 2019','TBA',900719,101109),(2479,'CL2010',21,'Community Learning  - 003',25,4,'Fall 2019','TBA',900719,101109),(2480,'CL2010',13,'Community Learning  - 004',25,4,'Winter 2019','TBA',900719,101109),(2481,'CL2020',49,'Community Learning  - 001',25,4,'Spring 2019','TBA',900720,101109),(2482,'CL2020',16,'Community Learning  - 002',25,4,'Summer 2019','TBA',900720,101109),(2483,'CL2020',25,'Community Learning  - 003',25,4,'Fall 2019','TBA',900720,101109),(2484,'CL2020',32,'Community Learning  - 004',25,4,'Winter 2019','TBA',900720,101109),(2485,'CL2030',40,'Community Learning  - 001',25,4,'Spring 2019','TBA',900721,101109),(2486,'CL2030',46,'Community Learning  - 002',25,4,'Summer 2019','TBA',900721,101109),(2487,'CL2030',51,'Community Learning  - 003',25,4,'Fall 2019','TBA',900721,101109),(2488,'CL2030',34,'Community Learning  - 004',25,4,'Winter 2019','TBA',900721,101109),(2489,'CL2040',57,'Community Learning  - 001',25,4,'Spring 2019','TBA',900722,101109),(2490,'CL2040',38,'Community Learning  - 002',25,4,'Summer 2019','TBA',900722,101109),(2491,'CL2040',44,'Community Learning  - 003',25,4,'Fall 2019','TBA',900722,101109),(2492,'CL2040',17,'Community Learning  - 004',25,4,'Winter 2019','TBA',900722,101109),(2494,'test',3,'test',24,4,'Winter 2019','ABC123',12,101107),(2495,'test',3,'test',24,4,'Winter 2019','ABC123',12,101107),(2496,'test',3,'test',24,4,'Winter 2019','ABC123',12,101107),(2497,'theclass',7,'theclass',24,4,'Summer 2019','theclass',12,101110),(2498,'theclass',7,'theclass',24,4,'Summer 2019','theclass',12,101110),(2499,'theclasssss',8,'theclasssss',12,4,'Summer 2019','theclasssss',23,101107),(2500,'theclasssss',8,'theclasssss',12,4,'Summer 2019','theclasssss',23,101107),(2501,'PRE100',15,'prereq test - 002',24,4,'Summer 2019','This is to test the prerequisit function',45,101106);
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dayy`
--

DROP TABLE IF EXISTS `dayy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dayy` (
  `Day_ID` int(11) NOT NULL,
  PRIMARY KEY (`Day_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dayy`
--

LOCK TABLES `dayy` WRITE;
/*!40000 ALTER TABLE `dayy` DISABLE KEYS */;
/*!40000 ALTER TABLE `dayy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `Department_ID` int(11) NOT NULL,
  `Dept_Chair` varchar(255) DEFAULT NULL,
  `Department_Name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Department_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` (`Department_ID`, `Dept_Chair`, `Department_Name`) VALUES (10112,'Beryl Simpson','Politics Economics & Law'),(10113,'Jerome Jenner','Psychology'),(10114,'Timothy Woods','Public Health'),(10115,'Robert Hebert','School of business'),(10116,'Nerissa Blake','school of Education'),(10117,'Wendy Mcdonald','Sociology'),(10118,'Trevor Sony','School of Professional Studies'),(10119,'Yuly Hernandez','Visual Arts'),(101101,'Matt Smith','American Studies'),(101102,'Paula Jones','Biological Sciences'),(101103,'Kevin Matthews','Chemistry and Physics'),(101104,'James Peters','Computer Science'),(101105,'Oliver Green','English'),(101106,'Rebecca Thompson','History and Philosophy'),(101107,'Alexia Francis','Criminology'),(101108,'Ashley Simms','Industrial & Labor Relations'),(101109,'Tony Chambers','Liberal Studies'),(101110,'Dean Small','Mathematics'),(101111,'Maureen Rowe','Modern Languages');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enrollment`
--

DROP TABLE IF EXISTS `enrollment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enrollment` (
  `Student_ID` int(11) NOT NULL,
  `Course_ID` varchar(255) DEFAULT NULL,
  `P_Name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Student_ID`),
  CONSTRAINT `enrollment_ibfk_1` FOREIGN KEY (`Student_ID`) REFERENCES `student` (`Student_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enrollment`
--

LOCK TABLES `enrollment` WRITE;
/*!40000 ALTER TABLE `enrollment` DISABLE KEYS */;
/*!40000 ALTER TABLE `enrollment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculty` (
  `Faculty_ID` int(11) NOT NULL,
  `Faculty_Name` varchar(30) DEFAULT NULL,
  `Faculty_Number` varchar(30) NOT NULL,
  PRIMARY KEY (`Faculty_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculty`
--

LOCK TABLES `faculty` WRITE;
/*!40000 ALTER TABLE `faculty` DISABLE KEYS */;
INSERT INTO `faculty` (`Faculty_ID`, `Faculty_Name`, `Faculty_Number`) VALUES (900100,'Albie Hayward','(800) 317-0062'),(900101,'Aeryn Dunne','(800) 615-9425'),(900102,'Antoni Squires','(800)  697-2157'),(900103,'Mohammad Langley','(800)  469-6113'),(900104,'Izabel Bright','(800) 420-5653'),(900105,'Zunairah Neale','(800) 731-9102'),(900106,'Pascal Sparks','(800)  332-7338'),(900107,'Cecily Tillman','(800)  711-4169'),(900108,'Rafi Pena','(800) 761-8071'),(900109,'Mohamad Sargent','(800) 384-9398'),(900110,'Israel Palacios','(800)  405-0982'),(900111,'Ameera Healy','(800) 954-8173'),(900112,'Malak Boyle','(800)  733-8473'),(900113,'India Pittman','(800)  512-9953'),(900114,'Waseem Bain','(800) 725-6354'),(900115,'Alejandro Frazier','(800)  734-8989'),(900116,'Kaisha Schneider','(800)  203-8484'),(900117,'Gerrard Medina','(800)  985-4578'),(900118,'Iolo Aguirre','(800)  997-1326'),(900119,'Rick Bishop','(800) 532-4159'),(900120,'Skylah Firth','(800)  715-6795'),(900121,'Juliette Blair','(800)  332-1629'),(900122,'Darrell Rice','(800)  299-0143'),(900123,'Ayub Blackburn','(800)  933-8798'),(900124,'Ebony Martins','(800)  594-0991'),(900125,'Aayush Paterson','(800)  693-5628'),(900126,'Kaci Bradley','(800)  444-4662'),(900127,'Ella-Mai Galindo','(800)  560-1392'),(900128,'Esme-Rose Diaz','(800) 595-6603'),(900129,'Hasnain Hibbert','(800) 760-5450'),(900130,'Sanjay Patel','(800)  884-8561'),(900131,'Keeley Robson','(800)  810-9838'),(900132,'Issa Benton','(800)  547-5232'),(900133,'Emilee Mcgowan','(800)  686-5816'),(900134,'Domas Humphries','(800)  237-6699'),(900135,'Jevan Gilmour','(800)  766-8775'),(900136,'Blade Sharp','(800)  472-6706'),(900137,'Carlton Moore','(800)  335-4840'),(900138,'Brett Melia','(800)  255-7900'),(900139,'Aston Horne','(800)  484-5334'),(900140,'Arnas Hood','(800)  561-7301'),(900141,'Angelina Cabrera','(800)  531-2114'),(900142,'Shaan Levine','(800)  546-7442'),(900143,'Clement Orr','(800)  677-6182'),(900144,'Jarrad Durham','(800)  968-7076'),(900145,'Timur Koch','(800) 324-8639'),(900146,'Ariel Palmer','(800)  203-1881'),(900147,'Cherry Sanders','(800)  731-5450'),(900148,'Tamsin Heaton','(800)  901-7553'),(900149,'Thelma Fenton','(800)  492-0114'),(900150,'Norma Richmond','(800)  366-5130'),(900151,'Seth Gibson','(800)  283-2060'),(900152,'Codie Mcfarland','(800)  688-4058'),(900153,'Hester Guerrero','(800)  512-9205'),(900154,'Eden Gentry','(800)  673-5355'),(900155,'Hallie Crouch','(800)   233-8531'),(900156,'Kirsty Ellwood','(800)  951-8002'),(900157,'Noel Carey','(800)  893-4309'),(900158,'Bentley Stacey','(800)    824-6806'),(900159,'Ptolemy Portillo','(800)     990-0937'),(900160,'Shannon Huynh','(800)   496-1206'),(900161,'Ehsan Mccall','(800)   640-3928'),(900162,'Kelan Doherty','(800)   848-5719'),(900163,'Elisabeth O Gallagher','(800)   954-4237'),(900164,'Waleed Booth','(800)   554-8225'),(900165,'Ibrahim Emery','(800)   598-1921'),(900166,'Corrie Kumar','(800)   932-1772'),(900167,'Mylo O Moore','(800)    743-7699'),(900168,'Jameel Mckinney','(800)   720-2300'),(900169,'Zion Yu','(800)   655-5269'),(900170,'Mack Everett','(800)   864-7106'),(900171,'Dafydd Hanna','(800)  771-0220'),(900172,'Naima Ferrell','(800)   372-3300'),(900173,'Eloisa Mcgregor','(800)   393-6296'),(900174,'Juno Finley','(800)   545-7876'),(900175,'Jadene Dunkley','(800)   696-2856'),(900176,'Anisah Park','(800)  470-1132'),(900177,'Mayur Padilla','(800)   454-6735'),(900178,'Caiden Chester','(800)   477-1543'),(900179,'Gage Rooney','(800)   250-0754'),(900180,'Talhah Mccann','(800)   289-2231'),(900181,'Bella Myers','(800)   697-6751'),(900182,'Lianne Burch','(800)   357-4799'),(900183,'Ronald Finney','(800)   883-0748'),(900184,'Garry Nicholson','(800)   666-1372'),(900185,'Lilly-Mai Macdonald','(800)   948-7312'),(900186,'Johan Wood','(800)   232-2197'),(900187,'Libbie Webber','(800)  562-4400'),(900188,'Chaya Povey','(800)  896-9722'),(900189,'Juliet Hunt','(800)  432-3109'),(900190,'Derren Pearson','(800)   455-2277'),(900191,'Stefanie Bond','(800)   812-8700'),(900192,'Garrett Easton','(800)   385-0943'),(900193,'Zunaira Haynes','(800)   458-2694'),(900194,'Summer Gilmore','(800)   695-0511'),(900195,'Noa Freeman','(800)   425-7442'),(900196,'Madeleine Broughton','955-0885'),(900197,'Libbi Churchill','(800)   249-5222'),(900198,'Waqas Tran','(800)    278-8297'),(900199,'Rhia Goldsmith','(800)   410-9696 ');
/*!40000 ALTER TABLE `faculty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facultyfulltime`
--

DROP TABLE IF EXISTS `facultyfulltime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facultyfulltime` (
  `Faculty_ID` int(11) DEFAULT NULL,
  UNIQUE KEY `Faculty_ID` (`Faculty_ID`),
  CONSTRAINT `facultyfulltime_ibfk_1` FOREIGN KEY (`Faculty_ID`) REFERENCES `faculty` (`Faculty_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facultyfulltime`
--

LOCK TABLES `facultyfulltime` WRITE;
/*!40000 ALTER TABLE `facultyfulltime` DISABLE KEYS */;
INSERT INTO `facultyfulltime` (`Faculty_ID`) VALUES (900101),(900102),(900103),(900104),(900105),(900106),(900107),(900108),(900109),(900110),(900111),(900112),(900113),(900114),(900115),(900116),(900117),(900118),(900119),(900120),(900121),(900122),(900123),(900124),(900125),(900126),(900127),(900128),(900129),(900130),(900131),(900132),(900133),(900134),(900135),(900136),(900137),(900138),(900139),(900140),(900141),(900142),(900143),(900144),(900145),(900146),(900147),(900148),(900149),(900150),(900151),(900152),(900153),(900154),(900155),(900156),(900157),(900158),(900159),(900160),(900161),(900162),(900163),(900164),(900165),(900166),(900167),(900168),(900169),(900170),(900171),(900172),(900173),(900174),(900175),(900176),(900177),(900178),(900179),(900180),(900181),(900182),(900183),(900184),(900185),(900186),(900187),(900188),(900189),(900190),(900191),(900192),(900193),(900194),(900195),(900196),(900197),(900198),(900199);
/*!40000 ALTER TABLE `facultyfulltime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facultyparttime`
--

DROP TABLE IF EXISTS `facultyparttime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facultyparttime` (
  `Faculty_ID` int(11) NOT NULL,
  UNIQUE KEY `Faculty_ID` (`Faculty_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facultyparttime`
--

LOCK TABLES `facultyparttime` WRITE;
/*!40000 ALTER TABLE `facultyparttime` DISABLE KEYS */;
INSERT INTO `facultyparttime` (`Faculty_ID`) VALUES (900000),(900001),(900002),(900003),(900004),(900005),(900006),(900007),(900008),(900009),(900010),(900011),(900012),(900013),(900014),(900015),(900016),(900017),(900018),(900019),(900020),(900021),(900022),(900023),(900024),(900025),(900026),(900027),(900028),(900029),(900030),(900031),(900032),(900033),(900034),(900035),(900036),(900037),(900038),(900039),(900040),(900041),(900042),(900043),(900044),(900045),(900046),(900047),(900048),(900049),(900050),(900051),(900052),(900053),(900054),(900055),(900056),(900057),(900058),(900059),(900060),(900061),(900062),(900063),(900064),(900065),(900066),(900067),(900068),(900069),(900070),(900071),(900072),(900073),(900074),(900075),(900076),(900077),(900078),(900079),(900080),(900081),(900082),(900083),(900084),(900085),(900086),(900087),(900088),(900089),(900090),(900091),(900092),(900093),(900094),(900095),(900096),(900097),(900098),(900099),(900100);
/*!40000 ALTER TABLE `facultyparttime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `general_education`
--

DROP TABLE IF EXISTS `general_education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `general_education` (
  `entry_number` int(30) NOT NULL AUTO_INCREMENT,
  `Course_ID` int(30) NOT NULL,
  PRIMARY KEY (`entry_number`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `general_education`
--

LOCK TABLES `general_education` WRITE;
/*!40000 ALTER TABLE `general_education` DISABLE KEYS */;
INSERT INTO `general_education` (`entry_number`, `Course_ID`) VALUES (1,173),(2,2),(3,2441),(4,101),(5,317),(6,369),(7,379),(8,457),(9,465),(10,801),(11,1825),(12,1969),(13,2085),(14,2197);
/*!40000 ALTER TABLE `general_education` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grades`
--

DROP TABLE IF EXISTS `grades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grades` (
  `Student_ID` int(11) DEFAULT NULL,
  `Grades` varchar(255) DEFAULT NULL,
  `Course_ID` int(30) NOT NULL,
  `Semester` varchar(255) NOT NULL,
  KEY `Student_ID` (`Student_ID`),
  CONSTRAINT `grades_ibfk_1` FOREIGN KEY (`Student_ID`) REFERENCES `student` (`Student_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grades`
--

LOCK TABLES `grades` WRITE;
/*!40000 ALTER TABLE `grades` DISABLE KEYS */;
/*!40000 ALTER TABLE `grades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `graduate`
--

DROP TABLE IF EXISTS `graduate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `graduate` (
  `Student_ID` int(11) NOT NULL,
  KEY `graduate_ibfk_1` (`Student_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `graduate`
--

LOCK TABLES `graduate` WRITE;
/*!40000 ALTER TABLE `graduate` DISABLE KEYS */;
INSERT INTO `graduate` (`Student_ID`) VALUES (700000151),(700000152),(700000153),(700000154),(700000155),(700000156),(700000157),(700000158),(700000159),(700000160),(700000161),(700000162),(700000163),(700000164),(700000165),(700000166),(700000167),(700000168),(700000169),(700000170),(700000171),(700000172),(700000173),(700000174),(700000175),(700000176),(700000177),(700000178),(700000179),(700000180),(700000181),(700000182),(700000183),(700000184),(700000185),(700000186),(700000187),(700000188),(700000189),(700000190),(700000191),(700000192),(700000193),(700000194),(700000195),(700000196),(700000197),(700000198),(700000199),(700000200),(700000201),(700000202),(700000203),(700000204),(700000205),(700000206),(700000207),(700000208),(700000209),(700000210),(700000211),(700000212),(700000213),(700000214),(700000215),(700000216),(700000217),(700000218),(700000219),(700000220),(700000221),(700000222),(700000223),(700000224),(700000225),(700000226),(700000227),(700000228),(700000229),(700000230),(700000231),(700000232),(700000233),(700000234),(700000235),(700000236),(700000237),(700000238),(700000239),(700000240),(700000241),(700000242),(700000243),(700000244),(700000245),(700000246),(700000247),(700000248),(700000249),(700000250),(700000251),(700000252),(700000253),(700000254),(700000255),(700000256),(700000257),(700000258),(700000259),(700000260),(700000261),(700000262),(700000263),(700000264),(700000265),(700000266),(700000267),(700000268),(700000269),(700000270),(700000271),(700000272),(700000273),(700000274),(700000275),(700000276),(700000277),(700000278),(700000279),(700000280),(700000281),(700000282),(700000283),(700000284),(700000285),(700000286),(700000287),(700000288),(700000289),(700000290),(700000291),(700000292),(700000293),(700000294),(700000295),(700000296),(700000297),(700000298),(700000299);
/*!40000 ALTER TABLE `graduate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holds`
--

DROP TABLE IF EXISTS `holds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `holds` (
  `Hold_ID` int(11) NOT NULL,
  `Description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Hold_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holds`
--

LOCK TABLES `holds` WRITE;
/*!40000 ALTER TABLE `holds` DISABLE KEYS */;
INSERT INTO `holds` (`Hold_ID`, `Description`) VALUES (4331,'Academic'),(4332,'Administration'),(4333,'Athlete'),(4334,'Disciplinary'),(4335,'Financial');
/*!40000 ALTER TABLE `holds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `major`
--

DROP TABLE IF EXISTS `major`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `major` (
  `Major_ID` int(11) NOT NULL,
  `Major_Name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Major_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `major`
--

LOCK TABLES `major` WRITE;
/*!40000 ALTER TABLE `major` DISABLE KEYS */;
INSERT INTO `major` (`Major_ID`, `Major_Name`) VALUES (1700,'American Studies'),(1701,'Biological Sciences'),(1702,'Chemistry and Physics'),(1703,'Computer Science'),(1704,'Criminology'),(1705,'English'),(1706,'History and Philosophy'),(1707,'Industrial & Labor Relations'),(1708,'Liberal Studies'),(1709,'Mathematics'),(1710,'Modern Languages'),(1711,'Politics Economics & Law'),(1712,'Psychology'),(1713,'Public Health'),(1714,'School of Business'),(1715,'School of Education'),(1716,'School of Professional Studies'),(1717,'Sociology'),(1718,'Visual Arts');
/*!40000 ALTER TABLE `major` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `minor`
--

DROP TABLE IF EXISTS `minor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `minor` (
  `Minor_ID` int(11) NOT NULL,
  `Minor_Name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Minor_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `minor`
--

LOCK TABLES `minor` WRITE;
/*!40000 ALTER TABLE `minor` DISABLE KEYS */;
INSERT INTO `minor` (`Minor_ID`, `Minor_Name`) VALUES (1501,'Biological Sciences'),(1502,'Chemistry and Physics'),(1503,'Computer Science'),(1504,'Criminology'),(1505,'English'),(1506,'History and Philosophy'),(1507,'Industrial & Labor Relations'),(1508,'Liberal Studies'),(1509,'Mathematics'),(1510,'Modern Languages'),(1511,'Politics Economics & Law'),(1512,'Psychology'),(1513,'Public Health'),(1514,'School of Business'),(1515,'School of Education'),(1516,'School of Professional Studies'),(1517,'Sociology'),(1518,'Visual Arts');
/*!40000 ALTER TABLE `minor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__bookmark`
--

DROP TABLE IF EXISTS `pma__bookmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__bookmark` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__bookmark`
--

LOCK TABLES `pma__bookmark` WRITE;
/*!40000 ALTER TABLE `pma__bookmark` DISABLE KEYS */;
INSERT INTO `pma__bookmark` (`id`, `dbase`, `user`, `label`, `query`) VALUES (1,'g6','cpses_fmyshuhziv','update departments','UPDATE course\r\nSET \r\n    Department_ID = 101101\r\nWHERE\r\n    Course_ID BETWEEN 309 AND 472;'),(2,'g6','cpses_fm89ejc8q0','update departments','SELECT * FROM `course` WHERE 1');
/*!40000 ALTER TABLE `pma__bookmark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__central_columns`
--

DROP TABLE IF EXISTS `pma__central_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin,
  PRIMARY KEY (`db_name`,`col_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__central_columns`
--

LOCK TABLES `pma__central_columns` WRITE;
/*!40000 ALTER TABLE `pma__central_columns` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__central_columns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__column_info`
--

DROP TABLE IF EXISTS `pma__column_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__column_info` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__column_info`
--

LOCK TABLES `pma__column_info` WRITE;
/*!40000 ALTER TABLE `pma__column_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__column_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__designer_settings`
--

DROP TABLE IF EXISTS `pma__designer_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__designer_settings`
--

LOCK TABLES `pma__designer_settings` WRITE;
/*!40000 ALTER TABLE `pma__designer_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__designer_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__export_templates`
--

DROP TABLE IF EXISTS `pma__export_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__export_templates` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__export_templates`
--

LOCK TABLES `pma__export_templates` WRITE;
/*!40000 ALTER TABLE `pma__export_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__export_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__favorite`
--

DROP TABLE IF EXISTS `pma__favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__favorite`
--

LOCK TABLES `pma__favorite` WRITE;
/*!40000 ALTER TABLE `pma__favorite` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__history`
--

DROP TABLE IF EXISTS `pma__history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sqlquery` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`,`db`,`table`,`timevalue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__history`
--

LOCK TABLES `pma__history` WRITE;
/*!40000 ALTER TABLE `pma__history` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__navigationhiding`
--

DROP TABLE IF EXISTS `pma__navigationhiding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__navigationhiding`
--

LOCK TABLES `pma__navigationhiding` WRITE;
/*!40000 ALTER TABLE `pma__navigationhiding` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__navigationhiding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__pdf_pages`
--

DROP TABLE IF EXISTS `pma__pdf_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT '',
  PRIMARY KEY (`page_nr`),
  KEY `db_name` (`db_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__pdf_pages`
--

LOCK TABLES `pma__pdf_pages` WRITE;
/*!40000 ALTER TABLE `pma__pdf_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__pdf_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__recent`
--

DROP TABLE IF EXISTS `pma__recent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__recent`
--

LOCK TABLES `pma__recent` WRITE;
/*!40000 ALTER TABLE `pma__recent` DISABLE KEYS */;
INSERT INTO `pma__recent` (`username`, `tables`) VALUES ('cpses_fm0t112x3w','[{\"db\":\"g6\",\"table\":\"users\"}]'),('cpses_fm16cf2pkx','[{\"db\":\"g6\",\"table\":\"transcript\"},{\"db\":\"g6\",\"table\":\"History_Major\"}]'),('cpses_fm1af2bu0c','[{\"db\":\"g6\",\"table\":\"transcript\"}]'),('cpses_fm2c1qtmwm','[{\"db\":\"g6\",\"table\":\"advisor\"}]'),('cpses_fm2h0di3jp','[{\"db\":\"g6\",\"table\":\"student\"},{\"db\":\"g6\",\"table\":\"holds\"},{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"transcript\"}]'),('cpses_fm2xld27b9','[{\"db\":\"g6\",\"table\":\"History_Major\"},{\"db\":\"g6\",\"table\":\"CS_Major\"},{\"db\":\"g6\",\"table\":\"prerequisite\"},{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"transcript\"},{\"db\":\"g6\",\"table\":\"users\"}]'),('cpses_fm3eruq4kp','[{\"db\":\"g6\",\"table\":\"student\"},{\"db\":\"g6\",\"table\":\"schedulee\"},{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"course\"}]'),('cpses_fm4cu6ncrn','[{\"db\":\"g6\",\"table\":\"course\"}]'),('cpses_fm4lqo7o71','[{\"db\":\"g6\",\"table\":\"department\"},{\"db\":\"g6\",\"table\":\"timee\"},{\"db\":\"g6\",\"table\":\"course\"}]'),('cpses_fm6mj8jvd7','[{\"db\":\"theusers\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"grades\"},{\"db\":\"g6\",\"table\":\"professor\"},{\"db\":\"g6\",\"table\":\"userr\"},{\"db\":\"g6\",\"table\":\"semester\"},{\"db\":\"g6\",\"table\":\"timee\"}]'),('cpses_fm89ejc8q0','[{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"theusers\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"department\"},{\"db\":\"g6\",\"table\":\"timee\"}]'),('cpses_fm8nostwlp','[{\"db\":\"g6\",\"table\":\"transcript\"},{\"db\":\"g6\",\"table\":\"student\"},{\"db\":\"g6\",\"table\":\"holds\"},{\"db\":\"g6\",\"table\":\"course\"}]'),('cpses_fm9c4ltx4p','[{\"db\":\"g6\",\"table\":\"transcript\"},{\"db\":\"g6\",\"table\":\"CS_Major\"},{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"department\"},{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"History_Major\"},{\"db\":\"g6\",\"table\":\"student\"},{\"db\":\"g6\",\"table\":\"attendance\"},{\"db\":\"g6\",\"table\":\"schedulee\"}]'),('cpses_fm9twzwqak','[{\"db\":\"g6\",\"table\":\"prerequisite\"},{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"History_Major\"},{\"db\":\"g6\",\"table\":\"CS_Major\"},{\"db\":\"g6\",\"table\":\"transcript\"},{\"db\":\"g6\",\"table\":\"users\"}]'),('cpses_fmb9jgjjsq','[{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"schedulee\"},{\"db\":\"g6\",\"table\":\"timee\"},{\"db\":\"g6\",\"table\":\"student\"},{\"db\":\"g6\",\"table\":\"department\"},{\"db\":\"g6\",\"table\":\"transcript\"},{\"db\":\"g6\",\"table\":\"CS_Major\"},{\"db\":\"g6\",\"table\":\"History_Major\"}]'),('cpses_fmbh9id8yz','[{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"course\"}]'),('cpses_fmbqpz3gna','[{\"db\":\"g6\",\"table\":\"History_Major\"},{\"db\":\"g6\",\"table\":\"student\"},{\"db\":\"g6\",\"table\":\"schedulee\"},{\"db\":\"g6\",\"table\":\"users\"}]'),('cpses_fmby9s2m60','[{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"student\"},{\"db\":\"g6\",\"table\":\"faculty\"},{\"db\":\"g6\",\"table\":\"History_Major\"},{\"db\":\"g6\",\"table\":\"CS_Major\"},{\"db\":\"g6\",\"table\":\"prerequisite\"},{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"transcript\"}]'),('cpses_fmdgyfferh','[{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"student\"},{\"db\":\"g6\",\"table\":\"schedulee\"},{\"db\":\"g6\",\"table\":\"transcript\"},{\"db\":\"g6\",\"table\":\"holds\"}]'),('cpses_fmfw5ntz6c','[{\"db\":\"theusers\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"users\"}]'),('cpses_fmg854g86x','[{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"grades\"},{\"db\":\"g6\",\"table\":\"professor\"},{\"db\":\"g6\",\"table\":\"userr\"},{\"db\":\"g6\",\"table\":\"semester\"},{\"db\":\"g6\",\"table\":\"timee\"}]'),('cpses_fmh4v7fhsm','[{\"db\":\"g6\",\"table\":\"timee\"},{\"db\":\"g6\",\"table\":\"student\"}]'),('cpses_fmhnh8ex8b','[{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"student\"},{\"db\":\"g6\",\"table\":\"History_Major\"},{\"db\":\"g6\",\"table\":\"CS_Major\"},{\"db\":\"g6\",\"table\":\"prerequisite\"},{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"transcript\"}]'),('cpses_fmhpddtnfx','[{\"db\":\"g6\",\"table\":\"transcript\"}]'),('cpses_fmib8qr5rj','[{\"db\":\"g6\",\"table\":\"holds\"}]'),('cpses_fmjpzx550h','[{\"db\":\"g6\",\"table\":\"schedulee\"},{\"db\":\"g6\",\"table\":\"department\"},{\"db\":\"g6\",\"table\":\"facultyparttime\"},{\"db\":\"g6\",\"table\":\"student\"},{\"db\":\"g6\",\"table\":\"attendance\"},{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"theusers\",\"table\":\"users\"}]'),('cpses_fmk5zok44l','[{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"schedulee\"},{\"db\":\"g6\",\"table\":\"CurrentSemester\"},{\"db\":\"g6\",\"table\":\"transcript\"},{\"db\":\"g6\",\"table\":\"History_Major\"},{\"db\":\"g6\",\"table\":\"CS_Major\"},{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"prerequisite\"}]'),('cpses_fmlf94xq4r','[{\"db\":\"g6\",\"table\":\"users\"}]'),('cpses_fmokmnqzjx','[{\"db\":\"g6\",\"table\":\"transcript\"}]'),('cpses_fmpm5e7bu5','[{\"db\":\"theusers\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"timee\"},{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"department\"}]'),('cpses_fmq7bxrr98','[{\"db\":\"g6\",\"table\":\"course\"}]'),('cpses_fmqa6qdpmj','[{\"db\":\"g6\",\"table\":\"transcript\"},{\"db\":\"g6\",\"table\":\"grades\"},{\"db\":\"g6\",\"table\":\"schedulee\"},{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"student\"}]'),('cpses_fms2nyk1tl','[{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"department\"},{\"db\":\"theusers\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"timee\"}]'),('cpses_fms99z9j4x','[{\"db\":\"g6\",\"table\":\"student\"},{\"db\":\"g6\",\"table\":\"attendance\"},{\"db\":\"g6\",\"table\":\"schedulee\"},{\"db\":\"g6\",\"table\":\"course\"}]'),('cpses_fmsthtch42','[{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"student\"}]'),('cpses_fmtf6ojjkr','[{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"userr\"},{\"db\":\"g6\",\"table\":\"transcript\"},{\"db\":\"g6\",\"table\":\"timee\"},{\"db\":\"g6\",\"table\":\"student\"},{\"db\":\"g6\",\"table\":\"semester\"},{\"db\":\"g6\",\"table\":\"schedulehistory\"},{\"db\":\"g6\",\"table\":\"schedulee\"},{\"db\":\"g6\",\"table\":\"professor\"}]'),('cpses_fmu7kzn69e','[{\"db\":\"g6\",\"table\":\"History_Major\"},{\"db\":\"g6\",\"table\":\"transcript\"},{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"general_education\"}]'),('cpses_fmv5mvjo9t','[{\"db\":\"g6\",\"table\":\"transcript\"},{\"db\":\"g6\",\"table\":\"general_education\"},{\"db\":\"g6\",\"table\":\"History_Major\"},{\"db\":\"g6\",\"table\":\"course\"}]'),('cpses_fmv7oedsm9','[{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"student\"},{\"db\":\"g6\",\"table\":\"transcript\"},{\"db\":\"theusers\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"enrollment\"},{\"db\":\"g6\",\"table\":\"attendance\"},{\"db\":\"g6\",\"table\":\"CS_Major\"},{\"db\":\"g6\",\"table\":\"History_Major\"},{\"db\":\"g6\",\"table\":\"userr\"}]'),('cpses_fmw190mgna','[{\"db\":\"g6\",\"table\":\"student\"}]'),('cpses_fmxo3yzdih','[{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"transcript\"},{\"db\":\"g6\",\"table\":\"schedulee\"},{\"db\":\"g6\",\"table\":\"course\"}]'),('cpses_fmy6myjh97','[{\"db\":\"g6\",\"table\":\"holds\"}]'),('cpses_fmyshuhziv','[{\"db\":\"g6\",\"table\":\"users\"},{\"db\":\"g6\",\"table\":\"userr\"},{\"db\":\"g6\",\"table\":\"department\"},{\"db\":\"g6\",\"table\":\"course\"}]'),('omnicypher','[{\"db\":\"g6\",\"table\":\"course\"},{\"db\":\"g6\",\"table\":\"student\"},{\"db\":\"login\",\"table\":\"users\"}]');
/*!40000 ALTER TABLE `pma__recent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__relation`
--

DROP TABLE IF EXISTS `pma__relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  KEY `foreign_field` (`foreign_db`,`foreign_table`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__relation`
--

LOCK TABLES `pma__relation` WRITE;
/*!40000 ALTER TABLE `pma__relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__savedsearches`
--

DROP TABLE IF EXISTS `pma__savedsearches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__savedsearches` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__savedsearches`
--

LOCK TABLES `pma__savedsearches` WRITE;
/*!40000 ALTER TABLE `pma__savedsearches` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__savedsearches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__table_coords`
--

DROP TABLE IF EXISTS `pma__table_coords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT '0',
  `x` float unsigned NOT NULL DEFAULT '0',
  `y` float unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__table_coords`
--

LOCK TABLES `pma__table_coords` WRITE;
/*!40000 ALTER TABLE `pma__table_coords` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__table_coords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__table_info`
--

DROP TABLE IF EXISTS `pma__table_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`db_name`,`table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__table_info`
--

LOCK TABLES `pma__table_info` WRITE;
/*!40000 ALTER TABLE `pma__table_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__table_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__table_uiprefs`
--

DROP TABLE IF EXISTS `pma__table_uiprefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`username`,`db_name`,`table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__table_uiprefs`
--

LOCK TABLES `pma__table_uiprefs` WRITE;
/*!40000 ALTER TABLE `pma__table_uiprefs` DISABLE KEYS */;
INSERT INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES ('cpses_fm16cf2pkx','g6','History_Major','[]','2019-04-19 03:34:36'),('cpses_fmby9s2m60','g6','users','{\"sorted_col\":\"`users`.`id` ASC\"}','2019-04-26 20:09:30'),('cpses_fmdgyfferh','g6','course','{\"sorted_col\":\"`course`.`Course_ID` ASC\"}','2019-05-02 17:57:49'),('cpses_fmhnh8ex8b','g6','student','{\"sorted_col\":\"`student`.`Student_ID` ASC\"}','2019-04-26 15:35:18'),('cpses_fmjpzx550h','theusers','users','[]','2019-04-07 03:45:08'),('cpses_fmk5zok44l','g6','History_Major','[]','2019-05-09 13:57:51');
/*!40000 ALTER TABLE `pma__table_uiprefs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__tracking`
--

DROP TABLE IF EXISTS `pma__tracking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin,
  `data_sql` longtext COLLATE utf8_bin,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`db_name`,`table_name`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__tracking`
--

LOCK TABLES `pma__tracking` WRITE;
/*!40000 ALTER TABLE `pma__tracking` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__tracking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__userconfig`
--

DROP TABLE IF EXISTS `pma__userconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__userconfig`
--

LOCK TABLES `pma__userconfig` WRITE;
/*!40000 ALTER TABLE `pma__userconfig` DISABLE KEYS */;
INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES ('omnicypher','2019-03-25 14:42:41','{\"Console\\/Mode\":\"collapse\"}');
/*!40000 ALTER TABLE `pma__userconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__usergroups`
--

DROP TABLE IF EXISTS `pma__usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N',
  PRIMARY KEY (`usergroup`,`tab`,`allowed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__usergroups`
--

LOCK TABLES `pma__usergroups` WRITE;
/*!40000 ALTER TABLE `pma__usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pma__users`
--

DROP TABLE IF EXISTS `pma__users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`username`,`usergroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pma__users`
--

LOCK TABLES `pma__users` WRITE;
/*!40000 ALTER TABLE `pma__users` DISABLE KEYS */;
/*!40000 ALTER TABLE `pma__users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prerequisite`
--

DROP TABLE IF EXISTS `prerequisite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prerequisite` (
  `Course_ID` varchar(255) NOT NULL,
  `Prerequiste_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Course_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prerequisite`
--

LOCK TABLES `prerequisite` WRITE;
/*!40000 ALTER TABLE `prerequisite` DISABLE KEYS */;
/*!40000 ALTER TABLE `prerequisite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `professor`
--

DROP TABLE IF EXISTS `professor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `professor` (
  `Professor_ID` int(11) NOT NULL,
  `P_Name` varchar(255) DEFAULT NULL,
  `Course_Name` varchar(255) DEFAULT NULL,
  `Department_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`Professor_ID`),
  KEY `Department_ID` (`Department_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `professor`
--

LOCK TABLES `professor` WRITE;
/*!40000 ALTER TABLE `professor` DISABLE KEYS */;
/*!40000 ALTER TABLE `professor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedulee`
--

DROP TABLE IF EXISTS `schedulee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedulee` (
  `Row_Number` int(11) NOT NULL AUTO_INCREMENT,
  `Student_ID` int(11) NOT NULL,
  `Course_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Row_Number`),
  KEY `Student_ID` (`Student_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedulee`
--

LOCK TABLES `schedulee` WRITE;
/*!40000 ALTER TABLE `schedulee` DISABLE KEYS */;
INSERT INTO `schedulee` (`Row_Number`, `Student_ID`, `Course_ID`) VALUES (5,700900000,'4'),(8,700900000,'454'),(58,700900000,'632'),(68,700900001,'10'),(69,700900001,'20'),(105,700000000,'2466'),(123,700000000,'26'),(136,700000030,'1314'),(141,700000030,'1321'),(146,700000030,'1350'),(154,700000030,'1414'),(156,700000030,'1434'),(157,700000004,'62'),(158,700000004,'694'),(160,700000004,'762'),(161,700000004,'6'),(164,700000031,'2501'),(167,700000000,'114'),(177,700000000,'442'),(178,700000045,'2501');
/*!40000 ALTER TABLE `schedulee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedulehistory`
--

DROP TABLE IF EXISTS `schedulehistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedulehistory` (
  `Term` int(11) NOT NULL,
  `Year` int(11) DEFAULT NULL,
  `Course_ID` varchar(255) DEFAULT NULL,
  `Time_Date` varchar(255) DEFAULT NULL,
  `Hold_ID` int(11) DEFAULT NULL,
  `Class_Name` varchar(255) DEFAULT NULL,
  `Class_Schedule` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Term`),
  KEY `Hold_ID` (`Hold_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedulehistory`
--

LOCK TABLES `schedulehistory` WRITE;
/*!40000 ALTER TABLE `schedulehistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedulehistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `semester`
--

DROP TABLE IF EXISTS `semester`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `semester` (
  `Semester_ID` int(11) NOT NULL,
  `RegDate` varchar(255) DEFAULT NULL,
  `Course_Name` varchar(255) DEFAULT NULL,
  `Department_ID` int(11) DEFAULT NULL,
  `Season` varchar(255) DEFAULT NULL,
  `Year` int(11) DEFAULT NULL,
  PRIMARY KEY (`Semester_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `semester`
--

LOCK TABLES `semester` WRITE;
/*!40000 ALTER TABLE `semester` DISABLE KEYS */;
/*!40000 ALTER TABLE `semester` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `Student_ID` int(30) NOT NULL AUTO_INCREMENT,
  `Student_Name` varchar(255) DEFAULT NULL,
  `Advisor_Name` varchar(255) DEFAULT 'None Assigned',
  `Student_Number` varchar(255) DEFAULT 'None Assigned',
  `Date_Of_Enrollment` varchar(255) NOT NULL DEFAULT 'None Assigned',
  `Hold_ID` int(30) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Student_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=700000046 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` (`Student_ID`, `Student_Name`, `Advisor_Name`, `Student_Number`, `Date_Of_Enrollment`, `Hold_ID`) VALUES (700000000,'Juvon Hyatt','None Assigned','None Assigned','None Assigned',0),(700000001,'Mikaela Hyatt','None Assigned','None Assigned','None Assigned',0),(700000002,'Adrine Hyatt','None Assigned','None Assigned','None Assigned',0),(700000005,'stest stest','None Assigned','None Assigned','None Assigned',0),(700000012,'stesthree stesthree','None Assigned','None Assigned','None Assigned',0),(700000013,'test5','test5','test5','test5',0),(700000015,'test9 ','Juvon Hyatt','test9','2019-04-24',0),(700000016,'','test55','test55','2019-04-25',0),(700000017,'','studenttwo','studenttwo','2019-04-25',0),(700000018,'','studenttwo','studenttwo','2019-04-25',0),(700000019,'stutest stutest','None Assigned','None Assigned','None Assigned',0),(700000022,'test','None Assigned','None Assigned','None Assigned',0),(700000023,'test','None Assigned','None Assigned','None Assigned',0),(700000025,'finaltest finaltest','None Assigned','None Assigned','2019-04-26',0),(700000026,'Omnicypher(Student Test)','None Assigned','None Assigned','2019-04-26',0),(700000027,'addstudent addstudent','None Assigned','None Assigned','2019-04-26',0),(700000028,'accountmanager accountmanager','None Assigned','None Assigned','2019-04-26',0),(700000029,'accountmanagertwo accountmanagertwo','None Assigned','None Assigned','2019-04-26',0),(700000030,'studentstudent studentstudent','None Assigned','None Assigned','2019-04-30',0),(700000031,'Ashok Ashok','None Assigned','None Assigned','2019-05-01',0),(700000034,'acctest acctest','None Assigned','None Assigned','2019-05-02',0),(700000036,'acctest acctest','None Assigned','None Assigned','2019-05-02',0),(700000038,'testacc testacc','None Assigned','None Assigned','2019-05-02',0),(700000040,'Camille Nicholas','None Assigned','None Assigned','2019-05-03',0),(700000041,'testnow testnow','None Assigned','None Assigned','2019-05-03',0),(700000042,'Antwon Kelly','None Assigned','None Assigned','2019-05-07',0),(700000044,'testpassword testpassword','None Assigned','None Assigned','2019-05-07',0),(700000045,'Student Student','None Assigned','None Assigned','2019-05-12',0);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `studentfulltime`
--

DROP TABLE IF EXISTS `studentfulltime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `studentfulltime` (
  `Student_ID` int(11) NOT NULL,
  KEY `Student_ID` (`Student_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `studentfulltime`
--

LOCK TABLES `studentfulltime` WRITE;
/*!40000 ALTER TABLE `studentfulltime` DISABLE KEYS */;
/*!40000 ALTER TABLE `studentfulltime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `studentparttime`
--

DROP TABLE IF EXISTS `studentparttime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `studentparttime` (
  `Student_ID` int(11) NOT NULL,
  KEY `Student_ID` (`Student_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `studentparttime`
--

LOCK TABLES `studentparttime` WRITE;
/*!40000 ALTER TABLE `studentparttime` DISABLE KEYS */;
/*!40000 ALTER TABLE `studentparttime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timee`
--

DROP TABLE IF EXISTS `timee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timee` (
  `Time_ID` int(30) NOT NULL,
  `Time_Slot` varchar(255) NOT NULL,
  `Day` varchar(255) NOT NULL,
  PRIMARY KEY (`Time_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timee`
--

LOCK TABLES `timee` WRITE;
/*!40000 ALTER TABLE `timee` DISABLE KEYS */;
INSERT INTO `timee` (`Time_ID`, `Time_Slot`, `Day`) VALUES (11,'8:00 am - 9:30 am','Monday - Wednesday '),(12,'9:40 am - 11:10 am','Monday - Wednesday '),(13,'11:20 am - 12:50 pm','Monday - Wednesday'),(14,'1:00 pm - 2:30 pm','Monday - Wednesday'),(15,'2:40 pm - 3:40 pm','Monday - Wednesday'),(16,'3:50 pm - 5:20 pm','Monday - Wednesday'),(17,'5:30 pm - 7:00 pm','Monday - Wednesday'),(18,'7:10 pm - 8:40 pm','Monday - Wednesday'),(19,'8:50 pm - 10:20 pm','Monday - Wednesday'),(21,'8:00 am - 9:30 am','Tuesday - Thursday'),(22,'9:40 am - 11:10 am','Tuesday - Thursday'),(23,'11:20 am - 12:00 pm','Tuesday - Thursday'),(24,'1:00 pm - 2:30 pm','Tuesday - Thursday'),(25,'2:40 pm- 3:40 pm','Tuesday - Thursday'),(26,'3:50 pm - 5:20 pm','Tuesday - Thursday'),(27,'5:30 pm - 7:00 pm','Tuesday - Thursday'),(28,'7:10 pm - 8:40 pm','Tuesday - Thursday'),(29,'8:50 pm - 10:20 pm','Tuesday - Thursday'),(31,'8:00 am - 9:30 am','Tuesday - Thursday'),(32,'9:40 am - 11:10 am','Tuesday - Thursday'),(33,'11:20 am - 12:50 pm','Tuesday - Thursday'),(34,'1:00 pm - 2:30 pm','Tuesday - Thursday'),(35,'2:40 pm - 3:40 pm','Tuesday - Thursday'),(36,'3:50 pm - 5:20 pm','Tuesday - Thursday'),(37,'5:30 pm- 7:00 pm','Tuesday - Thursday'),(38,'7:10 pm - 8:40 pm','Tuesday - Thursday'),(39,'8:50 pm - 10:20 pm','Tuesday - Thursday'),(41,'8:00 am - 9:30 am','Tuesday -Thursday'),(42,'9:40 am - 11:10 am','Tuesday -Thursday'),(43,'11:20 am- 12:50 pm','Tuesday -Thursday'),(44,'1:00 pm - 2:30 pm','Tuesday -Thursday'),(45,'2:40 pm - 3:40 pm','Tuesday -Thursday'),(46,'3:50 pm - 5:20 pm','Tuesday -Thursday'),(47,'5:30 pm - 7:00 pm','Tuesday -Thursday'),(48,'7:10 pm - 8:40 pm','Tuesday -Thursday'),(49,'8:50 pm - 10:20 pm','Tuesday -Thursday'),(51,'8:00 am - 9:30 am','Friday'),(52,'9:40 am - 11:10 am','Friday'),(53,'11:20 am - 12:50 pm','Friday'),(54,'1:00 pm - 2:30 pm','Friday'),(55,'2:40 pm - 3:40 pm ','Friday'),(56,'3:50 pm- 5:20 pm ','Friday'),(57,'5:30 pm - 7:00 pm','Friday'),(58,'7:10 pm - 8:40 pm ','Friday'),(59,'8:50 pm - 10:20 pm','Friday');
/*!40000 ALTER TABLE `timee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transcript`
--

DROP TABLE IF EXISTS `transcript`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transcript` (
  `transcript_entry` int(30) NOT NULL AUTO_INCREMENT,
  `Student_ID` int(11) NOT NULL,
  `Course_ID` int(30) NOT NULL,
  `Grades` varchar(255) DEFAULT NULL,
  `Semester` varchar(255) NOT NULL,
  `Course_Credits` int(30) NOT NULL DEFAULT '4',
  PRIMARY KEY (`transcript_entry`),
  KEY `Student_ID` (`Student_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transcript`
--

LOCK TABLES `transcript` WRITE;
/*!40000 ALTER TABLE `transcript` DISABLE KEYS */;
INSERT INTO `transcript` (`transcript_entry`, `Student_ID`, `Course_ID`, `Grades`, `Semester`, `Course_Credits`) VALUES (36,700000000,2466,'N/A','Summer 2019',4),(45,700000000,2215,'N/A','Summer 2019',4),(54,700000000,26,'N/A','Summer 2019',4),(56,700000000,1,'B','Spring 2019',4),(59,700000000,5,'C','Spring 2019',4),(61,700000000,13,'A','Spring 2019',4),(62,700000000,29,'A','Spring 2019',4),(65,700000000,2,'B','Spring 2019',4),(69,700000030,1366,'N/A','Summer 2019',4),(70,700000030,1369,'B','Spring 2019',4),(72,700000030,1441,'B','Spring 2019',4),(73,700000030,1425,'A','Spring 2019',4),(74,700000030,1349,'B','Spring 2019',4),(88,700000030,1350,'N/A','Summer 2019',4),(96,700000030,1414,'N/A','Summer 2019',4),(98,700000030,1434,'N/A','Summer 2019',4),(99,700000004,62,'N/A','Summer 2019',4),(100,700000004,694,'N/A','Summer 2019',4),(102,700000004,762,'N/A','Summer 2019',4),(103,700000004,6,'N/A','Summer 2019',4),(106,700000031,2501,'N/A','Summer 2019',4),(109,700000000,2441,'A','Spring 2019',4),(110,700000000,114,'N/A','Summer 2019',4),(120,700000000,442,'N/A','Summer 2019',4),(121,700000045,2501,'N/A','Summer 2019',4);
/*!40000 ALTER TABLE `transcript` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` int(30) NOT NULL DEFAULT '0',
  `student_id` int(30) NOT NULL,
  `major` varchar(255) NOT NULL DEFAULT 'None Assigned',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `username`, `password`, `level`, `student_id`, `major`) VALUES (1,'juvon','hyatt','juvonhyatt@yahoo.com','juvon','password',0,700000001,'None Assigned'),(35,'accountmanagertwo','accountmanagertwo','accountmanagertwo@gmail.com','accountmanagertwo','$2y$10$hRxn4mAkPDik2wsgfx35TeKTsPENM72XAeYKkORN3EHst/czxYdE6',1,700000029,'Computer Science'),(4,'Caryne','Nicholas','ctctzrl@gmail.com','DerSchwarzeSchwanz','$2y$10$ZMtJ5.3F0vTKnwjrHhAmv.h70zoF5X.KpLIe.vbVqFiBh5nG93LMC',0,700000004,'None Assigned'),(0,'studentX','studentX','studentX@gmail.com','studentX','$2y$10$CkPEcBwg7EVvhpTA4DNybugKjNeuQkfVHStfVTqrbHE.G4jabqw8i',0,700000000,'American Studies'),(6,'this admin account has been terminated. you can do nothing','this admin account has been terminated. you can do nothing','admin@gmail.com','admin','$2y$10$VJecetZvXaTEpgv.vRc7k.t2UikkE7PTw1O/MV3UrDWGMNDamvMXm',0,101,'None Assigned'),(26,'stutest','stutest','stutest@gmailc.om','stutest','$2y$10$VnUXsGOvp9wAQV2Fh8KXpucvNv9jzP9Ro6iua2iTwdwtB.9eI/7qi',0,700000019,'Computer Science'),(28,'test','test','test','test','test',0,0,'None Assigned'),(29,'test','test','test','test','test',0,0,'None Assigned'),(31,'finaltest','finaltest','finaltest@gmail.com','finaltest','$2y$10$y7RLF09jKgQYH0Po5aWBbes/PnYdmlvW6YoQKtGnsd01h4ksfGyz6',0,700000024,'History'),(32,'Omnicypher(GOD account)','Hyatt','juvonhyatt@yahoo.com','Omnicypher','$2y$10$YZ2Pl.1RBNUrt/r3QmyYCOeh0OrjgodO8HNXArqIP5/6OnQ2TxdH2',1,0,'Computer Science'),(34,'accountmanager','accountmanager','accountmanager@gmail.com','accountmanager','$2y$10$2DPQHKNFBSVkLlsIfRDGhuwWM6KzUhM4zF9jVxsN81EqutWqB7SNS',0,0,'Computer Science'),(33,'addstudent','addstudent','addstudent@gmail.comaddstudent','addstudent','$2y$10$SNnoT0nyROq4KbjtKv8alevUUiTdYPJ/N6aa6aURNJ9GrqoOltVjG',0,700000027,'Biology'),(63,'testpassword','testpassword','testpassword@gmail.com','testpassword','$2y$10$g3y41WwdBRE54hhYJT6ITeMcsB8bdflaHSyDmwmBgG3crYLxtT9ci',0,700000044,'Computer Science'),(37,'facultytesttwo','facultytesttwo','facultytesttwo@gmail.com','facultytesttwo','$2y$10$9I.4aJJ0cbaKaqKWx8uojeR9Kas4HGx5yIuuHm./pQnVQTzd7z/C.',2,0,'None Assigned'),(39,'studentstudent','studentstudent','studentstudent@gmail.com','studentstudent','$2y$10$9cAPLhFRyjX/jWHaXezile5fB2dc3wxSExcOnvx.r4PKol/9e8zPq',0,700000030,'Computer Science'),(40,'researcher','researcher','researcher@gmail.com','researcher','$2y$10$Tz56DTkefmcJZRWPaxppCubEXZnMaLB3N6sTTyLGr9sfbofAR3XLS',3,0,'None Assigned'),(41,'Ashok','Ashok','ashok@gmail.com','Ashok','$2y$10$c6fRbnyJK7KICP32.WW1xOj7pJCv2G1W4klaOGaWmjZoXd0dlxrkC',0,700000031,'Computer Science'),(45,'Juvon','Hyatt','juvonhyatt@yahoo.com','jhyatt','$2y$10$GKnCKDwbU6ZCGvKTd8qOIeJN3Ml0yWPGAhBFY47PyGudJpI9JeDcO',2,0,'None Assigned'),(48,'acctest','acctest','acctest@gmail.com','acctest','$2y$10$PjFOlE6Q.DWevcJJzMIgBu84JoJmHBDXwsuLn1ve4VdHfnI4ekyS2',0,700000036,'Computer Science'),(49,'Albert','Einstein','AlbertEinstein@gmail.com','AlbertEinstein','$2y$10$CVaDfNvlOzaItCqDpxSvVOI0jDkmRYhtq8a0KG5ulwR8QTztVzBBC',3,0,'None Assigned'),(61,'Antwon','Kelly','sexysoupturtle@gmail.com','anal','$2y$10$..egiRR1Q7agIRJkU5Px2Ol23udRN.OPNnSLVGHwW459BhTml7rvS',0,700000042,'Computer Science'),(56,'Camille','Nicholas','Wow@gmail.com','Clammycammy','$2y$10$pKa1prb0v2.PUltwBQkRUuMWlXz/YmE1qlmgvkDu37OzitNAbCeZq',0,700000039,'Liberal Arts'),(57,'testnow','testnow','testnow@gmail.com','testnow','$2y$10$CsoQAC2mG95exrhABJv0HOjXYoIqFlv7YhdhsVLM2lOQfbEAbhPVC',0,700000041,'Biology'),(64,'Student','Student','juvonhyatt@yahoo.com','Student','$2y$10$ethjAhUg5BiK9hAd9Qw5M.yzXkKU0t3ZJgzTXArfYXUStp1ms8Pqm',0,700000045,'Computer Science');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'g6'
--

--
-- Dumping routines for database 'g6'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-13  4:02:50
