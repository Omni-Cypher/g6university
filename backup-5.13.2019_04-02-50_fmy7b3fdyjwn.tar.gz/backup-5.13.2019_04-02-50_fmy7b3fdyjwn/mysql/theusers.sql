-- MySQL dump 10.13  Distrib 5.6.43, for Linux (x86_64)
--
-- Host: localhost    Database: theusers
-- ------------------------------------------------------
-- Server version	5.6.43-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` int(30) NOT NULL DEFAULT '0',
  `student_id` int(30) NOT NULL,
  `major` varchar(255) NOT NULL DEFAULT 'None Assigned',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `username`, `password`, `level`, `student_id`, `major`) VALUES (1,'juvon','hyatt','juvonhyatt@yahoo.com','juvon','password',0,0,'None Assigned'),(2,'lee-ann','asian','lee-ann@gmail.com','lee-ann','password',1,0,'None Assigned'),(3,'studenttwo','studenttwo','student2@gmail.com','studenttwo','$2y$10$n7e46menpCvjzJIUCziJdu9iSQNJpMJaEOO5jGfFTfbq4UeJ0RZly',0,0,'None Assigned'),(4,'Caryne','Nicholas','ctctzrl@gmail.com','DerSchwarzeSchwanz','$2y$10$ZMtJ5.3F0vTKnwjrHhAmv.h70zoF5X.KpLIe.vbVqFiBh5nG93LMC',0,700900000,'None Assigned'),(5,'student','student','student@gmail.com','student','$2y$10$Xnf/uUQY0fMAXlaxvNeAiOH.2R5LoMmPpBp6hT8UMpdQ8uNaRrGKm',0,700000000,'History'),(6,'admin','admin','admin@gmail.com','admin','$2y$10$VJecetZvXaTEpgv.vRc7k.t2UikkE7PTw1O/MV3UrDWGMNDamvMXm',1,0,'None Assigned'),(7,'Daniel','Poop','gatorboi@yahoo.com','gatorboi','$2y$10$Ja7F2q4hj2vu06sI5mUei.lbICzJsYDOyCreY93TE5apTQBov6.Vu',0,0,'None Assigned'),(8,'ashok','basawaputna','ashok@gmail.com','ashokbasawaputna100','$2y$10$OX5WglxSEUZ2Vm3q9Sy4SeH1u21qJbXYU8aQ4PqOWuIIJ/koIUhT.',0,0,'None Assigned'),(9,'jack','black','jackblack@gmail.com','Jack','$2y$10$TMK0MilOtWcRB6Ann6IPZ.u/8cuad0N/kfK4DWd2kAeMoXIE3fu6u',0,700900001,'None Assigned'),(12,'majortest','majortest','majortest@gmail.com','majortest','$2y$10$cobUbevGJwrUShVWY/AlIOaG8xMP3iBkl78Ex03nxAaBLgb3tLCgy',0,700000011,'Computer Science'),(14,'Juvon','Hyatt','juvonhyatt@yahoo.com','jhyatt','$2y$10$FF0qgrY5byBY3LJthmE9RuE0mDpuo.y2k1AHQjHwXhu1D1EKk5GUm',0,0,'Computer Science');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'theusers'
--

--
-- Dumping routines for database 'theusers'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-13  4:02:50
