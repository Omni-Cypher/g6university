
<html>
<head>
    <Title></Title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div style=" width: 100%; height: auto;">
    <header>
     <div class ="main-wrapper">
          <div class="box1" style="background-color:lightblue; width: 100%;">
        <h1 style="text-align: center;">Group 6 University</h1>
         </div>
                 <?php
                 session_start();

                 $student_id = $_SESSION['student_id'];
                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $firstname = $_SESSION['firstname'];
                 $lastname = $_SESSION['lastname'];
                 $major = $_SESSION['major'];
                
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');

// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());

                    if(isset($_SESSION['username'])){
                        
                        //extra admin privlages
                        $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 1";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                        if($resultCheck>0){
                            $_SESSION['level'] = 1;
                           $level = $_SESSION['level'];
                        //if you are an admin
           
                        
                            echo '<nav>
                       
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                 
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="studentsearch.php">Search student</a></li>
                        <li><a href="accounts.php">Manage Accounts</a></li>
                        <li><a href="facultyMain.php">My Profile</a></li>
                        <li><a href="courseManager.php">Course Manager</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
         
                        //** add more admin abilities above **/    
                       
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form><div></nav>';
                            
                        }else{
                            
                         $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 0";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                           $_SESSION['level'] = 0;
                           $level = $_SESSION['level'];
                         //if you are an student user
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="StudentMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="degreeAudit.php">Degree Audit</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                               $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 2";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
              
                                //if you are an faculty

                                $_SESSION['level'] = 2;
                                $level =  $_SESSION['level'];
                           
                                
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="facultyMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="studentManager.php">Student Manager</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                            
                                 $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 3";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                                //you are a researcher
                            
                             $_SESSION['student_id'] = 0;
                                $_SESSION['level'] = 3;
                                $level =  $_SESSION['level'];
                     
                                
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="research.php">Research</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                         <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                            
                           }
                       }
                        
                     }
                  }
                }else{
                                echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                  
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
                         echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                   <button type="submit" name="submit">Login</button>
                    </form>
                    <!--<a href="signup.php">sign up</a></div></nav>-->';
                    }
                ?>
                  
                </div>

    </header>
    <style>
        .slider-frame{
    overflow:hidden;
    height: 500px;
    width: 100%;
    margin-top: 20px;  
    padding-bottom: 50px;
}

@-webkit-keyframes slide_animation{
    0%{left: 0%;}
    10%{left: 0%;}
    20%{left: 101%;}
    30%{left:101%;}
    40%{left: 150%;}
    50%{left: 150%x;}
    60%{left: 101%;}
    70%{left: 101%;}
    80%{left: 50%;}
    90%{left: 0%;}
    100%{left: 0px;}
}

.slide-images{
    width: 3600px;
    height: 800px;
    margin: 0 0 0 -2400px;
    position: relative;
    -webkit-animation-name: slide_animation;
    -webkit-animation-duration: 33s;
    -webkit-animation-iteration-count: infinite;
    -webkit-animation-direction: alternate;
    -webkit-animation-play-state: running;
    
    -moz-animation-name: slide_animation;
    -moz-animation-duration: 33s;
    -moz-animation-iteration-count: infinite;
    -moz-animation-direction: alternate;
    -moz-animation-play-state: running;
 
}

.img-container{
     
    height: 500px;
    width: 33%;
    position: relative;
    float: left;
}

.info-box-1{
    height: 300px;
    float: left;
    width: 60%;
    background-image: linear-gradient(cadetblue, lightblue);
    margin-top: 50px;
    margin-left: 30px;
    border-radius: 5px;
    font-family: Arial;
    font-size: 250%;
    font-weight: bold;
    padding-left: 50px;
    
    
}

.info-box-2{
    height: 300px;
    float: left;
    width: 30%;
    background-image: linear-gradient(cadetblue, lightblue);
    margin-top: 50px;
    margin-left: 60px;
    border-radius: 5px;
    
}

li { transition: all .2s ease-in-out; }
li:hover { transform: scale(1.1); }
    
    </style>

    <div style="background-color: lightblue; height: 200%; width: 100%;">
    <section style="Padding: 0px;">
        
             
              <div style="float:left; font-size: 30px; padding-left: 30px;">
                    <?php
        if(isset($_SESSION['username'])){
            $username= $_SESSION['username'];
            echo"Hello $firstname, welcome to G6<br>";  
            if($student_id>0){
            echo"Student ID: $student_id<br>";
            }
            
               $sql = "SELECT * FROM users WHERE username='$username' AND level>0";
            $result = mysqli_query($conn,$sql);
            $resultCheck = mysqli_num_rows($result);
            if($resultCheck>0){
            echo" <br></br><p>you are an admin!!!<p>";
            }
        }
        ?>
        </div>
        
       
                <div class="slider-frame">
                     <h1 style=" font-size: 150%; position= absolute; color: white; padding-left: 50px;">Own Your Future. Here, at G6.</h1>
                    <div class="slide-images">
                         <div class= "img-container">
                            <img src ="https://wallpapercave.com/wp/wp2542537.jpg">
                        </div>
                        <div class= "img-container">
                            <img src ="http://iau.edu.lc/wp-content/uploads/2014/06/banner.jpg">
                        </div>
                        <div class= "img-container">
                            <img src ="http://hdwallpapersrocks.com/wp-content/uploads/2013/10/College-student-boy-and-girl-couple.jpg">
                        </div>
                         <div class= "img-container">
                            <img src ="https://wallpapercave.com/wp/wp2542537.jpg">
                        </div>
            
                    </div>
                </div>
               <!--<img class="colback" src="http://iau.edu.lc/wp-content/uploads/2014/06/banner.jpg" alt="college background" height="400px" width="100%">-->
         
        <div class="content">
           
        <div class="info-box-1">
        <p>Together We Can Change the World.</p>
        </div>
        
         <div class="info-box-2">
            
        </div>
        
        
        
       </div>
        </div>
      
      
    </div>
     </div>
    </section>

    
</body>
<div class="footer" style="border-style: solid; border-color: white; border-width: 9px;">
        <div class="ft1">
            <p style="text-align: left; padding: 10px;">Juvon Hyatt Copyright 2018-2019</p>
        </div>

        <div class="ft2">
            <p style="text-align: left; padding: 10px;">Juvon Hyatt Copyright 2018-2019</p>
        </div>

        <div class="ft3">
            <p style="text-align: left; padding: 10px;">Juvon Hyatt Copyright 2018-2019</p>
        </div>
    </div>
    </div>
    </div>
    
</html>
