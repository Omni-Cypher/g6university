<html>
<head>
    <Title></Title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div style=" width: 100%; height: auto;">
    <header>
     <div class ="main-wrapper">
          <div class="box1" style="background-color:lightblue; width: 100%;">
        <h1 style="text-align: center;">Group 6 University</h1>
         </div>
         <style>
             li { transition: all .2s ease-in-out; }
             li:hover { transform: scale(1.1); }
    
         </style>
         

                 <?php
                 session_start();

                
                 $student_id = $_SESSION['student_id'];
                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $firstname = $_SESSION['firstname'];
                 $lastname = $_SESSION['lastname'];
                 $major = $_SESSION['major'];
                 
                
                 
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');
                
                
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());

                 

    if($_SESSION['level']==1){
                 
                    if(isset($_SESSION['username'])){
                        
                        //extra admin privlages
                        $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level>0";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                        if($resultCheck>0){
                            $_SESSION['level'] = 1;
                           $level = $_SESSION['level'];
                        //if you are an admin
           
                        
                            echo '<nav>
                       
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                 
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="studentsearch.php">Search student</a></li>
                        <li><a href="accounts.php">Manage Accounts</a></li>
                        <li><a href="courseManager.php">Course Manager</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
         
                        //** add more admin abilities above **/    
                       
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form><div></nav>';
                            
                        }else{
                            
                         $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 0";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                           $_SESSION['level'] = 0;
                           $level = $_SESSION['level'];
                         //if you are an student user
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="StudentMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="degreeAudit.php">Degree Audit</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                                //if you are an faculty
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="StudentMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                        
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        
                            
                        }
                            
                        }
               
               
               
               
               
               
               
               
               
                }else{
                                echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                  
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
                         echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                    <button type="submit" name="submit">Login</button>
                    </form>
                    <a href="signup.php">sign up</a></div></nav>';
                    }
                
                 $sql = "SELECT MAX(student_id) AS NEXT_ID FROM student;";
                 $id;
                        $result = @mysqli_query($dbc,$sql);
                 while($row = mysqli_fetch_array($result)){
                          #echo $row['NEXT_ID']; 
                         $id=  $row['NEXT_ID']+1;
                          
                       }
                       #echo'id: '.$id;
                  
     echo'           
                </div>

    </header>
    <section class="main-container">
        <h2 style="color: white">Account Manager</h2>
        <div style="height:1900px;">'; 
             if($_SESSION['success']){
                 echo $_SESSION['success'];
                 unset($_SESSION['success']);
             }
            if(isset($_POST['delStudent'])){ //checks if delete student was called 
                  
                   $s2del = $_POST['delStudent'];
                    $sqld = 'DELETE FROM users WHERE student_id = '.$s2del;
                    $sqld2 = 'DELETE FROM student WHERE Student_ID = '.$s2del;
                    
                            $res = @mysqli_query($dbc, $sqld);
                            $res2 = @mysqli_query($dbc, $sqld2);
                            if($res && $res2){
                                mysqli_query($dbc, $sqld);
                                mysqli_query($dbc, $sqld2);
                                echo'<div style="color: lightgreen; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Student '.$_POST['delStudent'].' has been successfully deleted</div>';
                            }
               }
                if(isset($_POST['delFaculty'])){ //checks if delete student was called 
                  
                   $s2del = $_POST['delFaculty'];
                    $sqld = 'DELETE FROM users WHERE id = '.$s2del;
                    
                            $res = @mysqli_query($dbc, $sqld);
                        
                            if($res){
                                mysqli_query($dbc, $sqld);
                                echo'<div style="color: lightgreen; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Faculty '.$_POST['delFaculty'].' has been successfully deleted</div>';
                            }
               }
               
                if(isset($_POST['delAdmin'])){ //checks if delete student was called 
                  
                   $s2del = $_POST['delAdmin'];
                    $sqld = 'DELETE FROM users WHERE id = '.$s2del;
             
                    
                           
                                if($s2del != 32){
                                     $res = mysqli_query($dbc, $sqld);
                            if($res){
                            
                                mysqli_query($dbc, $sqld);
                                mysqli_query($dbc, $sqld2);
                                echo'<div style="color: lightgreen; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Admin '.$_POST['delAdmin'].' has been successfully deleted</div>';
                                
                                }
                            }
                            else{
                                    echo'<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: God Admin Account cannot be deleted</div>';
                                }
               }
               
                if(isset($_POST['delResearcher'])){ //checks if delete student was called 
                  
                   $s2del = $_POST['delResearcher'];
                    $sqld = 'DELETE FROM users WHERE id = '.$s2del;
           
                    
                            $res = @mysqli_query($dbc, $sqld);
                       
                            if($res){
                                mysqli_query($dbc, $sqld);
                   
                                echo'<div style="color: lightgreen; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Researcher '.$_POST['delResearcher'].' has been successfully deleted</div>';
                            }
               }
               
               
                 echo'<div class="profile-box" style="border-style: solid; border-color: black; border-width: 2px; font-size: 10px; font-color: white; padding-left: 70px; padding-top: 10px; padding-bottom: 10px; margin-left: 30px; width: 450px; background-color:#d3d3d3; font-family: arial; border-radius: 10px;">
                    <p style="font-size:20px; padding-left: 130px;">Add Student</p>
                <form class="signup-form" action="includes/signup.inc.php" method="POST" id="signup" name="signup">
            <input type="text" name="firstname" placeholder="Firstname">
             <input input type="hidden" name="student_id" value="'.$id.'">
            <input type="text" name="lastname" placeholder="Lastname">
            <select style="height: 30px; width: 90%; padding-bottom 10px;" name="Major" form="signup">
               <option value="" disabled selected>Select Major</option>
                <option ="Computer Science">Computer Science</option>
                 <option ="Biology">Biology</option>
                 <option ="Psychology">Psychology</option>
                <option = "Liberal Arts">Liberal Arts</option>
                  <option ="History">History</option>
            </select>
            <input type="text" name="email" placeholder="e-mail">
            <input type="text" name="username" placeholder="username">
            <input type="password" name="password" placeholder="password">
            <button style="margin-left: 120px; margin-top: 20px;" type="submit" name="submit">Submit</button>
                </form></div>';
                   
                   
                //PRINT OUT STUDENTS//
               echo' <div style="overflow: scroll; overflow-x: hidden; border-style: solid; border-color: black; 
               border-width: 3px; border-radius: 10px; position:relative; top: -430px; height: 425px; width: 50%; 
               float: right; margin-right: 200px; background: lightgrey">';
               
                
                $sql = "SELECT * FROM users WHERE student_id >699999999 and level = 0 ORDER BY student_id;";
                $students = @mysqli_query($dbc, $sql);
                if( $students){
                echo'<h1 style="color: cadetblue;padding-top: 20px;padding-left:15px;">Student Accounts</h1>';
                echo '<table style="width: 100%;" align="left"
                cellspacing="5" cellpadding="8">
                <tr><td align="left"><b>Student ID</b></td>
                <td align="left"><b>Student Name</b></td>
                <td align="left"><b>Delete</b></td>
                <td align="left"><b>View Schedule</b></td>';
 
                // mysqli_fetch_array will return a row of data from the query
                // until no further data is available
  
                while($row = mysqli_fetch_array( $students)){
                $name = $row['firstname'].' '.$row['lastname'];
                echo '<tr><td align="left">' . $row['student_id'] . '</td><td align="left">'.  $name . '</td><td align="left">'.
                '<form action="accounts.php" method="POST"><button onclick="confirm()" name="delStudent" type="submit" value="'.$row['student_id'].'">Delete</button></form>'. '</td><td align="left">'. 'view schedulefiller'.'</td>';
 
                echo '</tr>';
                }

 
echo '</table>';
 
} 
               echo' </div>
      

         <br><br>
         <div class="profile-box" style=" border-style: solid; border-color: black; border-width: 2px; font-size: 10px; font-color: white; padding-left: 70px; padding-top: 10px; padding-bottom: 10px; margin-left: 30px; width: 450px; background-color:#d3d3d3; font-family: arial; border-radius: 10px;">
                    <p style="font-size:20px; padding-left: 130px;">Add Faculty</p>
                <form class="signup-form" action="includes/signup.inc.php" method="POST" id="signup" name="signup">
            <input type="text" name="firstname" placeholder="Firstname">
             <input input type="hidden" name="level" value="2">
            <input type="text" name="lastname" placeholder="Lastname">
            <input type="text" name="email" placeholder="e-mail">
            <input type="text" name="username" placeholder="username">
            <input type="password" name="password" placeholder="password">
            <button style="margin-left: 120px; margin-top: 20px;" type="submit" name="submit2">Submit</button>
                </form></div>';
                
                //PRINT OUT Faculty//
               echo' <div style="overflow: scroll; overflow-x: hidden; border-style: solid; border-color: black; 
               border-width: 3px; border-radius: 10px; position:relative; top: -400px; height: 395px; width: 50%; 
               float: right; margin-right: 200px; background: lightgrey">';
               
                
                $sql = "SELECT * FROM users WHERE level = 2 ORDER BY id;";
                $faculty = @mysqli_query($dbc, $sql);
                if( $faculty){
                echo'<h1 style="color: cadetblue;padding-top: 20px;padding-left:15px;">Faculty Accounts</h1>';
                echo '<table style="width: 100%;" align="left"
                cellspacing="5" cellpadding="8">
                <tr><td align="left"><b>Faculty ID</b></td>
                <td align="left"><b>Faculty Name</b></td>
                <td align="left"><b>Delete</b></td>
                <td align="left"><b>Manage Classes</b></td>
                <td align="left"><b>View Schedule</b></td>';
 
                // mysqli_fetch_array will return a row of data from the query
                // until no further data is available
  
                while($row = mysqli_fetch_array( $faculty)){
                $name = $row['firstname'].' '.$row['lastname'];
                echo '<tr><td align="left">' . $row['id'] . '</td><td align="left">'.  $name . '</td><td align="left">'.
                '<form action="accounts.php" method="POST"><button onclick="confirm()" name="delFaculty" type="submit" value="'.$row['id'].'">Delete</button></form>'.
                '</td><td align="left">'.
                '<form action="facultyManager.php" method="POST"><input type="hidden" name="name" value="'.$name.'"><button name="facClasses" type="submit" value="'.$row['id'].'">Manage Classes</button></form>'.'</td><td align="left">'. 'view schedulefiller'.'</td>';
 
                echo '</tr>';
                }
                echo '</table>';
                }// end of table prints
                
         echo' </div>         
                
        
         <br><br>
         <div class="profile-box" style=" border-style: solid; border-color: black; border-width: 2px; font-size: 10px; font-color: white; padding-left: 70px; padding-top: 10px; padding-bottom: 10px; margin-left: 30px; width: 450px; background-color:#d3d3d3; font-family: arial; border-radius: 10px;">
                    <p style="font-size:20px; padding-left: 130px;">Add Admin</p>
                <form class="signup-form" action="includes/signup.inc.php" method="POST" id="signup" name="signup">
            <input type="text" name="firstname" placeholder="Firstname">
             <input input type="hidden" name="level" value="1">
            <input type="text" name="lastname" placeholder="Lastname">
            <input type="text" name="email" placeholder="e-mail">
            <input type="text" name="username" placeholder="username">
            <input type="password" name="password" placeholder="password">
            <button style="margin-left: 120px; margin-top: 20px;" type="submit" name="submit3">Submit</button>
                </form></div>';
                
                 //PRINT OUT Admin//
               echo' <div style="overflow: scroll; overflow-x: hidden; border-style: solid; border-color: black; 
               border-width: 3px; border-radius: 10px; position:relative; top: -400px; height: 395px; width: 50%; 
               float: right; margin-right: 200px; background: lightgrey">';
               
                
                $sql = "SELECT * FROM users WHERE level = 1 ORDER BY id;";
                $admin = @mysqli_query($dbc, $sql);
                if( $admin){
                echo'<h1 style="color: cadetblue;padding-top: 20px;padding-left:15px;">Admin Accounts</h1>';
                echo '<table style="width: 100%;" align="left"
                cellspacing="5" cellpadding="8">
                <tr><td align="left"><b>Admin ID</b></td>
                <td align="left"><b>Admin Name</b></td>
                <td align="left"><b>Delete</b></td>';
 
                // mysqli_fetch_array will return a row of data from the query
                // until no further data is available
  
                while($row = mysqli_fetch_array( $admin)){
                $name = $row['firstname'].' '.$row['lastname'];
                echo '<tr><td align="left">' . $row['id'] . '</td><td align="left">'.  $name . '</td><td align="left">'.
                '<form action="accounts.php" method="POST"><button onclick="confirm()" name="delAdmin" type="submit" value="'.$row['id'].'">Delete</button></form>'. '</td><td align="left">'.'</td>';
 
                echo '</tr>';
                }
                echo '</table>';
                }// end of table prints
                
         echo' </div>         
                
        <br><br>
         <div class="profile-box" style=" border-style: solid; border-color: black; border-width: 2px; font-size: 10px; font-color: white; padding-left: 70px; padding-top: 10px; padding-bottom: 10px; margin-left: 30px; width: 450px; background-color:#d3d3d3; font-family: arial; border-radius: 10px;">
                    <p style="font-size:20px; padding-left: 130px;">Add Researcher</p>
                <form class="signup-form" action="includes/signup.inc.php" method="POST" id="signup" name="signup">
            <input type="text" name="firstname" placeholder="Firstname">
             <input input type="hidden" name="level" value="1">
            <input type="text" name="lastname" placeholder="Lastname">
            <input type="text" name="email" placeholder="e-mail">
            <input type="text" name="username" placeholder="username">
            <input type="password" name="password" placeholder="password">
            <button style="margin-left: 120px; margin-top: 20px;" type="submit" name="submit4">Submit</button>
                </form></div>';
                
                //PRINT OUT Researcher//
               echo' <div style="overflow: scroll; overflow-x: hidden; border-style: solid; border-color: black; 
               border-width: 3px; border-radius: 10px; position:relative; top: -400px; height: 395px; width: 50%; 
               float: right; margin-right: 200px; background: lightgrey">';
               
                
                $sql = "SELECT * FROM users WHERE level = 3 ORDER BY id;";
                $researcher = @mysqli_query($dbc, $sql);
                if($researcher){
                echo'<h1 style="color: cadetblue;padding-top: 20px;padding-left:15px;">Researcher Accounts</h1>';
                echo '<table style="width: 100%;" align="left"
                cellspacing="5" cellpadding="8">
                <tr><td align="left"><b>Researcher ID</b></td>
                <td align="left"><b>Researcher Name</b></td>
                <td align="left"><b>Delete</b></td>';
 
                // mysqli_fetch_array will return a row of data from the query
                // until no further data is available
  
                while($row = mysqli_fetch_array($researcher)){
                $name = $row['firstname'].' '.$row['lastname'];
                echo '<tr><td align="left">' . $row['id'] . '</td><td align="left">'.  $name . '</td><td align="left">'.
                '<form action="accounts.php" method="POST"><button onclick="confirm()" name="delResearcher" type="submit" value="'.$row['id'].'">Delete</button></form>'. '</td><td align="left">'.'</td>';
 
                echo '</tr>';
                }
                echo '</table>';
                }// end of table prints
                
         echo' </div>     
        
      
     
     </div>
     
     
     
    </section>
    
    
<script>
function confirm() {
  confirm("Are you sure?");
}
</script>
</body>

    
</html>';
}else{
    header("Location: ../index.php");
    exit();
}