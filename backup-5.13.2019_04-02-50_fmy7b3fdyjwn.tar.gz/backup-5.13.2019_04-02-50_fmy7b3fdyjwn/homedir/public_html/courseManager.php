<html>
<head>
    <Title></Title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div style=" width: 100%; height: auto;">
     <header>
     <div class ="main-wrapper">
          <div class="box1" style="background-color:lightblue; width: 100%;">
        <h1 style="text-align: center;">Group 6 University</h1>
         </div>
                 <?php
                 session_start();

                 $student_id = $_SESSION['student_id'];
                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $firstname = $_SESSION['firstname'];
                 $lastname = $_SESSION['lastname'];
                 $major = $_SESSION['major'];
                
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');

// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());

                    if(isset($_SESSION['username'])){
                        
                        //extra admin privlages
                        $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 1";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                        if($resultCheck>0){
                            $_SESSION['level'] = 1;
                           $level = $_SESSION['level'];
                        //if you are an admin
           
                        
                            echo '<nav>
                       
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                 
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="studentsearch.php">Search student</a></li>
                        <li><a href="accounts.php">Manage Accounts</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
         
                        //** add more admin abilities above **/    
                       
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form><div></nav>';
                            
                        }else{
                            
                         $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 0";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                           $_SESSION['level'] = 0;
                           $level = $_SESSION['level'];
                         //if you are an student user
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="StudentMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="degreeAudit.php">Degree Audit</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                                //if you are an faculty
                                $_SESSION['student_id'] = 0;
                                $_SESSION['level'] = 2;
                                $level =  $_SESSION['level'];
                                $student_id = $_SESSION['student_id'];
                                
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="facultyMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="studentManager.php">Student Manager</a></li>                    
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }
                        }
                }else{
                                echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                  
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
                         echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                    <button type="submit" name="submit">Login</button>
                    </form>
                    <a href="signup.php">sign up</a></div></nav>';
                    }
                ?>
                  
                </div>

    </header>
    
    <section class="main-container">
        <h2 style="color: white">Course Manager</h2>
        <div style="height:1400px;"> 
        <?php
        session_start();
            DEFINE ('DB_USER4', 'omnicypher');
    
            DEFINE ('DB_PASSWORD4', 'S3RV3R!!');
            DEFINE ('DB_HOST4', 'localhost');
            DEFINE ('DB_NAME4', 'g6');
 
            // $dbc will contain a resource link to the database
            // @ keeps the error from showing in the browser
 
            $conn = @mysqli_connect(DB_HOST4, DB_USER4, DB_PASSWORD4, DB_NAME4)
            OR die('Could not connect to MySQL: ' .
            mysqli_connect_error());
             if(isset($_SESSION['Error'])){
                      echo '<div style="font-size: 20px; padding bottom: 10px;padding-left: 30p; color: white;">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspStatus:'.$_SESSION['Error'];
                      unset($_SESSION['Error']);
                  }
                  
            if(isset($_POST['add-course'])){
            //----------------------------INSERT COURSE--------------------------------//
            $crn = $_POST['CRN'];
            $time_id = $_POST['Time_ID'];
            $course_name = $_POST['Course_Name'];
            $section = $_POST['Section'];
            $seats = $_POST['open_seats'];
            $credits = $_POST['Course_Credits'];
            $sem = $_POST['Semester_ID'];
            $desc = $_POST['Course_Description'];
            $pID = $_POST['Professor_ID'];
            $dept = $_POST['Department_ID'];
            
            #echo $course_name;
    
        if(empty($crn) || empty($time_id) || empty($course_name) || empty($section) || empty($seats) || empty($sem) || empty($credits)  || empty($desc) || empty($pID)  || empty($dept) ){
        $_SESSION['Error'] = "Failed! You left one or more of the required fields empty.";
        header("Location: ../courseManager.php?addCourse=emptyfield"); //signup=empty shows error message
        exit();  
        }else{
                    if (!preg_match('/^[1-9][0-9]*$/', $seats) ||!preg_match('/^[1-9][0-9]*$/', $credits || !preg_match('/^[1-9][0-9]*$/', $pID)) ) {
                    $_SESSION['Error'] = "Failed! One or more numbers entered are invalid";
                    header("Location: ../courseManager.php?addCourse=invalid_number"); //signup=empty shows error message 
                    
                    exit();
                    } else {
                    // Continue
                    $count = 0;
                    $sql = "SELECT MAX(Course_ID) AS NEXT_ID FROM course;";
                    
                    
            
                     $id;
                        $result = @mysqli_query($conn,$sql);
                    while($row = mysqli_fetch_array($result)){
                          #echo $row['NEXT_ID']; 
                         $id=  $row['NEXT_ID']+1;
                          
                       }
                       #echo'id: '.$id;
                    
                    $sql = "INSERT INTO `course` (`Course_ID`, `CRN`, `Time_ID`, `Course_Name`, `open_seats`, `Course_Credits`, `Semester_ID`, `Course_Description`, `Professor_ID`, `Department_ID`) VALUES ('$id', '$crn','$time_id','$course_name', '$seats','$credits', '$sem', '$desc', '$pID', '$dept')";
                    $response = @mysqli_query($conn,$sql);
                    if($response){
                        echo '<div style="font-size: 20px; padding bottom: 10px;padding-left: 30p; color: white;">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspStatus: Course Successfully Created!</div>';
                    }else{
                        echo '<div style="font-size: 20px; padding bottom: 10px;padding-left: 30p; color: white;">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspStatus: Attempt to create course failed! , try again</div>';
                    }
                        
                        
                       }
                        
                    }
                  }
                  
                 
                
                  
                  if(isset($_POST['delete'])){
                      $dID = $_POST['cDelete'];
                      $sqlfind ='SELECT * FROM `course` WHERE Course_ID = '.$dID;
                      $sqlx ='DELETE FROM `course` WHERE Course_ID = '.$dID;
                      $find = mysqli_query($conn,$sqlfind);
                      $remove = mysqli_query($conn,$sqlx);
                      $cnt =0;
                      if($find){
                          while($row = mysqli_fetch_array($find)){
                              $cnt += 1;
                          }
                          
                      }
                      if($cnt>0){
                          #echo $cnt;
                      if($remove){
                          mysqli_query($conn,$sqlx);
                          echo '<div style="font-size: 20px; padding bottom: 10px;padding-left: 30p; color: white;">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspStatus: Successfully Removed!</div>';
                      }else{
                          echo '<div style="font-size: 20px; padding bottom: 10px;padding-left: 30p; color: white;">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspStatus: Attempt to remove course failed! , try again</div>';
                      }
                      }else if($cnt==0){
                            #echo $cnt;
                           echo '<div style="font-size: 20px; padding bottom: 10px;padding-left: 30p; color: white;">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspStatus: The course entered does not exists. </div>';
                      }
                       
                  }
                  
       
        
       
            
                 echo'<div class="profile-box" style="border-style: solid; border-color: black; border-width: 2px; font-size: 10px; font-color: white; padding-left: 70px; padding-top: 10px; padding-bottom: 10px; margin-left: 30px; width: 450px; background-color:#d3d3d3; font-family: arial; border-radius: 10px;">
                    <p style="font-size:20px; padding-left: 130px;">Add Course</p>
                <form class="signup-form" action="courseManager.php" method="POST" id="addCourse" name="addCourse">
            <input type="text" name="CRN" placeholder="enter CRN"><!--CRN-->
            <select style="height: 30px; width: 90%; padding-bottom 10px;" name="Time_ID" form="addCourse">
             <option value="" disabled selected>Select Time</option>
             <option value= "11">8:00 am - 9:30 am(MW)</option>
             <option value="12">9:40 am - 11:10 am(MW)</option>
             <option value="13">11:20 am - 12:50 pm(MW)</option>
             <option value="14">1:00 pm - 2:30 pm(MW)</option>
             <option value="15">2:40 pm - 3:40 pm(MW)</option>
             <option value="16">3:50 pm - 5:20 pm(MW)</option>
             <option value="17">5:30 pm - 7:00 pm(MW)</option>
             <option value="18">7:10 pm - 8:40 pm(MW)</option>
             <option value="19">8:50 pm - 10:20 pm(MW)</option>
             <option value="21">8:00 am - 9:30 am(TR)</option>
             <option value="22">9:40 am - 11:10 am(TR)</option>
             <option value="23">11:20 am - 12:00 pm(TR)</option>
             <option value="24">1:00 pm - 2:30 pm(TR)</option>
             <option value="25">2:40 pm- 3:40 pm(TR)</option>
             <option value="26">3:50 pm - 5:20 pm(TR)</option>
             <option value="27">5:30 pm - 7:00 pm(TR)</option>
             <option value="28">7:10 pm - 8:40 pm(TR)</option>
             <option value="29">8:50 pm - 10:20 pm(TR)</option>
             <option value="31">8:00 am - 9:30 am(TR)</option>
             <option value="32">9:40 am - 11:10 am(TR)</option>
             <option value="33">11:20 am - 12:50 pm(TR)</option>
             <option value="34">1:00 pm - 2:30 pm(TR)</option>
             <option value="35">2:40 pm - 3:40 pm(TR)</option>
             <option value="36">3:50 pm - 5:20 pm(TR)</option>
             <option value="37">5:30 pm- 7:00 pm(TR)</option>
             <option value="38">7:10 pm - 8:40 pm(TR)</option>
             <option value="39">8:50 pm - 10:20 pm(TR)</option>
             <option value="41">8:00 am - 9:30 am(TR)</option>
             <option value="42">9:40 am - 11:10 am(TR)</option>
             <option value="43">11:20 am- 12:50 pm(TR)</option>
             <option value="44">1:00 pm - 2:30 pm(TR)</option>
             <option value="45">2:40 pm - 3:40 pm(TR)</option>
             <option value="46">3:50 pm - 5:20 pm(TR)</option>
             <option value="47">5:30 pm - 7:00 pm(TR)</option>
             <option value="48">7:10 pm - 8:40 pm(TR)</option>
             <option value="49">8:50 pm - 10:20 pm(TR)</option>
             <option value="51">8:00 am - 9:30 am(F)</option>
             <option value="52">9:40 am - 11:10 am(F)</option>
             <option value="53">11:20 am - 12:50 pm(F)</option>
             <option value="54">1:00 pm - 2:30 pm(F)</option>
             <option value="55">2:40 pm - 3:40 pm(F)</option>
             <option value="56">3:50 pm- 5:20 pm(F)</option>
             <option value="57">5:30 pm - 7:00 pm(F)</option>
             <option value="58">7:10 pm - 8:40 pm(F)</option>
             <option value="59">8:50 pm - 10:20 pm(F)</option>
            </select><!--TIME ID-->
            <input type="text" name="Course_Name" placeholder="enter course name"><!--Course Name-->
             <select style="height: 30px; width: 90%; padding-bottom 10px;" name="Section" form="addCourse"><!--Section-->
             <option " - 001">1</option>
             <option " - 002">2</option>
             <option " - 003">3</option>
             <option " - 004">4</option>
             </select>
            <input type="text" name="open_seats" placeholder="number of seats"><!--Open Seats-->
            <input type="text" name="Course_Credits" placeholder="course credits"><!--Course Credits-->
            <select style="height: 30px; width: 90%; padding-bottom 10px;" name="Semester_ID" form="addCourse">
               <option value="" disabled selected>Select Semester</option> 
               <option value ="Spring 2019">Spring 2019</option>
               <option value ="Summer 2019">Summer 2019</option>
               <option value ="Fall 2019">Fall 2019</option>
               <option value ="Winter 2019">Winter 2019</option>
               
               <option value ="Spring 2020">Spring 2020</option>
               <option value ="Summer 2020">Summer 2020</option>
               <option value ="Fall 2020">Fall 2020</option>
               <option value ="Winter 2020">Winter 2020</option>
               
               <option value ="Spring 2022">Spring 2021</option>
               <option value ="Summer 2022">Summer 2021</option>
               <option value ="Fall 2022">Fall 2021</option>
               <option value ="Winter 2022">Winter 2021</option>
               
               <option value ="Spring 2022">Spring 2022</option>
               <option value ="Summer 2022">Summer 2022</option>
               <option value ="Fall 2022">Fall 2022</option>
               <option value ="Winter 2022">Winter 2022</option>
               
            </select><!--Semester ID-->
            <input type="text" name="Course_Description" placeholder="enter description"><!--Course Description-->
            <input type="text" name="Professor_ID" placeholder="enter professor ID"><!--Professor ID-->
            <select style="margin-bottom: 4px; height: 30px; width: 90%; padding-bottom 10px;" name="Department_ID" form="addCourse">
               <option value="" disabled selected>Select Department</option>
                <option value="10112">Politics Economics & Law</option>
                <option value="10113">Psychology</option>
                <option value="10114">Public Health</option>
                <option value="10115">School of Business</option>
                <option value="10116">School of Education</option>
                <option value="10117">Scoiology</option>
                <option value="10118">School of Professional Studies</option>
                <option value="10119">Visual Arts</option>
                <option value="101101">American Studies</option>
                <option value="101102">Biological Sciences</option>
                <option value="101103">Chemistry and Physics</option>
                <option value="101104">Computer Science</option>
                <option value="101105">English</option>
                <option value="101106">History and Philosophy</option>
                <option value="101107">Criminology</option>
                <option value="101108">Industrial & Labor Relations</option>
                <option value="101109">Liberal Arts</option>
                <option value="101110">Mathematics</option>
                <option value="101111">Modern Languages</option>
            </select><!--Department ID-->
            <input style="margin-top 5px; background: grey" type="submit" name="add-course">
                </form></div>
                
                 <div class="profile-box" style="float: left; border-style: solid; border-color: black; border-width: 2px; font-size: 10px; font-color: white; padding-left: 70px; padding-top: 10px; padding-bottom: 10px; margin-left: 30px; width: 450px; background-color:#d3d3d3; font-family: arial; border-radius: 10px;">
                    <p style="font-size:20px; padding-left: 130px;">Delete Course</p>
                    <form class="signup-form" action="courseManager.php" method="POST" id="deleteCourse" name="deleteCourse">
                    <input type="text" name="cDelete" placeholder="enter course to delete by ID">
                    <input style="margin-top 5px; background: red" type="submit" name="delete">
                    </form>
                    
                    </div>
                    ';
                    
                   
                    echo'<div class="profile-box" style="overflow-x: hidden; overflow: scroll; margin-right: 200px; position:relative; top: -560px; float: right; border-style: solid; border-color: black; border-width: 2px; font-size: 12px; font-color: white; padding-bottom: 10px; height: 670px; width: 850px; background-color:#d3d3d3; font-family: arial; border-radius: 10px;">';





$query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID

";
 
// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);
 

// If the query executed properly proceed
if($response){
echo'<h1 style="color: cadetblue;padding-top: 20px;padding-left:15px;">All Courses</h1>';
echo '<table style=" width: 70%;" align="left"
cellspacing="5" cellpadding="8">
<tr><td align="left"><b>Class ID</b></td>
<td align="left"><b>CRN</b></td>
<td align="left"><b>Course Name</b></td>
<td align="left"><b>Time</b></td>
<td align="left"><b>Day</b></td>
<td align="left"><b>Semester</b></td>
<td align="left"><b>Department</b></td>';
 
// mysqli_fetch_array will return a row of data from the query
// until no further data is available
  
while($row = mysqli_fetch_array($response)){
 
echo '<tr><td align="left">' . $row['Course_ID'] . '</td><td align="left">'. $row['CRN'] . '</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['Time_Slot'] . '</td><td align="left">' . $row['day'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Department_Name'] . '</td>';
 
echo '</tr>';
}

}
echo '</table>';
  ?>
     </div>
     
     
     
    </section>
    
    

</body>
    
</html>
}else{
    header("Location: ../index.php");
    exit();
}