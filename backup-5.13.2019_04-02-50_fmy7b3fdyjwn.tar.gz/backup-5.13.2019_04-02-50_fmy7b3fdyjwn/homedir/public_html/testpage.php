 <!DOCTYPE html>
<html>
<body>
    <?php
    session_start();
DEFINE ('DB_USER', 'omnicypher');
    
DEFINE ('DB_PASSWORD', 'S3RV3R!!');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'g6');
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
    $query = "SELECT * FROM course;

";
 
// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);
 

// If the query executed properly proceed
if($response){
echo'<h1 style="color: cadetblue;padding-top: 20px;padding-left:15px;">Master Schedule</h1>';
echo '<table style="width: 100%;" align="left"
cellspacing="5" cellpadding="8">
<tr><td align="left"><b>Descriptions</b></td>';
 
// mysqli_fetch_array will return a row of data from the query
// until no further data is available
  
while($row = mysqli_fetch_array($response)){
 
echo '<tr><td align="left">' . '<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a name="'.$row['Course_ID'].'">'.$row['Course_ID'].'	'.$row['Course_Name'].'</a></p><tr><td>'.'Description: '.$row['Course_Description'].'<td><tr>';
 
echo '</tr>';
}


echo '</table>';
}
    ?>
    
</body>
</html>
