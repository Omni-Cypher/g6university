<html>
<head>
    <Title></Title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div style=" width: 100%; height: auto;">
       <header>
     <div class ="main-wrapper">
          <div class="box1" style="background-color:lightblue; width: 100%;">
        <h1 style="text-align: center;">Group 6 University</h1>
         </div>
                 <?php
                 session_start();

                 $student_id = $_SESSION['student_id'];
                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $firstname = $_SESSION['firstname'];
                 $lastname = $_SESSION['lastname'];
                 $major = $_SESSION['major'];
                
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');

// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());

                    if(isset($_SESSION['username'])){
                        
                        //extra admin privlages
                        $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 1";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                        if($resultCheck>0){
                            $_SESSION['level'] = 1;
                           $level = $_SESSION['level'];
                        //if you are an admin
           
                        
                            echo '<nav>
                       
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                 
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="studentsearch.php">Search student</a></li>
                        <li><a href="accounts.php">Manage Accounts</a></li>
                        <li><a href="courseManager.php">Course Manager</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
         
                        //** add more admin abilities above **/    
                       
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form><div></nav>';
                            
                        }else{
                            
                         $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 0";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                           $_SESSION['level'] = 0;
                           $level = $_SESSION['level'];
                         //if you are an student user
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="StudentMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="degreeAudit.php">Degree Audit</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                               $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 2";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
              
                                //if you are an faculty

                                $_SESSION['level'] = 2;
                                $level =  $_SESSION['level'];
                           
                                
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="facultyMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="studentManager.php">Student Manager</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                            
                                 $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 3";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                                //you are a researcher
                            
                             $_SESSION['student_id'] = 0;
                                $_SESSION['level'] = 3;
                                $level =  $_SESSION['level'];
                     
                                
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="research.php">Research</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                         <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                            
                           }
                       }
                        
                     }
                  }
                }else{
                                echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                  
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
                         echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                   <button type="submit" name="submit">Login</button>
                    </form>
                    <!--<a href="signup.php">sign up</a></div></nav>-->';
                    }
                ?>
                  
                </div>

    </header>
     <style>
    @import url(https://fonts.googleapis.com/css?family=Roboto:300);

    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 50%;
    }

    td,
    th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(even) {
        background-color: #dddddd;
    }
    tr:hover{
     
    }

    .mschedual {
        align-content: center;

        height: 1400px;
        width: 750px;
        text-align: left;
        font-size: 20px;
        font-family: sans-serif;
        position: relative;
        background-color: cadetblue;
        margin-top: 20px;
        border: solid;
        border-color: white;
        border-width: thick;
        margin-left: 350px;
        margin-right: 350px;
        padding-left: 10px;
        padding-right: 10px;
    }


    .footer {
        
        position: relative;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: lightblue;
        color: white;
        text-align: center;
        padding-top: 10px;
    }

    .ft1 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .ft2 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .ft3 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .colimg {
        float: left;

    }

    .slink {
        size: 200px;
    }

    .logout {
        font-family: monospace;
        background-color: skyblue;
        color: black;
        position: absolute;
        top: -15px;
        right: -9px;
        border-radius: 5px;
        padding: 3px;
        width: 80px;
    }

    .msboxsub {
        height: 100%;
        width: 100%;
        position: relative;
        border: solid;
        border-color: white;
    }
</style>
    <section class="main-container">
      
            <?php 
            session_start();
            
            
                $fid;
                $cid;
                if($_SESSION['level'] == 2){
                      echo'<h2 style="color: white">Class Schedule</h2>
                        <div style="height:700px;">';
                
            
            
                  $name = $firstname.' '.$lastname;
                   $fid = $_SESSION['id'];
                    $sql ='SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
                                            FROM course 
                                            INNER JOIN timee
                                            ON course.Time_ID = timee.Time_ID
                                            INNER JOIN department
                                            ON course.Department_ID = department.Department_ID
                                            WHERE `Professor_ID` ='.$fid;
                                            
                                  $_SESSION['fid'] = $fid;          
                    $result = @mysqli_query($dbc,$sql);
                    if($result){
                        echo'<div style= "padding-left: 30px;">';
                        echo'<div style="padding-left: 20px;">Faculty Name: '.$name.'</div>';
                        echo'<h1 style="color: cadetblue;padding-top: 20px;padding-left:15px;">Class Schedule</h1>';
                echo '<table style="width: 95%;" align="left"
                cellspacing="5" cellpadding="8">
                <tr><td align="left"><b>Class ID</b></td>
                <td align="left"><b>CRN</b></td>
                <td align="left"><b>Course Name</b></td>
                <td align="left"><b>Time</b></td>
                <td align="left"><b>Day</b></td>
                <td align="left"><b>Semester</b></td>
                <td align="left"><b>Department</b></td>';

                        while($row = mysqli_fetch_array($result)){
                          echo '<tr><td align="left">' . $row['Course_ID'] . '</td><td align="left">'. $row['CRN'] . '</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['Time_Slot'] . '</td><td align="left">' . $row['day'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Department_Name'] . '</td>';
 
                        echo '</tr>';
                        }
                        echo'</table>';
                    }
                    
                    
               }else{
                  header('Location: index.php');
                  exit;
               }
               
            echo'</div>';    
          ?>      
         </div>     
        
    
     
     </div>
     
     
     
    </section>
    
    

</body>
    
</html>';
