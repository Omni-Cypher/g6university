<!DOCTYPE html>
<!-- html by Juvon Hyatt -->
<html>

<head>
    <meta charset="utf-8">
    <title>Group 6 University</title>
</head>
<style>
    @import url(https://fonts.googleapis.com/css?family=Roboto:300);

    .box1 {

        align-content: center;
        border: solid;
        background-color: cadetblue;
        height: 100px;
        width: 100%;
        text-align: center;
        font-size: 20px;
        font-family: roboto;
        position: relative;


    }

    .box2 {
        margin-right: 10px;
        align-content: left;
        float: left;
        height: 200px;
        width: 770px;
        text-align: left;
        font-size: 20px;
        font-family: sans-serif;
        position: relative;
        background-color: cadetblue;
        margin-top: 20px;
        border: solid;
        border-color: white;
        border-width: thick;
        left
    }

    .box3 {
        align-content: left;
        float: left;
        height: 200px;
        width: 720px;
        text-align: left;
        font-size: 20px;
        font-family: sans-serif;
        position: relative;
        background-color: cadetblue;
        margin-top: 20px;
        border: solid;
        border-color: white;
        border-width: thick;
    }

    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
    }

    td,
    th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(even) {
        background-color: #dddddd;
    }

    .mschedual {
        align-content: center;

        height: 1400px;
        width: 750px;
        text-align: left;
        font-size: 20px;
        font-family: sans-serif;
        position: relative;
        background-color: cadetblue;
        margin-top: 20px;
        border: solid;
        border-color: white;
        border-width: thick;
        margin-left: 350px;
        margin-right: 350px;
        padding-left: 10px;
        padding-right: 10px;
    }

    .h1 {
        color: black;
        font-size: 10px;
        font-family:
            font-family: "Roboto";
    }

    .navbox {
        color: darkcyan;
        align-content: center;
        text-align: center;
        padding-right: 10px;
        top: 10px;
        padding: 5px;
        font-family: sans-serif;
        background-color: cadetblue;
        position: relative;
        border-radius: 10px;
    }

    a:link {
        color: white;
        font-size: 150%;
        margin: 20px;
        text-decoration: none;

    }

    a:hover {

        color: white;
    }

    .logo {
        float: left;
        position: relative;
        left: 550px;
        top: 20px;

    }

    .footer {
        
        position: relative;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: lightblue;
        color: white;
        text-align: center;
        padding-top: 10px;
    }

    .ft1 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .ft2 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .ft3 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .colimg {
        float: left;

    }

    .slink {
        size: 200px;
    }

    .logout {
        font-family: monospace;
        background-color: skyblue;
        color: black;
        position: absolute;
        top: -15px;
        right: -9px;
        border-radius: 5px;
        padding: 3px;
        width: 80px;
    }

    .msboxsub {
        height: 100%;
        width: 100%;
        position: relative;
        border: solid;
        border-color: white;
    }
</style>

<body class="main" body style="background-color:powderblue;">

    <div class="box1" style="background-color:lightblue">
        <img class="logo" src="https://www.wilsoncc.edu/wp-content/uploads/2018/02/Graduation-Icon-1.png" alt="college logo" height="60" width="60" position="relative">
        <h1 style="font-family: roboto;">Group 6 University</h1>
    </div>
    <div class="navbox">
        <div><a href="index.php">Home</a> </div>
    <!--<div><a class="logout" href="Log%20In.html">Logout</a></div>-->
    </div>
      <div class="search"searchMethod" style="padding-left: 20px; padding-top: 50px;">
     
    <a href="courseSearch.php"><div style ="padding-left: 30px;background: lightgrey; border-radius: 9px; position: relative; height:30px; width: 290px;">Course Search / Register</div> </a>
    
<?php 
session_start();
DEFINE ('DB_USER', 'omnicypher');
    
DEFINE ('DB_PASSWORD', 'S3RV3R!!');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'g6');
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
    $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID

";
 
// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);
 

// If the query executed properly proceed
if($response){
echo'<h1 style="color: cadetblue;padding-top: 20px;padding-left:15px;">Master Schedule</h1>';
echo '<table style="width: 100%;" align="left"
cellspacing="5" cellpadding="8">
<tr><td align="left"><b>Class ID</b></td>
<td align="left"><b>CRN</b></td>
<td align="left"><b>Course Name</b></td>
<td align="left"><b>Time</b></td>
<td align="left"><b>Day</b></td>
<td align="left"><b>Semester</b></td>
<td align="left"><b>Department</b></td>';
 
// mysqli_fetch_array will return a row of data from the query
// until no further data is available
  
while($row = mysqli_fetch_array($response)){
 
echo '<tr><td align="left">' . $row['Course_ID'] . '</td><td align="left">'. $row['CRN'] . '</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['Time_Slot'] . '</td><td align="left">' . $row['day'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Department_Name'] . '</td>';
 
echo '</tr>';
}

 
echo '</table>';
 
} else {
 
echo "Couldn't issue database query<br />";
 
echo mysqli_error($dbc);
 
}
  
 
// Close connection to the database
mysqli_close($dbc);

    
    ?>
</body>
    <script>
        
    
    </script>


</html>

 