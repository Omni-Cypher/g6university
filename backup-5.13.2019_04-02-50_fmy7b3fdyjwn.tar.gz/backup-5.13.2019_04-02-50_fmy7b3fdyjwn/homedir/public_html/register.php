<?php session_start();
?>
<!DOCTYPE html>
<!-- html by Juvon Hyatt -->
<html>

<head>
    <meta charset="utf-8">
    <title>Group 6 University</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<style>
    @import url(https://fonts.googleapis.com/css?family=Roboto:300);

    .box1 {

        align-content: center;
        border: solid;
        background-color: cadetblue;
        height: 100px;
        width: 100%;
        text-align: center;
        font-size: 20px;
        font-family: roboto;
        position: relative;


    }

    .box2 {
        margin-right: 10px;
        align-content: left;
        float: left;
        height: 200px;
        width: 770px;
        text-align: left;
        font-size: 20px;
        font-family: sans-serif;
        position: relative;
        background-color: cadetblue;
        margin-top: 20px;
        border: solid;
        border-color: white;
        border-width: thick;
        left
    }

    .box3 {
        align-content: left;
        float: left;
        height: 200px;
        width: 720px;
        text-align: left;
        font-size: 20px;
        font-family: sans-serif;
        position: relative;
        background-color: cadetblue;
        margin-top: 20px;
        border: solid;
        border-color: white;
        border-width: thick;
    }

    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
    }

    td,
    th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(even) {
        background-color: #dddddd;
    }

    .mschedual {
        align-content: center;

        height: 1400px;
        width: 750px;
        text-align: left;
        font-size: 20px;
        font-family: sans-serif;
        position: relative;
        background-color: cadetblue;
        margin-top: 20px;
        border: solid;
        border-color: white;
        border-width: thick;
        margin-left: 350px;
        margin-right: 350px;
        padding-left: 10px;
        padding-right: 10px;
    }

    .h1 {
        color: black;
        font-size: 10px;
        font-family:
            font-family: "Roboto";
    }

    .navbox {
        color: darkcyan;
        align-content: center;
        text-align: center;
        padding-right: 10px;
        top: 10px;
        padding: 5px;
        font-family: sans-serif;
        background-color: cadetblue;
        position: relative;
        border-radius: 10px;
    }

    a:link {
        color: white;
        font-size: 150%;
        margin: 20px;
        text-decoration: none;

    }

    a:hover {

        text-shadow: 2px 2px darkblue;
    }

    .logo {
        float: left;
        position: relative;
        left: 550px;
        top: 20px;

    }

    .footer {
        
        position: relative;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: lightblue;
        color: white;
        text-align: center;
        padding-top: 10px;
    }

    .ft1 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .ft2 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .ft3 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .colimg {
        float: left;

    }

    .slink {
        size: 200px;
    }

    .logout {
        font-family: monospace;
        background-color: skyblue;
        color: black;
        position: absolute;
        top: -15px;
        right: -9px;
        border-radius: 5px;
        padding: 3px;
        width: 80px;
    }

    .msboxsub {
        height: 100%;
        width: 100%;
        position: relative;
        border: solid;
        border-color: white;
    }
</style>
<?php
session_start();
if(isset($_SESSION['username'])){
    
 if(isset($_POST['reg'])){
    $class_id = $_POST["class_id"];
 if(is_numeric($class_id)){
echo'<body class="main" body style="background-color:powderblue;">

    <div class="box1" style="background-color:lightblue">
      
        <h1 style="font-family: roboto;">Group 6 University</h1>
    </div>
    <div class="navbox">
        <div><a href="index.php">Home</a> <a href="MasterSchedule.php">Master Schedule</a></div>
    <!--<div><a class="logout" href="Log%20In.html">Logout</a></div>-->
    </div>
      <div class="search"searchMethod" style="padding-left: 20px; padding-top: 50px;">
     
    <a href="courseSearch.php">Register for Course</a>';
    
 

 if(isset($_SESSION['username'])){
$student_id = $_SESSION['student_id'];
$major = $_SESSION['major'];
DEFINE ('DB_USER', 'omnicypher');
    
DEFINE ('DB_PASSWORD', 'S3RV3R!!');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'g6');

$time1 = "0";
$time2 = "0"; 
$day ="";
$day2 = "";
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
if (isset($_POST["class_id"])) {
  


    $query = 'SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE course.Course_ID = '.$class_id;

}
 
// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);
 

// If the query executed properly proceed
if($response){
// mysqli_fetch_array will return a row of data from the query
// until no further data is available
  $rowws=0;
while($row = mysqli_fetch_array($response)){
 
echo '<tr><td align="left">' . $row['Course_ID'] . '</td><td align="left">'. $row['CRN'] . '</td><td align="left">' . $row['Course_Name'] . '</td>';
$time1 =  $row['Time_Slot'];
$day =  $row['day'];

$course_id =  $row['Course_ID'];
$course_crn = $row['CRN'];
$sourse_time = $row['Time_Slot'];
$course_name = $row['Course_Name'];
$classday  = $row['day'];



if($row['Semester_ID']=="Spring 2019"){
    $semester = "Spring 2019";
}
else if($row['Semester_ID']=="Summer 2019"){
    $semester = "Summer 2019";
}
else if($row['Semester_ID']=="Winter 2019"){
    $semester = "Winter 2019";
}

else if($row['Semester_ID']=="Fall 2019"){
    $semester = "Fall 2019";
}

if($time1==$time2 && $day==$day2){
    $count = $count +1;
}

echo '</tr>';
}

echo '</table>';
} else {
 
echo "Couldn't issue database query<br />";
 
echo mysqli_error($dbc);
 
}



      $query2 = 'SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
INNER JOIN schedulee
ON course.Course_ID = schedulee.Course_ID
WHERE Student_ID = '.$student_id;

 $qHold ="SELECT * FROM holds
INNER JOIN student
ON holds.Hold_ID = student.Hold_ID
Where student.Student_ID = '$student_id'
"; //checking for holds


// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query2);
$response2 = @mysqli_query($dbc, $qHold);


// If the query executed properly proceed
if($response){
    

// mysqli_fetch_array will return a row of data from the query
// until no further data is available
 $count = 0;

 $holds = 0;
while($row = mysqli_fetch_array($response)){

$time2=  $row['Time_Slot'];
$day2 =  $row['day'];

echo '</tr>';

if($time1==$time2 && $day==$day2){
    $count = $count +1;
}

}

while($row = mysqli_fetch_array($response2)){
$holds++;
}
$sem = "SELECT * FROM CurrentSemester WHERE entry_number = 0";
$res= @mysqli_query($dbc, $sem);
$currentSemester ="Summer 2019";
while($row = mysqli_fetch_array($res)){
$currentSemester = $row['semester'];
}
$theCount = 0;
#echo $currentSemester;
$query3 = 'SELECT * FROM `schedulee` INNER JOIN course on course.Course_ID = schedulee.Course_ID WHERE Student_ID = '.$student_id.' and Semester_ID = "'.$currentSemester.'"  ';  //counting if there are more than 4 classes
$response3 = @mysqli_query($dbc, $query3);
while($row = mysqli_fetch_array($response3)){
$theCount = $theCount+1; //counting classes
    

}

if($count>0){
    echo' Status: Time clash, cannot add class!!!';
}else if($count==0){
    
    if($holds==0){
        if($theCount>=4){
        
            echo'<br><div style="color:red; padding-left: 20px;">Cannot add class, Over 16 credits</div>';
        }else{
            if($semester=="Spring 2019"){
                echo'Error: Cannot register for past semester';
            }else{
                $reqCheck = 0;
                $prereq = 0;
                 $toCheck = "No";
                if($major == "Computer Science"){
                    $getPre = "SELECT * FROM CS_Major WHERE Course_ID = '$class_id' ";
                    $getPrereq = @mysqli_query($dbc, $getPre);
                    if($getPrereq){
                         while($row = mysqli_fetch_array($getPrereq)){
                             if($row['Prerequisite_ID'] > 0){
                                 $prereq = $row['Prerequisite_ID'];
                                  $toCheck = "Yes";
                             }
                     
                    }
                    }
                }
                if($major == "History" || $major == "American Studies"){
                    $getPre = "SELECT * FROM History_Major WHERE Course_ID = '$class_id' ";
                    $getPrereq = @mysqli_query($dbc, $getPre);
                    if($getPrereq){
                         while($row = mysqli_fetch_array($getPrereq)){
                             if($row['Prerequisite_ID'] > 0){
                                 $prereq = $row['Prerequisite_ID'];
                                  $toCheck = "Yes";
                             }
                     
                    }
                    }
                }
                
                //search if class has prereq of the selected course
                $check = "SELECT * FROM transcript WHERE Student_ID = '$student_id' and Course_ID = '$prereq";
                $preResult = @mysqli_query($dbc,$check);
                
                if($preResult){
                    while($row = mysqli_fetch_array($preResult)){
                        $reqCheck = $reqCheck + 1;
                    }
                }
                
                //count +1 if it does 
                if($reqCheck == 0 &&  $toCheck == "Yes"){
                    echo'<br><div style="color:red; padding-left: 20px;">Cannot register class '.$class_id.', Prerequisite ID: '.$prereq.' for '.$major.' Major not satisfied!!!</div>';
                }else{

$start_date = '2019-05-01';

$end_date = '2020-09-05';

$date_from_user = date("Y/m/d");


function check_in_range($start_date, $end_date, $date_from_user)
{
  // Convert to timestamp
  $start_ts = strtotime($start_date);
  $end_ts = strtotime($end_date);
  $user_ts = strtotime($date_from_user);

  // Check that user date is between start & end
  return (($user_ts >= $start_ts) && ($user_ts <= $end_ts));
}



if(!check_in_range($start_date, $end_date, $date_from_user)){
     echo'<br><div style="color:red; padding-left: 20px;">Cannot register, Registration period over!!!</div>';
}else{


    $sql3 = 'INSERT INTO schedulee VALUES (0,'.$student_id.','.$class_id.')';
   
   $sql4 = 'INSERT INTO transcript VALUES(0,'.$student_id.','.$class_id.', "N/A","'.$semester.'",4)';


    mysqli_query($dbc,$sql3)
or die(mysqli_error($dbc));

    mysqli_query($dbc,$sql4)
or die(mysqli_error($dbc));
     echo' Status: Class successfully Registered!!!'; 
     
     
     $rowws=0;
                }
               }
   }
   }
        
    }else{
        echo'<br><div style="color:red; padding-left: 20px;">Cannot register, Hold exists!!!</div>';
    }
}



echo '</table>';

 
} else {
 
echo "Couldn't issue database query<br />";
 
echo mysqli_error($dbc);
 
}
 
$response = @mysqli_query($dbc, $query2);
 
// If the query executed properly proceed
if($response){
 //echo '<br><div style="padding-left:20px;">Classes: '.$theCount.'</div>';
echo'<h1 style="color: white;padding-top: 20px;padding-left:15px;">Registered Classes</h1>';
echo '<table align="left"
cellspacing="5" cellpadding="8">
<tr><td align="left"><b>Course ID</b></td>
<td align="left"><b>CRN</b></td>
<td align="left"><b>Course Name</b></td>
<td align="left"><b>Time</b></td>
<td align="left"><b>Day</b></td>
<td align="left"><b>Semester</b></td>
<td align="left"><b>Department</b></td>';

// mysqli_fetch_array will return a row of data from the query
// until no further data is available
 $count = 0;
 $rowws=0;
while($row = mysqli_fetch_array($response)){
    
echo '<tr><td align="left">' . $row['Course_ID'] . '</td><td align="left">'. $row['CRN'] . '</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['Time_Slot'] . '</td><td align="left">' . $row['day'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Department_Name'] . '</td>';
 

$time2=  $row['Time_Slot'];
$day2 =  $row['day'];
$rowws2++;
 
if($time1==$time2 && $day==$day2){
    $count = $count +1;
}
echo '</tr>';

}
if($rowws2<4){
   
     echo' <div style="color:red">Warining: you are not a fulltime student. credits lower than 16 </div><br>';
}

     ?>
    <form>
<input style="margin-left: 30px;" type="button" value="Go to Student Home" onclick="window.location.href='http://g6university.com/StudentMain.php'" />
</form>
<?php

    ?>
    <form>
    <input style="margin-left: 30px;" type="button" value="Add Class " onclick="window.location.href='http://g6university.com/courseSearch.php'" />
    </form>
    
    <form method="POST" action="register.php">
    <input style="margin-left: 30px;" type="text" name="drop_id" placeholder="enter class ID">
     <Button type="submit" name="drop_class">Drop Class</Button>
    </form>
    <?php


echo '</table>';
 
} else {
 
echo "Couldn't issue database query<br />";
 
echo mysqli_error($dbc);
 
}
 
}
  
 
// Close connection to the database
mysqli_close($dbc);

 }else{
     header("Location: searchedCourse.php");
     $_SESSION['ERROR']="ERROR: Course ID must be numeric!!!!!!";
     exit();
      
 }   
    


}
 if(isset($_POST['drop_class'])){
     $theCount = 0;
    $class_id = $_POST["drop_id"];
echo'<body class="main" body style="background-color:powderblue;">

    <div class="box1" style="background-color:lightblue">
      
        <h1 style="font-family: roboto;">Group 6 University</h1>
    </div>
    <div class="navbox">
        <div><a href="index.php">Home</a> <a href="index.php">Master Schedule</a></div>
    <!--<div><a class="logout" href="Log%20In.html">Logout</a></div>-->
    </div>
      <div class="search"searchMethod" style="padding-left: 20px; padding-top: 50px;">
     
    <a href="courseSearch.php">Register for Course</a>';
    
 

 if(isset($_SESSION['username'])){
$student_id = $_SESSION['student_id'];
DEFINE ('DB_USER', 'omnicypher');
    
DEFINE ('DB_PASSWORD', 'S3RV3R!!');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'g6');


 
$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
 

    $query = 'SELECT * FROM `schedulee` WHERE Course_ID = '.$class_id.' and Student_ID = '.$student_id;
     $qHold ="SELECT * FROM holds
INNER JOIN student
ON holds.Hold_ID = student.Hold_ID
Where student.Student_ID = '$student_id'
";
// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);

$response2 = @mysqli_query($dbc, $qHold);

// If the query executed properly proceed
if($response){
// mysqli_fetch_array will return a row of data from the query
// until no further data is available
 $rowws = 0;
 $holds = 0;
$theCount = 0;
while($row = mysqli_fetch_array($response)){




$time1 =  $row['Time_Slot'];
$day =  $row['day'];

$course_id =  $row['Course_ID'];
$course_crn = $row['CRN'];
$sourse_time = $row['Time_Slot'];
$course_name = $row['Course_Name'];
$classday  = $row['day'];
$theCount = $theCount + 1;
 


echo '</tr>';
}

while($row = mysqli_fetch_array($response2)){
    $holds++;
}



echo '</table>';
 
} 

if($theCount== 0){
    echo' You are not registered for this class';
}
if($theCount >0){
    echo' Class successfully dropped!';
    echo $theCount;
}
if($holds==0){
     
 $del = 'DELETE FROM transcript WHERE Course_ID = '.$class_id.' and Student_ID = '.$student_id;
 
    mysqli_query($dbc,$del)
or die(mysqli_error($dbc));
 $query = 'DELETE FROM `schedulee` WHERE Course_ID = '.$class_id.' and Student_ID = '.$student_id;
 

}else{
    echo'Holds exists, Cannot drop class.';
}
$sem = "SELECT * FROM CurrentSemester WHERE entry_number = 0";
$res= @mysqli_query($dbc, $sem);
$currentSemester ="Summer 2019";
while($row = mysqli_fetch_array($res)){
$currentSemester = $row['semester'];
}
$theCount = 0;
#echo $currentSemester;
$query3 = 'SELECT * FROM `schedulee` INNER JOIN course on course.Course_ID = schedulee.Course_ID WHERE Student_ID = '.$student_id.' and Semester_ID = "'.$currentSemester.'"  ';  //counting if there are more than 4 classes
$response3 = @mysqli_query($dbc, $query3);
while($row = mysqli_fetch_array($response3)){
$theCount = $theCount+1; //counting classes
    

}
if($theCount<4){
    echo' <div style="color:red">Warining: you are not a fulltime student. credits lower than 16</div>';
}

 
// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);
 

// If the query executed properly proceed
if($response){
// mysqli_fetch_array will return a row of data from the query
// until no further data is available
  
while($row = mysqli_fetch_array($response)){




echo '</tr>';
}

echo '</table>';
 
} 

      $query2 = 'SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
INNER JOIN schedulee
ON course.Course_ID = schedulee.Course_ID
WHERE Student_ID = '.$student_id;

 
// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query2);
 
// If the query executed properly proceed
if($response){
    
echo '<br><div style="padding-left:20px;">Classes: '.$theCount.'</div>';
echo'<h1 style="color: white;padding-top: 20px;padding-left:15px;">Registered Classes</h1>';
echo '<table align="left"
cellspacing="5" cellpadding="8">
<tr><td align="left"><b>Course ID</b></td>
<td align="left"><b>CRN</b></td>
<td align="left"><b>Course Name</b></td>
<td align="left"><b>Time</b></td>
<td align="left"><b>Day</b></td>
<td align="left"><b>Semester</b></td>
<td align="left"><b>Department</b></td>';

// mysqli_fetch_array will return a row of data from the query
// until no further data is available
 $count = 0;
 $rowws=0;
while($row = mysqli_fetch_array($response)){
    
echo '<tr><td align="left">' . $row['Course_ID'] . '</td><td align="left">'. $row['CRN'] . '</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['Time_Slot'] . '</td><td align="left">' . $row['day'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Department_Name'] . '</td>';
 
$time2=  $row['Time_Slot'];
$day2 =  $row['day'];
$rowws++;
if($time1==$time2 && $day==$day2){
    $count = $count +1;
}
echo '</tr>';

}
    ?>
        
    <form>
    <input style="margin-left: 30px;" type="button" value="Go to Student Home" onclick="window.location.href='http://g6university.com/StudentMain.php'" />
    </form>


    <form>
    <input style="margin-left: 30px;" type="button" value="Add Class " onclick="window.location.href='http://g6university.com/courseSearch.php'" />
    </form>
    
    <form method="POST" action="register.php">
    <input style="margin-left: 30px;" type="text" name="drop_id" placeholder="enter class ID">
     <Button type="submit" name="drop_class">Drop Class</Button>
    </form>
    <?php

echo '</table>';

 
} else {
 
echo "Couldn't issue database query<br />";
 
echo mysqli_error($dbc);
 
}
  
 
// Close connection to the database
mysqli_close($dbc);

 }else{
     header("location: index.php");
      echo'Must be logged in';
      echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                    <button type="submit" name="submit">Login</button>
                    </form> ';
      
 }   
    

}
if(isset($_POST['regInfo'])){

echo'<body class="main" body style="background-color:powderblue;">

    <div class="box1" style="background-color:lightblue">
        <h1 style="font-family: roboto;">Group 6 University</h1>
    </div>
    <div class="navbox">
        <div><a href="index.php">Home</a> <a href="index.php">Master Schedule</a></div>
    <!--<div><a class="logout" href="Log%20In.html">Logout</a></div>-->
    </div>
      <div class="search"searchMethod" style="padding-left: 20px; padding-top: 50px;">
     
    <a href="courseSearch.php">Register for Course</a>';
    
 

 if(isset($_SESSION['username'])){
$student_id = $_SESSION['student_id'];
DEFINE ('DB_USER', 'omnicypher');
    
DEFINE ('DB_PASSWORD', 'S3RV3R!!');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'g6');


 
$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
 

    $query = 'SELECT * FROM `schedulee` WHERE Course_ID = '.$class_id.' and Student_ID = '.$student_id;
     $qHold ="SELECT * FROM holds
INNER JOIN student
ON holds.Hold_ID = student.Hold_ID
Where student.Student_ID = '$student_id'
";
// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);

$response2 = @mysqli_query($dbc, $qHold);



$query3 = 'SELECT * FROM `schedulee` INNER JOIN course on course.Course_ID = schedulee.Course_ID WHERE Student_ID = '.$student_id.' and Semester_ID = "Summer 2019"';  //counting if there are more than 4 classes
$response3 = @mysqli_query($dbc, $query3);
$rowws2= 0;
while($row = mysqli_fetch_array($response3)){
$rowws2 = $rowws2+1; //counting classes
     #echo'rows: '.$rowws2;
} 

if($rowws2<4){
    #echo' rows: '.$rowws2;
    echo' <div style="color:red">Warining: you are not a fulltime student. credits lower than 16</div>';
}

 
// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);
 

// If the query executed properly proceed
if($response){
// mysqli_fetch_array will return a row of data from the query
// until no further data is available
  
while($row = mysqli_fetch_array($response)){




echo '</tr>';
}

echo '</table>';
 
} 

      $query2 = 'SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
INNER JOIN schedulee
ON course.Course_ID = schedulee.Course_ID
WHERE Student_ID = '.$student_id;

 
// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query2);
 
// If the query executed properly proceed
if($response){
    

echo'<h1 style="color: white;padding-top: 20px;padding-left:15px;">Registered Classes</h1>';
echo '<table align="left"
cellspacing="5" cellpadding="8">
<tr><td align="left"><b>Course ID</b></td>
<td align="left"><b>CRN</b></td>
<td align="left"><b>Course Name</b></td>
<td align="left"><b>Time</b></td>
<td align="left"><b>Day</b></td>
<td align="left"><b>Semester</b></td>
<td align="left"><b>Department</b></td>';

// mysqli_fetch_array will return a row of data from the query
// until no further data is available
 $count = 0;
 $rowws=0;
while($row = mysqli_fetch_array($response)){
    
echo '<tr><td align="left">' . $row['Course_ID'] . '</td><td align="left">'. $row['CRN'] . '</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['Time_Slot'] . '</td><td align="left">' . $row['day'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Department_Name'] . '</td>';
 
$time2=  $row['Time_Slot'];
$day2 =  $row['day'];
$rowws++;
if($time1==$time2 && $day==$day2){
    $count = $count +1;
}
echo '</tr>';

}
    ?>
        
    <form>
    <input style="margin-left: 30px;" type="button" value="Go to Student Home" onclick="window.location.href='http://g6university.com/StudentMain.php'" />
    </form>


    <form>
    <input style="margin-left: 30px;" type="button" value="Add Class " onclick="window.location.href='http://g6university.com/courseSearch.php'" />
    </form>
    
    <form method="POST" action="register.php">
    <input style="margin-left: 30px;" type="text" name="drop_id" placeholder="enter class ID">
     <Button type="submit" name="drop_class">Drop Class</Button>
    </form>
    <?php

echo '</table>';

 
} else {
 
echo "Couldn't issue database query<br />";
 
echo mysqli_error($dbc);
 
}
  
 
// Close connection to the database
mysqli_close($dbc);

 }else{
     header("location: index.php");
      echo'Must be logged in';
      echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                    <button type="submit" name="submit">Login</button>
                    </form> ';
      
 }   
    

}


     
 


}else{
    header("Location: searchedCourse.php");
}
?>
</body>
    <script>
        
    
    </script>


</html>

 