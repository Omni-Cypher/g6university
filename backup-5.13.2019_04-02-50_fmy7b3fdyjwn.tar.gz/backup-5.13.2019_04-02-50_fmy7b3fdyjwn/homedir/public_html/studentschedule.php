<?php
session_start();
?>
<!DOCTYPE html>
<!-- html by Juvon Hyatt -->
<html>

<head>
    <meta charset="utf-8">
    <title>Group 6 University</title>
</head>
<style>
    @import url(https://fonts.googleapis.com/css?family=Roboto:300);

    .box1 {

        align-content: center;
        border: solid;
        background-color: cadetblue;
        height: 100px;
        width: 100%;
        text-align: center;
        font-size: 20px;
        font-family: roboto;
        position: relative;


    }

    .box2 {
        margin-right: 10px;
        align-content: left;
        float: left;
        height: 200px;
        width: 770px;
        text-align: left;
        font-size: 20px;
        font-family: sans-serif;
        position: relative;
        background-color: cadetblue;
        margin-top: 20px;
        border: solid;
        border-color: white;
        border-width: thick;
        left
    }

    .box3 {
        align-content: left;
        float: left;
        height: 200px;
        width: 720px;
        text-align: left;
        font-size: 20px;
        font-family: sans-serif;
        position: relative;
        background-color: cadetblue;
        margin-top: 20px;
        border: solid;
        border-color: white;
        border-width: thick;
    }

    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
    }

    td,
    th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(even) {
        background-color: #dddddd;
    }

    .mschedual {
        align-content: center;

        height: 1400px;
        width: 750px;
        text-align: left;
        font-size: 20px;
        font-family: sans-serif;
        position: relative;
        background-color: cadetblue;
        margin-top: 20px;
        border: solid;
        border-color: white;
        border-width: thick;
        margin-left: 350px;
        margin-right: 350px;
        padding-left: 10px;
        padding-right: 10px;
    }

    .h1 {
        color: black;
        font-size: 10px;
        font-family:
            font-family: "Roboto";
    }

    .navbox {
        color: darkcyan;
        align-content: center;
        text-align: center;
        padding-right: 10px;
        top: 10px;
        padding: 5px;
        font-family: sans-serif;
        background-color: cadetblue;
        position: relative;
        border-radius: 10px;
    }

    a:link {
        color: white;
        font-size: 150%;
        margin: 20px;
        text-decoration: none;

    }

    a:hover {

        text-shadow: 2px 2px darkblue;
    }

    .logo {
        float: left;
        position: relative;
        left: 550px;
        top: 20px;

    }

    .footer {
        
        position: relative;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: lightblue;
        color: white;
        text-align: center;
        padding-top: 10px;
    }

    .ft1 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .ft2 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .ft3 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .colimg {
        float: left;

    }

    .slink {
        size: 200px;
    }

    .logout {
        font-family: monospace;
        background-color: skyblue;
        color: black;
        position: absolute;
        top: -15px;
        right: -9px;
        border-radius: 5px;
        padding: 3px;
        width: 80px;
    }

    .msboxsub {
        height: 100%;
        width: 100%;
        position: relative;
        border: solid;
        border-color: white;
    }
</style>

<body class="main" body style="background-color:powderblue;">

    <div class="box1" style="background-color:lightblue">
      
        <h1 style="font-family: roboto;">Group 6 University</h1>
    </div>
    <div class="navbox">
        <div><a href="index.php">Home</a> <a href="index.php">Master Schedule</a></div>
        
        
        
    <!--<div><a class="logout" href="Log%20In.html">Logout</a></div>-->
    </div>
      <div class="search"searchMethod" style="padding-left: 20px; padding-top: 50px;">
     
<?php 
$id = $_SESSION['id'];
$student_id = $_SESSION['student_id'];
DEFINE ('DB_USER', 'omnicypher');
    
DEFINE ('DB_PASSWORD', 'S3RV3R!!');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'g6');

 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
if(isset($_POST['viewStudentSchedule'])){
   $dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());

$student_id = $_POST['viewStudentSchedule'];
    $query = 'SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
INNER JOIN schedulee
ON course.Course_ID = schedulee.Course_ID
WHERE Student_ID = '.$student_id;

// Get a response from the database by sending the connection
// and the query


      $query = 'SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
INNER JOIN schedulee
ON course.Course_ID = schedulee.Course_ID
WHERE Student_ID = '.$student_id;

$response = @mysqli_query($dbc, $query);

// If the query executed properly proceed
if($response){
echo'<h1 style="color: white;padding-top: 20px;padding-left:15px;">Student Schedule</h1>';
echo '<table align="left"
cellspacing="5" cellpadding="8">
<tr><td align="left"><b>Course ID</b></td>
<td align="left"><b>CRN</b></td>
<td align="left"><b>Course Name</b></td>
<td align="left"><b>Time</b></td>
<td align="left"><b>Day</b></td>
<td align="left"><b>Semester</b></td>
<td align="left"><b>Department</b></td>';
 
// mysqli_fetch_array will return a row of data from the query
// until no further data is available
  
while($row = mysqli_fetch_array($response)){

echo '<tr><td align="left">' . $row['Course_ID'] . '</td><td align="left">'. $row['CRN'] . '</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['Time_Slot'] . '</td><td align="left">' . $row['day'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Department_Name'] . '</td><td align="left">'.'<a href="#'.$row['Course_ID'].'">Details</a></td></tr>';
 
echo '</tr>';
}

 
echo '</table>';
   
   
   
   
   
   
   
   
   
   
} 
   
}
if($_SESSION['level']==0){
 
$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
    $query = 'SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
INNER JOIN schedulee
ON course.Course_ID = schedulee.Course_ID
WHERE Student_ID = '.$student_id;

// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);
if (isset($_POST["class_id"])) {
      $query = 'SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
INNER JOIN schedulee
ON course.Course_ID = schedulee.Course_ID
WHERE Student_ID = '.$student_id;

}  

// If the query executed properly proceed
if($response){
echo'<h1 style="color: white;padding-top: 20px;padding-left:15px;">Student Schedule</h1>';
echo '<table align="left"
cellspacing="5" cellpadding="8">
<tr><td align="left"><b>Course ID</b></td>
<td align="left"><b>CRN</b></td>
<td align="left"><b>Course Name</b></td>
<td align="left"><b>Time</b></td>
<td align="left"><b>Day</b></td>
<td align="left"><b>Semester</b></td>
<td align="left"><b>Department</b></td>';
 
// mysqli_fetch_array will return a row of data from the query
// until no further data is available
  
while($row = mysqli_fetch_array($response)){

echo '<tr><td align="left">' . $row['Course_ID'] . '</td><td align="left">'. $row['CRN'] . '</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['Time_Slot'] . '</td><td align="left">' . $row['day'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Department_Name'] . '</td><td align="left">'.'<a href="#'.$row['Course_ID'].'">Details</a></td></tr>';
 
echo '</tr>';
}

 
echo '</table>';
?>
    
    <form action="register.php" method="post">
    <input style="margin-left: 30px;" type="submit" name="regInfo" value="manage classes">
    </form>
    

    <?php
    
    
 
} else {
 
echo "Couldn't issue database query<br />";
 
echo mysqli_error($dbc);
 
}
}
else if($_SESSION['level']==2){
    
    if($_POST['searchSC']){
       $student_id= $_POST['theID'];
       
        $dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
    $query = 'SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
INNER JOIN schedulee
ON course.Course_ID = schedulee.Course_ID
WHERE Student_ID = '.$student_id;

$q2 = 'SELECT * FROM student WHERE Student_ID = '.$student_id;
$q2r = @mysqli_query($dbc, $q2);

// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);
#echo' Student ID: '.$student_id;
if($q2r){
    
echo '<table align="left"
cellspacing="5" cellpadding="8">
<tr><td align="left"><b>Student ID</b></td>
<td align="left"><b>Student Name</b></td>
<td align="left"><b>Advisor Name</b></td>';

while($row = mysqli_fetch_array($q2r)){
   echo '<tr><td align="left">' .$row['Student_ID'] . '</td><td align="left">' .$row['Student_Name'] . '</td><td align="left">' . $row['Advisor_Name'] .'<td><tr>';
    }
}
// If the query executed properly proceed
if($response){
echo'<h1 style="color: white;padding-top: 20px;padding-left:15px;">Student Schedule</h1>';
echo '<table align="left"
cellspacing="5" cellpadding="8">
<tr><td align="left"><b>Course ID</b></td>
<td align="left"><b>CRN</b></td>
<td align="left"><b>Course Name</b></td>
<td align="left"><b>Time</b></td>
<td align="left"><b>Day</b></td>
<td align="left"><b>Semester</b></td>
<td align="left"><b>Department</b></td>';
 
// mysqli_fetch_array will return a row of data from the query
// until no further data is available
  
while($row = mysqli_fetch_array($response)){

echo '<tr><td align="left">' . $row['Course_ID'] . '</td><td align="left">'. $row['CRN'] . '</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['Time_Slot'] . '</td><td align="left">' . $row['day'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Department_Name'] . '</td><td align="left">'.'<a href="#'.$row['Course_ID'].'">Details</a></td></tr>';
 
echo '</tr>';
}

 
echo '</table>';
        
    }
    
}
    
    
    echo'<form action="studentschedule.php" method="POST">
    <input type="text" placeholder="enter student id" name="theID">
    <input type="submit" value="submit" name="searchSC">
    </form>';
 $sql = 'Select * FROM student where Student_id = '.$theId;
}

 
// Close connection to the database


    
    ?>
 <?php
 
    echo'<div  style="margin-top:20px; height: 180px; width: 380px; overflow: hidden; border-style: solid;";>
    <div style="overflow: scroll; overflow: hidden; height: 200px; width: 400px; overflow-x: hidden; overflow: scroll; " >
    <!--<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a name="info">this is the info</a></p>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a name="2466">2466	PE4325	Jurisprudence: Legal Thought - 002</a></p>
    
     <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a name="2210">2210	PH4920	Special Topics in Public Health - 002</a></p>
    
     <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a name="26">26	AS2252	US Social Movement - 002</a></p>
    
     <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a name="114">114	AS421	Critical Ideas in American History - 002</a></p>
    
     <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a name="1">1	AS1282	Intro To African American Studies - 001</a></p>
    
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a name="5">5	AS1282	Introduction to African American Studies - 001</a></p>
    
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a name="13">13	AS2252	US Social Movement - 001</a></p>
    
    
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a name="2">2	AS2252	US Social Movement - 001</a></p>
    
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a name="29">29	AS2262	African American History I - 001</a></p>-->';
    
   session_start();
DEFINE ('DB_USER', 'omnicypher');
    
DEFINE ('DB_PASSWORD', 'S3RV3R!!');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'g6');
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
    $query = "SELECT * FROM course;

";
 
// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);
 

// If the query executed properly proceed
if($response){
echo '<table style="width: 110%;" align="left"
cellspacing="5" cellpadding="8">
<tr><td align="left"><b>Descriptions</b></td>';
 
// mysqli_fetch_array will return a row of data from the query
// until no further data is available
  
while($row = mysqli_fetch_array($response)){
 
echo '<tr style="background: white";><td style="background: white"; align="left">' . '<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    <p><a style="padding-top: 8px;" name="'.$row['Course_ID'].'">'.$row['Course_ID'].'	'.$row['Course_Name'].'</a></p><tr><td>'.'Description: '.$row['Course_Description'].'<td><tr>';
 
echo '</tr>';
}


echo '</table>';
}
    
    mysqli_close($dbc);
    ?>
    
    </div>
    </div>
</body>
    <script>
        
    
    </script>


</html>

 