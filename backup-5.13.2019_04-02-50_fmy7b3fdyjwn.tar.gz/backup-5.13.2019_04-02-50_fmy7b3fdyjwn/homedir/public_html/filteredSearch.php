<!DOCTYPE html>
<!-- html by Juvon Hyatt -->
<html>

<head>
    <meta charset="utf-8">
    <title>Group 6 University</title>
</head>
<title>Search Student</title>

<body class="main" body style="background-color:powderblue;">
<?php
DEFINE ('DB_USER', 'omnicypher');
    
DEFINE ('DB_PASSWORD', 'S3RV3R!!');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'g6');
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
   
             echo'<b><h1 style="padding-top: 50px; padding-left: 40px;";>SEARCH STUDENT</h1></b>
    <div style="padding-left: 40px;">
    <p style="float: left">Day Search</p>
    <form action="searchedCourse.php" method="post">
    <input type="text" name ="search"/>
    <Button type="submit" name="submit">Search</Button>
    </form></div>';
      
   
?>
</body>
</html>