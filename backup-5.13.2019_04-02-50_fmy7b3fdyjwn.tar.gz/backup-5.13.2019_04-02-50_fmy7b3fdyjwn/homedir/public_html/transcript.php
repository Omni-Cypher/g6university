<html>
<head>
    <Title></Title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<style>
    @import url(https://fonts.googleapis.com/css?family=Roboto:300);

    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
    
    }

    td,
    th {
        border: 2px solid cadetblue;
        text-align: left;
        padding: 8px;
    }
    tr{
         background-color: lightGray;
    }

    tr:nth-child(odd) {
        background-color: #ffffff;
    }

    .mschedual {
        align-content: center;

        height: 1400px;
        width: 750px;
        text-align: left;
        font-size: 20px;
        font-family: sans-serif;
        position: relative;
        background-color: cadetblue;
        margin-top: 20px;
        border: solid;
        border-color: white;
        border-width: thick;
        margin-left: 350px;
        margin-right: 350px;
        padding-left: 10px;
        padding-right: 10px;
    }
    h4{
       margin:3px;
       font-size: 150%;
    }

   
</style>
<body>
    <header>
     <div class ="main-wrapper">
          <div class="box1" style="background-color:lightblue">
       
        <h1  style="text-align: center;">Group 6 University</h1>
         </div>
         

                 <?php
                 session_start();

                
                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $username = $_SESSION['username'];
                 
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');
                
                
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());

                 
                 
                 
                    if(isset($_SESSION['username'])){
                        
                        //extra admin privlages
                        $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level>0";
                       
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        if($resultCheck>0){
                            
                           $_SESSION['level'] = 1;
                           $level = $_SESSION['level'];
                        //if you are an admin
                        
                            echo '<nav>
                       
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="coursecatalog.php">Course Catalog</a></li>
                        <li><a href="studentsearch.php">Search Student</a></li>
                        <li><a href="addstudent2.php">Add Student</a></li>
                    </ul>
                        <div class="nav-login">';
         
                        //** add more admin abilities above **/    
                       
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form>';
                            
                        }else{
                         //if you are an regular user
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="StudentMain.php">My Profile</a></li>
                      
                        <li><a href="coursecatalog.php">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form>';   
                        }
                }else{
                                echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="StudentMain.php">Student</a></li>
          
                        <li><a href="coursecatalog.php">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
                         echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                    <button type="submit" name="submit">Login</button>
                    </form>
                    <a href="signup.php">sign up</a>';
                    }
             mysqli_close($dbc); ?>
                  
                </div>

    </header>
    
<body class="main" body style="background-color:powderblue;">
<div class="studentinfo">
<?php
// Get a connection for the database
session_start();
          
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $student_id = $_SESSION['student_id'];

                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');
     
                
                
 
// $dcc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dcc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
 

if(isset($_SESSION['username'])){
 



$spring = "SELECT * FROM transcript 
INNER JOIN course
ON course.Course_ID = transcript.Course_ID
WHERE student_id ='$student_id'
and 
course.Semester_ID = 'Spring 2019'";

$summer = "SELECT * FROM transcript 
INNER JOIN course
ON course.Course_ID = transcript.Course_ID
WHERE student_id ='$student_id'
and 
course.Semester_ID = 'Summer 2019'";

$fall = "SELECT * FROM transcript 
INNER JOIN course
ON course.Course_ID = transcript.Course_ID
WHERE student_id ='$student_id'
and 
course.Semester_ID = 'Fall 2019'";

$winter = "SELECT * FROM transcript 
INNER JOIN course
ON course.Course_ID = transcript.Course_ID
WHERE student_id ='$student_id'
and 
course.Semester_ID = 'Winter 2019'";



// Get a response from the database by sending the connection
// and the query

$response = @mysqli_query($dcc, $spring);
$response2 = @mysqli_query($dcc, $summer);
$response3 = @mysqli_query($dcc, $fall);
$response4 = @mysqli_query($dcc, $winter);

// If the query executed properly proceed

if($response){

echo'<h4 style="color: cadetblue;padding-left:15px; font-size:200%;  font-family: Times New Roman;">&nbsp;&nbsp;<center>Spring 2019</center></h4><div style="color: gray;">Student ID: '.$student_id.'</div><br>';
echo '<table style="width: 100%;" align="left" cellspacing="5" cellpadding="8">
<tr><tr style="color:black;">
<td align="left"><b>Course ID&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Course Name&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Grade&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Semester&emsp;&emsp;&emsp;&emsp;</b></td></tr>';
 
// mysqli_fetch_array will return a row of data from the query
// until no further data is available

$count=0;
while($row = mysqli_fetch_array($response)){

      $course_ID2 =  $row['Course_ID'];
 
echo '<tr><td align="left" style="padding-left: 30px; line-height: 30px;">' . $row['Course_ID'] . '</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['Grades'] . '</td><td align="left">'. $row['Semester'] .'</td>';


echo '</tr>';
}
 
echo '</table>';


} 
echo'<hr>';
if($response2){

echo'<h4 style="color: cadetblue;padding-left:15px; font-size:200%; font-family: Times New Roman;">&nbsp;&nbsp;<center>Summer 2019</center> </h4><div style="color: gray;">Student ID: '.$student_id.'</div><br>';
echo '<table style="width: 100%;" align="left" cellspacing="5" cellpadding="8">
<tr><tr style="color:black;">
<td align="left"><b>Course ID&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Course Name&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Grade&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Semester&emsp;&emsp;&emsp;&emsp;</b></td></tr>';
 
// mysqli_fetch_array will return a row of data from the query
// until no further data is available

$count=0;
while($row = mysqli_fetch_array($response2)){

      $course_ID2 =  $row['Course_ID'];
 
echo '<tr><td align="left" style="padding-left: 30px; line-height: 30px;">' . $row['Course_ID'] . '</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['Grades'] . '</td><td align="left">'. $row['Semester'] .'</td>';


echo '</tr>';
}
 
echo '</table>';


} 
echo'<hr>';


}





else{
    //if they just typed out the address without the form//
    header("Location:studentsearch.php");
    exit();    
}

 
// Close connection to the database
mysqli_close($dcc);
 
?>
</div>

<div>
</div>
<?php

    ?>
    

 

</body>
</html>