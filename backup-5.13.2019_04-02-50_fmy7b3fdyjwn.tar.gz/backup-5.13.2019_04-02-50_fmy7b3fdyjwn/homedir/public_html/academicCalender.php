<!DOCTYPE html>
<!-- html by Juvon Hyatt -->
<?php
session_start();
?>
<html>

<head>
    <meta charset="utf-8">
    <title>Group 6 University</title>
</head>
<link rel="stylesheet" type="text/css" href="style.css">
<style>
        .slider-frame{
    overflow:hidden;
    height: 500px;
    width: 100%;
    margin-top: 20px;  
    padding-bottom: 50px;
}

@-webkit-keyframes slide_animation{
    0%{left: 0%;}
    10%{left: 0%;}
    20%{left: 101%;}
    30%{left:101%;}
    40%{left: 150%;}
    50%{left: 150%x;}
    60%{left: 101%;}
    70%{left: 101%;}
    80%{left: 50%;}
    90%{left: 0%;}
    100%{left: 0px;}
}

.slide-images{
    width: 3600px;
    height: 800px;
    margin: 0 0 0 -2400px;
    position: relative;
    -webkit-animation-name: slide_animation;
    -webkit-animation-duration: 33s;
    -webkit-animation-iteration-count: infinite;
    -webkit-animation-direction: alternate;
    -webkit-animation-play-state: running;
    
    -moz-animation-name: slide_animation;
    -moz-animation-duration: 33s;
    -moz-animation-iteration-count: infinite;
    -moz-animation-direction: alternate;
    -moz-animation-play-state: running;
 
}

.img-container{
     
    height: 500px;
    width: 33%;
    position: relative;
    float: left;
}

.info-box-1{
    height: 300px;
    float: left;
    width: 60%;
    background-image: linear-gradient(cadetblue, lightblue);
    margin-top: 50px;
    margin-left: 30px;
    border-radius: 5px;
    font-family: Arial;
    font-size: 250%;
    font-weight: bold;
    padding-left: 50px;
    
    
}

.info-box-2{
    height: 300px;
    float: left;
    width: 30%;
    background-image: linear-gradient(cadetblue, lightblue);
    margin-top: 50px;
    margin-left: 60px;
    border-radius: 5px;
    
}

li { transition: all .2s ease-in-out; }
li:hover { transform: scale(1.1); }
    
    </style>
<body>
<header>
     <div class ="main-wrapper">
          <div class="box1" style="background-color:lightblue; width: 100%;">
        <h1 style="text-align: center;">Group 6 University</h1>
         </div>
                 <?php
                 session_start();

                 $student_id = $_SESSION['student_id'];
                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $firstname = $_SESSION['firstname'];
                 $lastname = $_SESSION['lastname'];
                 $major = $_SESSION['major'];
                
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');

// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());

                    if(isset($_SESSION['username'])){
                        
                        //extra admin privlages
                        $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 1";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                        if($resultCheck>0){
                            $_SESSION['level'] = 1;
                           $level = $_SESSION['level'];
                        //if you are an admin
           
                        
                            echo '<nav>
                       
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                 
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="studentsearch.php">Search student</a></li>
                        <li><a href="accounts.php">Manage Accounts</a></li>
                        <li><a href="courseManager.php">Course Manager</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
         
                        //** add more admin abilities above **/    
                       
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form><div></nav>';
                            
                        }else{
                            
                         $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 0";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                           $_SESSION['level'] = 0;
                           $level = $_SESSION['level'];
                         //if you are an student user
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="StudentMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="degreeAudit.php">Degree Audit</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                               $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 2";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
              
                                //if you are an faculty

                                $_SESSION['level'] = 2;
                                $level =  $_SESSION['level'];
                           
                                
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="facultyMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="studentManager.php">Student Manager</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                            
                                 $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 3";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                                //you are a researcher
                            
                             $_SESSION['student_id'] = 0;
                                $_SESSION['level'] = 3;
                                $level =  $_SESSION['level'];
                     
                                
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="research.php">Research</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                         <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                            
                           }
                       }
                        
                     }
                  }
                }else{
                                echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                  
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
                         echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                   <button type="submit" name="submit">Login</button>
                    </form>
                    <!--<a href="signup.php">sign up</a></div></nav>-->';
                    }
                ?>
                  
                </div>

    </header>
    <center>
    
 <h2><strong> Acedemic Calender - Spring 2019</strong></h2> 

<table border ="1">
  <thead>
<tr> <th>Date</th> <th>Acedemic Event</th>  </tr><tr> <td>Jan 17 2019 (All Day)</td> <td>Advising for all students 10A.M. - 7P.M</td> </tr> <tr> <td>Jan 18 2019 (All Day) </td> <td>Advising for all students 10A.M. - 4P.M.</td> </tr></tr> <tr> <td>Jan 21 2019 - 10:00am to 4:00pm</td> <td>Residence Halls open; Martin Luther King, Jr. Birthday observed. No classes; offices closed</td> </tr> <tr></tr> <tr> <td>Jan 22 2019 (All Day)</td> <td>Spring 2019 Classes begin</td> </tr> <tr></tr> <tr> <td>Jan 22 2019 (All Day) to Jan 28 2019 (All day)</td> <td>Add/Drop (no fee)/Late Registration  ($50 fee) on the Web(g6university.com)</td> </tr> <tr></tr> <tr> <td>Feb 18 2019 (All Day)</td> <td>President's Day </td> </tr> <tr></tr> <tr> <td>Mar 4 2019 (All Day)</td> <td>Advising begins in department offices for Fall 2019 registration (By Appointment)</td> </tr> <tr></tr> <tr> <td>Mar 11 2019 (All Day) to Mar 16 2019 (All Day) </td> <td>Midterm Week</td> </tr> <tr> </tr> <tr> <td>Mar 16 2019 (All Day)</td> <td>Dinning Hall closes after breakfast</td> </tr> <tr></tr> <tr> <td>Mar 18 2019 (All Day) to Mar 24 2019 (All Day)</td> <td>Spring Recess</td> </tr> <tr></tr> <tr> <td>Mar 24  2019 (All Day)</td> <td>Dinning Hall reopens for dinner</td> </tr> <tr></tr> <tr> <td>Mar 25  2019 (All Day)</td> <td>Classes Resume</td> </tr> <tr> </tr> <tr> <td>Mar 27 2019 (All Day)</td> <td>Mid-term grades due</td> </tr> <tr></tr> <tr> <td>Apr 1 2019 (All Day)</td> <td>Fall registration for Seniors on the Web (g6university.com)</td> </tr> <tr> </tr> <tr> <td>Apr 4 2019 (All Day)</td> <td>Fall 2019 registration for junios on the Web (g6university.com)</td> </tr> <tr></tr> <tr> <td>Apr 8 2019 (All Day)</td> <td>Fall 2019 registration for sophomores on the Web (g6university.com)</td> </tr> <tr> </tr> <tr> <td>Apr 11 2019 (All Day)</td> <td>Fall 2019 registration for freshmen on the Web (g6university.com)</td> </tr> <tr></tr> <tr> <td>Apr 12 2019 (All Day) to Aug 23 2019 (All Day)</td> <td>Continual registration for Fall 2019 for all students on the Web (g6university.com)</td> </tr> <tr> </tr> <tr> <td>Apr 25 2019 (All Day)</td> <td>Honors Convocation - Classes cancelled from 2P.M. - 6P.M.</td> </tr> <tr></tr> <tr> <td>May 8 2019 (All Day)</td> <td>Make-up/Study Day* for Monday/Wednesday classes</td> </tr> <tr> </tr> <tr> <td>May 9  2019 (All Day)</td> <td>Make-up/Study Day* for Tuesday/Thursday classes</td> </tr> <tr></tr> <tr> <td>Mar 10 2019 (All Day) to May 16 2019 (All Day)</td> <td>Examinations week Grades due 48 hours after final examination)</td> </tr> <tr> </tr><tr> <td>May 16 2019 (All Day)</td> <td>Spring semester ends after last examination</td> </tr> <tr> <td>May 16 2019 (All Day) </td> <td>Residence halls close at 10P.M. for undergraduates</td> </tr></tr> <tr> <td>May 18 2019 (All Day)</td> <td>Graduating students check out of Residence Halls at 3P.M.</td> </tr></tr></tr> <tr> <td>May 18 2019 (All Day)</td> <td>Commencement</td> </tr> </table>
 <br><br>
 
 <h2><strong> Acedemic Calender - Summer 2019</strong></h2> 

<table border ="1">
  <thead>
<tr> <th>Date</th> <th>Acedemic Event</th>  </tr><tr> <td>May 20 2019 (All Day)</td> <td>Summer Session IV begins (5days/week)</td> </tr> <tr> <td>May 27 2019 (All Day) </td> <td>Memorial Day observed - no classes: offices closed</td> </tr></tr> <tr> <td>Jun 7 2019 (All Day)</td> <td>Summer IV ends</td> </tr> <tr></tr> <tr> <td>Jun 10 2019 (All Day)</td> <td>Summer Session I begins (2 days/week)</td> </tr> <tr></tr> <tr> <td>Jun 10 2019 (All Day)</td> <td>Summer Session II begins (4 days/week)</td> </tr> <tr></tr> <tr> <td>Jul 4 2019 (All Day)</td> <td>Independence Day; no classes; offices closed</td> </tr> <tr></tr> <tr> <td>Jul 11 2019 (All Day)</td> <td>Summer Session II ends</td> </tr> <tr></tr> <tr> <td>Jul 11 2019 (All Day)</td> <td>Final grades due for Summer Session II 48 hours after final examination</td> </tr> <tr> </tr> <tr> <td>Jul 15 2019 (All Day)</td> <td>Summer Session III begins (4 days/week, M-Th)</td> </tr> <tr> <td>Aug 15 2019 (All Day) </td> <td>Final grades due for Summer Sessions I and III 48 hours after final examination</td>  <tr></tr> <tr> <td>Aug 15 2019 (All Day) </td> <td>Summer Sessions I and III end</td> </table>
<br><br>
   
    <h2><strong> Acedemic Calender - Fall 2019</strong></h2> 

<table border ="1">
  <thead>
<tr> <th>Date</th> <th>Acedemic Event</th>  </tr><tr> <td>Aug 24 2019 (All Day)</td> <td>Residence halls open for all new students (Freshman and Transfer</td> </tr> <tr> <td>Aug 25 2019 - 10:00am to 4:00pm </td> <td>Residence halls open for all returning students</td> </tr></tr> <tr> <td>Aug 26 2019 </td> <td>Classes begin</td> </tr> <tr></tr> <tr> <td>Aug 26 2019 (All Day) to Sep 1 2019 (All Day)</td> <td>Add/Drop(nofee)/Late Registration ($50 fee) on the Web (g6university.com)</td> </tr> <tr></tr> <tr> <td>Sep 2 2019 (All Day)</td> <td>Labor Day Observed-no classes offices closed</td> </tr> <tr></tr> <tr> <td>Oct 1 2019 (All Day)</td> <td>Applications for graduation (Registrar's Office) due from candidates expecting to complete requirements by December 2019 </td> </tr> <tr></tr> <tr> <td>Oct 1 2019 (All Day)</td> <td>Advising begins in department offices for Spring 2020 registration (By appointment)</td> </tr> <tr></tr> <tr> <td>Oct 14 2019 (All Day) </td> <td>Columbus Day observed - non classes; offices closed</td> </tr> <tr> </tr> <tr> <td>Oct 21 2019 (All Day) to Oct 26 2019 (All Day)</td> <td>Midterm Week</td> </tr> <tr></tr> <tr> <td>Oct 21, 2019 (All Day) to Oct 26 2019 (All Day)</td> <td>Mid-term grades due</td> </tr> <tr></tr> <tr> <td>Nov 4  2019 (All Day)</td> <td>Spring 2020 registration for seniors on the Web (g6university.com)</td> </tr> <tr></tr> <tr> <td>Nov 5 2019 (All Day)</td> <td>Election Day - Classes in sessionn; offices minimally staffed</td> </tr> <tr> </tr> <tr> <td>Nov 7 2019 (All Day)</td> <td>Spring 2020 registration for juniors on the Web (g6university.com)</td> </tr> <tr></tr> <tr> <td>Nov 11 2019 (All Day)</td> <td>Fall registration for sophomores on the Web (g6university.com)</td> </tr> <tr> </tr> <tr> <td>Nov 14 2019 (All Day)</td> <td>Spring 2019 registration for freshmen on the Web (g6university.com)</td> </tr> <tr></tr> <tr> <td>Nov 15 2019 (All Day)</td> <td>Continual registration for Spring 2020 for all students on the Web (g6university.com)</td> </tr> <tr> </tr> <tr> <td>Nov 27 2019 (All Day)</td> <td>Dining Hall closes after dinner</td> </tr> <tr></tr> <tr> <td>Nov 28 2019 (All Day) to Dec 1 2019 (All Day)</td> <td>Thanksgiving Recess (begins after last class Wednesday)</td> </tr> <tr> </tr> <tr> <td>Dec 1 2019 (All Day)</td> <td>Dining Hall reopens for dinner</td> </tr> <tr></tr> <tr> <td>Dec 2 2019 (All Day)</td> <td>Classes resume</td> </tr> <tr> </tr> <tr> <td>Dec 11 2019 (All Day)</td> <td>Make-up/Study Day* for Monday/Wednesday classes</td> </tr> <tr></tr> <tr> <td>Dec 12 2019 (All Day)</td> <td>Make-up/Study Days for Tuesday/Thursday</td> </tr> <tr> </tr><tr> <td>Dec 14 2019 (All Day) to Dec 20 2019</td> <td>Examination week (Grades due 48 hours after final exams)</td> </tr> <tr> <td>Dec 20 2019 (All Day) </td> <td>Fall Semester ends after last examination</td> </tr></tr> <tr> <td>Dec 20 2019 (All Day)</td> <td>Residence Halls close at 10 P.M.</td> </tr></tr></tr> <tr> <td>Dec 25 2019 (All Day)</td> <td>Christmas - no classes; offices closed</td> </tr>
</table>
<br><br>

<h2><strong> Acedemic Calender - Winter 2020</strong></h2> 

<table border ="1">
  <thead>
<tr> <th>Date</th> <th>Acedemic Event</th>  </tr><tr> <td>Jan 2 2020 (All Day)</td> <td>Summer Session IV begins</td></tr> 
<tr><td>Jan 2 2020 (All Day) to Jan 3 2020 (All Day) </td> 
 <td> Add/Drop and late registration; $50 late registration fee applies</td> </tr></tr><tr> <td>Jan 4 2020 (All Day) to Jan 8 2020 (All Day)</td> <td>Withdrawal with 35% refund; No refunds after Jan 8</td> </tr> <tr></tr> <tr> <td>Jan 9 2020(All Day)</td> <td>Credit/No Credit grade option deadline</td> </tr> <tr></tr> <tr> <td>Jan 11 2020 (All Day)</td> <td>Last day to widthdraw from courses</td> </tr> <tr></tr> <tr> <td>Jan 18 2020 (All Day)</td> <td>Winter session ends</td> </tr> <tr></tr> 
</table>
<br><br>

</center>

</body>
</html>

 