<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="style.css">
  <title>G6 University Research Statistics</title>
</head>
<body>
    <header>
     <div class ="main-wrapper">
          <div class="box1" style="background-color:lightblue; width: 100%;">
        <h1 style="text-align: center;">Group 6 University</h1>
         </div>
                 <?php
                 session_start();

                 $student_id = $_SESSION['student_id'];
                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $firstname = $_SESSION['firstname'];
                 $lastname = $_SESSION['lastname'];
                 $major = $_SESSION['major'];
                
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');

// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());

                    if(isset($_SESSION['username'])){
                        
                        //extra admin privlages
                        $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 1";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                        if($resultCheck>0){
                            $_SESSION['level'] = 1;
                           $level = $_SESSION['level'];
                        //if you are an admin
           
                        
                            echo '<nav>
                       
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                 
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="studentsearch.php">Search student</a></li>
                        <li><a href="accounts.php">Manage Accounts</a></li>
                        <li><a href="courseManager.php">Course Manager</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
         
                        //** add more admin abilities above **/    
                       
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form><div></nav>';
                            
                        }else{
                            
                         $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 0";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                           $_SESSION['level'] = 0;
                           $level = $_SESSION['level'];
                         //if you are an student user
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="StudentMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="degreeAudit.php">Degree Audit</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                               $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 2";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
              
                                //if you are an faculty

                                $_SESSION['level'] = 2;
                                $level =  $_SESSION['level'];
                           
                                
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="facultyMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="studentManager.php">Student Manager</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                            
                                 $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 3";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                                //you are a researcher
                            
                             $_SESSION['student_id'] = 0;
                                $_SESSION['level'] = 3;
                                $level =  $_SESSION['level'];
                     
                                
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="research.php">Research</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                         <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                            
                           }
                       }
                        
                     }
                  }
                }else{
                                echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                  
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
                         echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                   <button type="submit" name="submit">Login</button>
                    </form>
                    <!--<a href="signup.php">sign up</a></div></nav>-->';
                    }
                ?>
                  
                </div>

    </header>
  <div class="container">
    <canvas id="myChart"></canvas>
    <br><br><br>
    <canvas id="line-chart" width="800" height="450"></canvas>
    <br><br><br>
    <canvas id="pie-chart" width="800" height="450"></canvas>
    <br><br><br>
  </div>

  <script>
    let myChart = document.getElementById('myChart').getContext('2d');

    // Global Options
    Chart.defaults.global.defaultFontFamily = 'Lato';
    Chart.defaults.global.defaultFontSize = 18;
    Chart.defaults.global.defaultFontColor = '#777';

    let massPopChart = new Chart(myChart, {
      type:'bar', // bar, horizontalBar, pie, line, doughnut, radar, polarArea
      data:{
        labels:['Women', 'Men', 'White Walkers', 'Targarians', 'Wights', 'Meeseeks'],
        datasets:[{
          label: 'population',
          data:[
            617594,
            181045,
            153060,
            106519,
            105162,
            95072
          ],
          //backgroundColor:'green',
          backgroundColor:[
            'rgba(255, 99, 132, 0.6)',
            'rgba(54, 162, 235, 0.6)',
            'rgba(255, 206, 86, 0.6)',
            'rgba(75, 192, 192, 0.6)',
            'rgba(153, 102, 255, 0.6)',
            'rgba(255, 159, 64, 0.6)',
            'rgba(255, 99, 132, 0.6)'
          ],
          borderWidth:1,
          borderColor:'#777',
          hoverBorderWidth:3,
          hoverBorderColor:'#000'
        }]
      },
      options:{
        title:{
          display:true,
          text:'G6 University Gender Statistics',
          fontSize:25
        },
        legend:{
          display:true,
          position:'right',
          labels:{
            fontColor:'#000'
          }
        },
        layout:{
          padding:{
            left:50,
            right:0,
            bottom:0,
            top:0
          }
        },
        tooltips:{
          enabled:true
        }
      }
    });
  </script>
  <script>
      new Chart(document.getElementById("line-chart"), {
  type: 'line',
  data: {
    labels: [2000,2003,2005,2007,2009,2011,2013,2015,2017,2019],
    datasets: [{ 
        data: [86,114,106,106,107,111,133,221,783,2478],
        label: "Spansh",
        borderColor: "#3e95cd",
        fill: false
      }, { 
        data: [282,350,411,502,635,809,947,1402,3700,5267],
        label: "Black",
        borderColor: "#8e5ea2",
        fill: false
      }, { 
        data: [168,170,178,190,203,276,408,547,675,734],
        label: "other",
        borderColor: "#3cba9f",
        fill: false
      }, { 
        data: [40,20,10,16,24,38,74,167,508,784],
        label: "indian",
        borderColor: "#e8c3b9",
        fill: false
      }, { 
        data: [6,3,2,2,7,26,82,172,312,433],
        label: "white",
        borderColor: "#c45850",
        fill: false
      }
    ]
  },
  options: {
    title: {
      display: true,
      text: 'G6 university diversity statistics 2000-2019'
    }
  }
});
  </script>
  <script>
      new Chart(document.getElementById("pie-chart"), {
    type: 'pie',
    data: {
      labels: ["Grad", "Undergrad", "Freshman", "Sophemore", "Junior","Senior"],
      datasets: [{
        label: "Progress (millions)",
        backgroundColor: ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850"],
        data: [2478,3567,2475,734,784,433]
      }]
    },
    options: {
      title: {
        display: true,
        text: 'G6 university population stats in 2019'
      }
    }
});
  </script>
</body>
</html>
