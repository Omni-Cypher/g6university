<?php
session_start();
?>
<html>
<head>
    <Title></Title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        .student-links{
            float: left;
            height: 410px;
            width: 800px;
            background-color: white;
            position: relative;
            bottom: 430px;
            left: 500px;
            padding-left: 30px;
            border-style: solid; border-color: black; border-width: 2px; font-size: 30px; font-color: black; border-radius: 10px;
        }
      
        
        th{
            color: darkblue;
            padding-right: 40px;
            background-color: lightblue;
            width: 80%;
            padding-left: 100px;
        }
        
        tr:nth-child(even){
            background-color: #e8f2f2;
            
        }
    </style>
</head>
<body>
    <header>
     <div class ="main-wrapper">
          <div class="box1" style="background-color:lightblue; width: 100%;">
        <h1 style="text-align: center;">Group 6 University</h1>
         </div>
                 <?php
                 session_start();

                 $student_id = $_SESSION['student_id'];
                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $firstname = $_SESSION['firstname'];
                 $lastname = $_SESSION['lastname'];
                 $major = $_SESSION['major'];
                
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');

// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());

                    if(isset($_SESSION['username'])){
                        
                        //extra admin privlages
                        $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 1";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                        if($resultCheck>0){
                            $_SESSION['level'] = 1;
                           $level = $_SESSION['level'];
                        //if you are an admin
           
                        
                            echo '<nav>
                       
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                 
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="studentsearch.php">Search student</a></li>
                        <li><a href="accounts.php">Manage Accounts</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
         
                        //** add more admin abilities above **/    
                       
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form><div></nav>';
                            
                        }else{
                            
                         $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 0";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                           $_SESSION['level'] = 0;
                           $level = $_SESSION['level'];
                         //if you are an student user
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="StudentMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="degreeAudit.php">Degree Audit</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                                //if you are an faculty
                                $_SESSION['student_id'] = 0;
                                $_SESSION['level'] = 2;
                                $level =  $_SESSION['level'];
                                $student_id = $_SESSION['student_id'];
                                
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="facultyMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="studentManager.php">Student Manager</a></li>
                         <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }
                        }
                }else{
                                echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                  
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
                         echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                    <button type="submit" name="submit">Login</button>
                    </form>
                    <a href="signup.php">sign up</a></div></nav>';
                    }
                ?>
                  
                </div>

    </header>
    <section class="main-container">
        <div class="main-wrapper"></div>
        <h2 style="color: white">Degree Audit</h2>
  
    </section>
    
       <?php
       session_start();

    $student_id = $_SESSION['student_id'];
                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $firstname = $_SESSION['firstname'];
                 $lastname = $_SESSION['lastname'];
                 $major = $_SESSION['major'];
    DEFINE ('DB_USER', 'omnicypher');
    
    DEFINE ('DB_PASSWORD', 'S3RV3R!!');
    DEFINE ('DB_HOST', 'localhost');
    DEFINE ('DB_NAME', 'g6');

 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser

 
$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
    $query = 'SELECT  *
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
INNER JOIN schedulee
ON course.Course_ID = schedulee.Course_ID
WHERE Student_ID = '.$student_id;

// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);
      session_start();
      
      $accProg ="SELECT * FROM transcript WHERE Student_ID ='$student_id' and Grades != 'N/A'";
       $accStat = mysqli_query($dbc,$accProg); 
       $cYear = 0;
      while($row = mysqli_fetch_array($accStat)){
          $cYear = $cYear +1;
      }
      if($cYear <= 8){$stat = "Freshman";}//4
      if($cYear > 8 && $cYear >=12 ){$stat = "Softmore";}//8
      if($cYear > 12 && $cYear >=16 ){$stat = "sophomore";}//8
      if($cYear > 16 && $cYear >=24 ){$stat = "Junior";}//8
      if($cYear > 24 && $cYear >=32 ){$stat = "Senior";}//8
      
      echo '<div style="padding-left: 20px;">Major: '.$major.' | Name: '.$firstname.' '.$lastname.'  | Student Status: '.$stat.'</div>';
      


      
  $geClass = "SELECT * FROM `general_education`
   INNER JOIN
   course
   on
   course.Course_ID =  general_education.Course_ID 
   INNER JOIN
   transcript
   on general_education.Course_ID = transcript.Course_ID
   WHERE
   Student_ID = '$student_id';
   ";
     $result2 = mysqli_query($dbc,$geClass); 
     
     if($result2){
    $i = 0;
    #echo'result 2: ';
    while($row = mysqli_fetch_array($result2)){
    $ge[$i] = $row['CRN'];
    #echo ',GE: '.$ge[$i];
    $i++;
  
} 

}

         echo'</table class="auditTable">';
         
      /*if($major == 'American Studies'){  //------------------------------------------------------------HISTORY AUDIT------------------------------------------------------------------
          
          $Major = 'SELECT * FROM History_Major INNER JOIN course on course.Course_ID = History_Major.Course_ID;';
           $Core = mysqli_query($dbc,$Major);
          
           $GEclasses = 'SELECT * FROM general_education INNER JOIN course on course.Course_ID = general_education.Course_ID;';
           $getGE =  mysqli_query($dbc,$GEclasses); //to print
           
           $transcript = 'SELECT * FROM transcript  LEFT JOIN course on transcript.Course_ID = course.Course_ID WHERE Student_ID = '.$student_id;
            $result3 = mysqli_query($dbc, $transcript); 
    
      
            if($result3){
    $i = 0;
    #echo'result 2: ';
    while($row = mysqli_fetch_array($result3)){
    $tClasses[$i] = $row['Course_ID'];
    #echo '--tClasses: '.$tClasses[$i];
    $i++;
  
} 

}
   $result2 = mysqli_query($dbc, $GEclasses); 
    
     if($result2){
    $i = 0;
    #echo'result 2: ';
    while($row = mysqli_fetch_array($result2)){
    $ge[$i] = $row['Course_ID'];
    #echo ',GE: '.$ge[$i];
    $i++;
  
} 

}
   
   echo '<table style="width: 100%;" align="left" cellspacing="5" cellpadding="8">
    <tr><tr style="color:black;">
    <td align="left"><b>Status&emsp;&emsp;&emsp;&emsp;</b></td>
    <td align="left"><b> Required Courses &emsp;&emsp;&emsp;&emsp;</b></td>
    <td align="left"><b>CRN&emsp;&emsp;&emsp;&emsp;</b></td>
    <td align="left"><b>Semester&emsp;&emsp;&emsp;&emsp;</b></td>
    <td align="left"><b>Grade&emsp;&emsp;&emsp;&emsp;</b></td>
    </tr>';

  

      while($row = mysqli_fetch_array($Core)){
          $cid = $row['Course_ID'];
           $grade =" ";
           $name = $row['Course_Name'];
           $crn = $row['CRN'];
           $sem = $row['Semester_ID'];
           $status="Not Yet Attempted";
            #print out grades
           
                         
                         
          for($i=0;$i<count($tClasses); $i++){
                        
                        if($tClasses[$i] == $row['Course_ID']){
                    
                            $find = 'SELECT * FROM transcript WHERE Course_ID = '.$row['Course_ID'].' and Student_ID = '.$student_id;
                              $gGrade = mysqli_query($dbc, $find); 
                             while($row = mysqli_fetch_array($gGrade)){
                        
                            $status ="<div style='color: green'>Completed</div>";
                            $grade = $row['Grades'];
                            #echo 'grade: '.$row['Grades'];
                        
                             $grade = $row['Grades'];
                           
                            if($row['Grades'] == "N/A"){
                                   $grade = "N/A";
                                   $status ="Not Yet Attempted";
                           }
                           if($row['Grades'] == "N/A" && $row["Semester"]=='Summer 2019'){
                                   $grade = "N/A";
                                   $status ="<div style='color: blue'>In Progress</div>";
                           }
                           
                           else if($grade == "A" ){
                               $status ="<div style='color: green'>Completed</div>";
                               $GPA += 4.00;
                                $classes++;
                           }
                           
                           else if($grade == "B" ){
                               $status ="<div style='color: green'>Completed</div>";
                               $GPA += 3.00;
                                $classes++;
                           }
                           
                           else if($grade == "C" ){
                               $status ="<div style='color: green'>Completed</div>";
                               $GPA += 2.00;
                                $classes++;
                           }
                           else if($grade == "D" ){
                               $status ="<div style='color: red'>Failed</div>";
                                $GPA += 1.00;
                                $classes++;
                           }
                           
                           else if($grade == "F" ){
                               $status ="<div style='color: red'>Failed</div>";
                                $GPA += 0.00;
                                $classes++;
                           }
                           
                          }
                        }else{
                            
                        }
                       
                        
                     }
                     
                    
                
           $row['Grades'] = $grade;
           $row['CRN'] = $crn;
           $row['Semester_ID'] = $sem;
           $row['Course_Name'] = $name;
                         
                       echo '<tr><td>'.$status.'</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['CRN'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Grades'] .'</td>';
   
                      

}
    echo'</table>';
    
  
//print the general ed classes 
$gec ="SELECT * FROM `general_education`
   INNER JOIN
   course
   on
   course.Course_ID =  general_education.Course_ID ";
   
   $resultGec = mysqli_query($dbc,$gec);
  
   if($resultGec){
       
     echo'<br><br><hr>';
echo '<table style="margin-top: 50px; width: 100%;" align="left" cellspacing="5" cellpadding="8">
<tr><tr style="color:black;">
<td align="left"><b>Status&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>General Education Course Name  (14 needed)&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>CRN&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Semester&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Grade&emsp;&emsp;&emsp;&emsp;</b></td>
</tr>';
       
       while($row = mysqli_fetch_array($resultGec)){
           $nonGeClasses = 0;
    $cid =0;
$taken = 0;
#echo 'course id: '.$row['Course_ID'].'<br>';
$fail = 0;
$cid = $row['Course_ID'];
$grade=" ";

            $grade ="";
            $status ="Not Yet Attempted";
                      $name = $row['Course_Name'];
                    $crn = $row['CRN'];
                    $sem = $row['Semester_ID'];

                     for($i=0;$i<count($tClasses); $i++){
                        
                        if($tClasses[$i] == $row['Course_ID']){
                          
                            $find = 'SELECT * FROM transcript WHERE Course_ID = '.$row['Course_ID'].' and Student_ID = '.$student_id;
                              $gGrade = mysqli_query($dbc, $find); 
                             while($row = mysqli_fetch_array($gGrade)){
                               
                            $status ="<div style='color: green'>Completed</div>";
                            $grade = $row['Grades'];
                            #echo 'grade: '.$row['Grades'];
                        
                             $grade = $row['Grades'];
                             
                           if($row['Grades'] == "N/A"){
                                   $grade = "N/A";
                                   $status ="Not Yet Attempted";
                           }
                           if($row['Grades'] == "N/A" && $row["Semester"]=='Summer 2019'){
                                   $grade = "N/A";
                                   $status ="<div style='color: blue'>In Progress</div>";
                           }
                           
                           else if($grade == "A" ){
                               $status ="<div style='color: green'>Completed</div>";
                               $GPA += 4.00;
                                $classes++;
                           }
                           
                           else if($grade == "B" ){
                               $status ="<div style='color: green'>Completed</div>";
                               $GPA += 3.00;
                                $classes++;
                           }
                           
                           else if($grade == "C" ){
                               $status ="<div style='color: green'>Completed</div>";
                               $GPA += 2.00;
                                $classes++;
                           }
                           else if($grade == "D" ){
                               $status ="<div style='color: red'>Failed</div>";
                                $GPA += 1.00;
                                $classes++;
                           }
                           
                           else if($grade == "F" ){
                               $status ="<div style='color: red'>Failed</div>";
                                $GPA += 0.00;
                                $classes++;
                           }
                           
                           
                          }     
                          
                                        
                        }else{
                            
                        }
                        
                     }
                     
          
             
            
                         #print out grades
                           $row['Grades'] = $grade;
                           $row['Course_Name'] = $name;
                            $row['CRN'] = $crn;
                         $row['Semester_ID'] = $sem;
                         
                       echo '<tr><td>'.$status.'</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['CRN'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Grades'] .'</td>';
 
        
}
       
   }

echo '</table>';
 
     $completion = $classes/32*100;
     #echo $nums;
     #echo $classTotal;

    echo'<br><div style="height: 300px; width:100%; padding-left: 20px; color:grey;">
    <p> Completion: '.$completion.'% <progress value="'.$completion.'" max="100"></progress></p>  
    </div>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspGPA: '.$GPA/$classes;
    

 
      
         
      }//end of history major*/
      if(!$major == NULL){  //------------------------------------------------------------Degree AUDIT------------------------------------------------------------------
          if($major == 'Computer Science' ){
              $Major = 'SELECT * FROM CS_Major INNER JOIN course on course.Course_ID = CS_Major.Course_ID;'; 
          }
           if($major == 'American Studies' ){
               $Major = 'SELECT * FROM History_Major INNER JOIN course on course.Course_ID = History_Major.Course_ID;';
          }
          
           $Core = mysqli_query($dbc,$Major);
          
           $GEclasses = 'SELECT * FROM general_education INNER JOIN course on course.Course_ID = general_education.Course_ID;';
           $getGE =  mysqli_query($dbc,$GEclasses); //to print
           
           $transcript = 'SELECT * FROM transcript  LEFT JOIN course on transcript.Course_ID = course.Course_ID WHERE Student_ID = '.$student_id;
            $result3 = mysqli_query($dbc, $transcript); 
    
      
            if($result3){
    $i = 0;
  
    while($row = mysqli_fetch_array($result3)){
    $tClasses[$i] = $row['CRN'];
     #echo'CRN: '. $row['CRN'];
    #echo '--tClasses: '.$tClasses[$i];
    $i++;
  
} 

}
   $result2 = mysqli_query($dbc, $GEclasses); 
    
     if($result2){
    $i = 0;
    #echo'result 2: ';
    while($row = mysqli_fetch_array($result2)){
    $ge[$i] = $row['CRN'];
    #echo ',GE: '.$ge[$i];
    $i++;
  
} 

}
   
   echo '<table style="width: 100%;" align="left" cellspacing="5" cellpadding="8">
    <tr><tr style="color:black;">
    <td align="left" style="background-color:cadetblue"><b>Status&emsp;&emsp;&emsp;&emsp;</b></td>
    <td align="left" style="background-color:cadetblue"><b> Required Courses &emsp;&emsp;&emsp;&emsp;</b></td>
    <td align="left" style="background-color:cadetblue"><b>CRN&emsp;&emsp;&emsp;&emsp;</b></td>
    <td align="left" style="background-color:cadetblue"><b>Semester&emsp;&emsp;&emsp;&emsp;</b></td>
    <td align="left" style="background-color:cadetblue"><b>Grade&emsp;&emsp;&emsp;&emsp;</b></td>
    </tr>';

  

      while($row = mysqli_fetch_array($Core)){
          $cid = $row['Course_ID'];
           $grade =" ";
           $name = $row['Course_Name'];
           $crn = $row['CRN'];
           $sem = $row['Semester_ID'];
           $status="Not Yet Attempted";
            #print out grades
           
                         
                         
          for($i=0;$i<count($tClasses); $i++){
                        
                        if($tClasses[$i] == $row['CRN']){
                            $find = 'SELECT * FROM transcript LEFT JOIN course on transcript.Course_ID = course.Course_ID  WHERE Student_ID = '.$student_id.' and CRN = "'.$row['CRN'].'"';
                            //$find = 'SELECT * FROM transcript WHERE Course_ID = '.$row['Course_ID'].' and Student_ID = '.$student_id;
                              $gGrade = mysqli_query($dbc, $find); 
                             while($row = mysqli_fetch_array($gGrade)){
                        
                            $status ="<div style='color: green'>Completed</div>";
                            $grade = $row['Grades'];
                            #echo 'grade: '.$row['Grades'];
                        
                             $grade = $row['Grades'];
                           
                            if($row['Grades'] == "N/A"){
                                   $grade = "N/A";
                                   $status ="Not Yet Attempted";
                           }
                           if($row['Grades'] == "N/A" && $row["Semester"]=='Summer 2019'){
                                   $grade = "N/A";
                                   $status ="<div style='color: blue'>In Progress</div>";
                           }
                           
                           else if($grade == "A" ){
                               $status ="<div style='color: green'>Completed</div>";
                               $GPA += 4.00;
                                $classes++;
                           }
                           
                           else if($grade == "B" ){
                               $status ="<div style='color: green'>Completed</div>";
                               $GPA += 3.00;
                                $classes++;
                           }
                           
                           else if($grade == "C" ){
                               $status ="<div style='color: green'>Completed</div>";
                               $GPA += 2.00;
                                $classes++;
                           }
                           else if($grade == "D" ){
                               $status ="<div style='color: red'>Failed</div>";
                                $GPA += 1.00;
                                $classes++;
                           }
                           
                           else if($grade == "F" ){
                               $status ="<div style='color: red'>Failed</div>";
                                $GPA += 0.00;
                                $classes++;
                           }
                           
                          }
                        }else{
                            
                        }
                       
                        
                     }
                     
                    
                
           $row['Grades'] = $grade;
           $row['CRN'] = $crn;
           $row['Semester_ID'] = $sem;
           $row['Course_Name'] = $name;
                         
                       echo '<tr><td>'.$status.'</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['CRN'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Grades'] .'</td>';
   
                      

}
    echo'</table>';
    
  
//print the general ed classes 
$gec ="SELECT * FROM `general_education`
   INNER JOIN
   course
   on
   course.Course_ID =  general_education.Course_ID ";
   
   $resultGec = mysqli_query($dbc,$gec);
  
   if($resultGec){
       
     echo'<br><br><hr>';
echo '<table style="margin-top: 50px; width: 100%;" align="left" cellspacing="5" cellpadding="8">
<tr><tr style="color:black;">
<td align="left" style="background-color:cadetblue"><b>Status&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left" style="background-color:cadetblue"><b>General Education Course Name  (14 needed)&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left" style="background-color:cadetblue"><b>CRN&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left" style="background-color:cadetblue"><b>Semester&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left" style="background-color:cadetblue"><b>Grade&emsp;&emsp;&emsp;&emsp;</b></td>
</tr>';
       
       while($row = mysqli_fetch_array($resultGec)){
           $nonGeClasses = 0;
    $cid =0;
$taken = 0;
#echo 'course id: '.$row['Course_ID'].'<br>';
$fail = 0;
$cid = $row['Course_ID'];
$grade=" ";

            $grade ="";
            $status ="Not Yet Attempted";
                      $name = $row['Course_Name'];
                    $crn = $row['CRN'];
                    $sem = $row['Semester_ID'];

                     for($i=0;$i<count($tClasses); $i++){
                        
                        if($tClasses[$i] == $row['CRN']){
                            $find = 'SELECT * FROM transcript LEFT JOIN course on transcript.Course_ID = course.Course_ID  WHERE Student_ID = '.$student_id.' and CRN = "'.$row['CRN'].'"';
                            //$find = 'SELECT * FROM transcript WHERE Course_ID = '.$row['Course_ID'].' and Student_ID = '.$student_id;
                              $gGrade = mysqli_query($dbc, $find); 
                             while($row = mysqli_fetch_array($gGrade)){
                               
                            $status ="<div style='color: green'>Completed</div>";
                            $grade = $row['Grades'];
                            #echo 'grade: '.$row['Grades'];
                        
                             $grade = $row['Grades'];
                             
                           if($row['Grades'] == "N/A"){
                                   $grade = "N/A";
                                   $status ="Not Yet Attempted";
                           }
                           if($row['Grades'] == "N/A" && $row["Semester"]=='Summer 2019'){
                                   $grade = "N/A";
                                   $status ="<div style='color: blue'>In Progress</div>";
                           }
                           
                           else if($grade == "A" ){
                               $status ="<div style='color: green'>Completed</div>";
                               $GPA += 4.00;
                                $classes++;
                           }
                           
                           else if($grade == "B" ){
                               $status ="<div style='color: green'>Completed</div>";
                               $GPA += 3.00;
                                $classes++;
                           }
                           
                           else if($grade == "C" ){
                               $status ="<div style='color: green'>Completed</div>";
                               $GPA += 2.00;
                                $classes++;
                           }
                           else if($grade == "D" ){
                               $status ="<div style='color: red'>Failed</div>";
                                $GPA += 1.00;
                                $classes++;
                           }
                           
                           else if($grade == "F" ){
                               $status ="<div style='color: red'>Failed</div>";
                                $GPA += 0.00;
                                $classes++;
                           }
                           
                           
                          }     
                          
                                        
                        }else{
                            
                        }
                        
                     }
                     
          
             
            
                         #print out grades
                           $row['Grades'] = $grade;
                           $row['Course_Name'] = $name;
                            $row['CRN'] = $crn;
                         $row['Semester_ID'] = $sem;
                         
                       echo '<tr><td>'.$status.'</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['CRN'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Grades'] .'</td>';
 
        
}
       
   }

echo '</table>';
 
     $completion = $classes/32*100;
     #echo $nums;
     #echo $classTotal;

    echo'<br><div style="position:relative; top: 10px; margin-top: 20px; margin-bottom: 100px; height: 100px; width:100%; padding-left: 20px; color:#3f3f3f;">
    Completion: '.$completion.'% <progress value="'.$completion.'" max="100"></progress>
    &nbsp&nbspGPA: '.$GPA/$classes.'</div>';
    

 
      
         
      }
      if($major == 'Not Decided' ||$major == 'None Decided' ){
          echo' You have no specific career path at the momment!';
      }
      
   
      // Close connection to the database
mysqli_close($dbc);

  
    ?>
    
</div>
</body>

    
</html>