<html>
<head>
    <Title></Title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header>
     <div class ="main-wrapper">
          <div class="box1" style="background-color:lightblue; width: 100%;">
        <h1 style="text-align: center;">Group 6 University</h1>
         </div>
                 <?php
                 session_start();

                 $student_id = $_SESSION['student_id'];
                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $firstname = $_SESSION['firstname'];
                 $lastname = $_SESSION['lastname'];
                 $major = $_SESSION['major'];
                
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');

// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());

                    if(isset($_SESSION['username'])){
                        
                        //extra admin privlages
                        $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 1";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                        if($resultCheck>0){
                            $_SESSION['level'] = 1;
                           $level = $_SESSION['level'];
                        //if you are an admin
           
                        
                            echo '<nav>
                       
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                 
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="studentsearch.php">Search student</a></li>
                        <li><a href="accounts.php">Manage Accounts</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
         
                        //** add more admin abilities above **/    
                       
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form><div></nav>';
                            
                        }else{
                            
                         $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 0";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                           $_SESSION['level'] = 0;
                           $level = $_SESSION['level'];
                         //if you are an student user
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="StudentMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="degreeAudit.php">Degree Audit</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                               $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 2";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
              
                                //if you are an faculty
                                $_SESSION['student_id'] = 0;
                                $_SESSION['level'] = 2;
                                $level =  $_SESSION['level'];
                                $student_id = $_SESSION['student_id'];
                                
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="facultyMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="studentManager.php">Student Manager</a></li>
                         <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                            
                                 $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 3";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                                //you are a researcher
                            
                             $_SESSION['student_id'] = 0;
                                $_SESSION['level'] = 3;
                                $level =  $_SESSION['level'];
                     
                                
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="reaserch.php">Research</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                         <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                            
                           }
                       }
                        
                     }
                  }
                }else{
                                echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                  
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
                         echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                    <button type="submit" name="submit">Login</button>
                    </form>
                    <a href="signup.php">sign up</a></div></nav>';
                    }
                ?>
                  
                </div>

    </header>
    
<body class="main" body style="background-color:powderblue;">
<div class="studentinfo">
<?php
// Get a connection for the database

                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $username = $_SESSION['username'];
                 
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');
                
                
 
// $dcc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dcc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
 
// Create a query for the database
if($level == 1 || $level == 2){
$sID;
if(isset($_POST['editHold'])){
   $tHold =  $_POST['hold'];
   $sID =  $_POST['editHold'];
   $set = $sID;
   $query2 = 'UPDATE `student` SET `Hold_ID`= '.$tHold.' WHERE Student_ID = '.$sID;
    mysqli_query($dcc, $query2);
}
$set = $_POST['search'];
if(!is_numeric($set) && !isset($_POST['editHold'])){
    $_SESSION["ERROR"] ='<div style="padding-left: 30px; color:red;">Error: Student ID must be a number!!!</div>';
    header('Location: studentsearch.php');
    exit();
}else{
if(isset($_POST['editHold'])){
$set = $sID;
$studentsID = $sID;
}
$query = "SELECT student_id, student_name, advisor_name, student_number, date_of_enrollment, hold_id FROM student WHERE student_id ='$set'";


// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dcc, $query);
// If the query executed properly proceed
if($response){

echo'<h1 style="color: cadetblue;padding-top: 20px;padding-left:15px; font-size:200%;">&nbsp;&nbsp;STUDENT SEARCH RESULTS</h1><br><br>';
echo '<table align="left" cellspacing="5" cellpadding="8">
<tr><tr style="color:black;"><td align="left"><b>&emsp;&emsp;Student ID&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Student Name&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Advisor Name&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Student Number&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Date Of Enrollment&emsp;&emsp;&emsp;&emsp;</b></td>

<td align="left"><b>Hold ID</b></td></tr>';
 
// mysqli_fetch_array will return a row of data from the query
// until no further data is available

while($row = mysqli_fetch_array($response)){
 
echo '<tr><td align="left" style="padding-left: 30px; line-height: 50px;">' . $row['student_id'] . '</td><td align="left">' . $row['student_name'] . '</td><td align="left">' . $row['advisor_name'] . '</td><td align="left">' . $row['student_number'] . '</td><td align="left">' . $row['date_of_enrollment'] . '</td><td align="left">' . $row['hold_id'] . '</td>';
 $studentsID =  $row['student_id'];
echo '</tr>';
}
 
echo '</table>';

} else{
 
echo "Couldn't issue database query<br />";
 
echo mysqli_error($dcc);
 

}
}
}else{
   //if they just typed out the address without the form//
   header("Location:index.php");
    exit();    
}

 
// Close connection to the database
mysqli_close($dcc);
 
?>
</div>

<div>
<?php
    if($level ==1 || $level == 2){
             echo'<br><br><br><br><br><br><br><br>
          
    <div style="padding-left: 30px;">
    <form action="searchedstudent.php" method="post">
    <input type="text" placeholder="enter student id" name ="search"/>
    <Button type="submit"  name="submit">Search New Student</Button>
    </form>';
    if($level ==1 ){
    echo'<form style="float:left;" action="searchedstudent.php" method="post">
    <select name="hold" style="height: 30px; width: 100px;">
    <option value="" disabled>Select Hold--</option>
    <option value="0">None</option>
    <option value="4331">Academic</option>
    <option value="4332">Administration</option>
    <option value="4333">Athlete</option>
    <option value="4334">Disciplinary</option>
    <option value="4335">Financial</option>
    </select>
    <Button style="height: 30px; width: 100px;" type="submit" name="editHold" value="'.$studentsID.'">Edit Holds</Button>
    </form>';
    }
    echo'<div style="padding-left: 30px; width: 400px;">
    <form action="editgrades.php" method="post">
    <Button style="margin-left: 10px; height: 30px; width: 100px;" type="submit" name="sidSubmit" value="'.$studentsID.'">Edit Grades</Button>
    </form></div>
    <div style="padding-left: 50px; width: 400px;">
    <form action="studentschedule.php" method="post">
    <Button style="margin-left: 10px; height: 30px; width: 170px;" type="submit" name="viewStudentSchedule" value="'.$studentsID.'">viewSchedule</Button>
    </form></div>';
    
    
    }
    ?>
    
</div>
 

</body>
</html>