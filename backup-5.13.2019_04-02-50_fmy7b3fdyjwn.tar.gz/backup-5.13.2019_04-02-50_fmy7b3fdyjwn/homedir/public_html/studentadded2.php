<html>
<head>
<title>Add Student</title>
</head>
<body>
<?php
session_start();
DEFINE ('DB_USER5', 'omnicypher');
    
DEFINE ('DB_PASSWORD5', 'S3RV3R!!');
DEFINE ('DB_HOST5', 'localhost');
DEFINE ('DB_NAME5', 'g6');
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$conn = @mysqli_connect(DB_HOST5, DB_USER5, DB_PASSWORD5, DB_NAME5)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());           


   
    

    /*$f_name = mysqli_real_escape_string($conn,$_POST['first_name']);
    $l_name = mysqli_real_escape_string($conn,$POST['last_name']);
    $s_name = mysqli_real_escape_string($conn,$POST[$f_name.' '.$l_name]);
    $a_name = mysqli_real_escape_string($conn,$_POST['advisor_name']);
    $s_number = mysqli_real_escape_string($conn,$_POST['student_number']);
    $s_email = mysqli_real_escape_string($conn,$_POST['student_email']);
    $s_username = mysqli_real_escape_string($conn,$POST['student_username']);
    $s_password = mysqli_real_escape_string($conn,$POST['student_password']);
    $major = mysqli_real_escape_string($conn,$POST['major']);
    #$doe = $_POST['date_of_enrollment'];
    $hold = mysqli_real_escape_string($conn,$_POST['hold_id']);*/
    
    $f_name = $_POST['first_name'];
    $l_name =$POST['last_name'];
    $s_name = $POST[$f_name.' '.$l_name];
    $a_name = $_POST['advisor_name'];
    $s_number = $_POST['student_number'];
    $s_email = $_POST['student_email'];
    $s_username = $POST['student_username'];
    $s_password = $POST['student_password'];
    $major = $POST['major'];
    #$doe = $_POST['date_of_enrollment'];
    $hold = $_POST['hold_id'];
    
    echo 'Major: '.$major;
    
    $doe = date("Y-m-d");
    $sq1 = "SELECT * from student WHERE username = '$s_username'";
    $response = @mysqli_query($con, $query);
    $count = 0;
   
    
    $sql = "INSERT INTO student (student_name,advisor_name,student_number,date_of_enrollment,hold_id,username) VALUES ('$s_name','$a_name','$s_number','$doe','$hold','$s_username')";
    $sql2 = "INSERT INTO users (firstname,lastname,email,username,password,major) VALUES('$f_name','$l_name', '$s_email','$s_username','$s_password','$major');";              
    mysqli_query($dbc, $sql2);
    
    if(!mysqli_query($conn,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        echo'Student Inserted';
    }
    header("refresh:2; url=addstudent2.php");
   
  
         
    


?>
 
    
<div class ="sform">
<form action="studentadded2.php" method="post" id="addStudent" name="addStudent">
 
<b>Add a New Student</b>
 
<p>First Name:
<input type="text" name="first_name" size="30" value="" />
</p>

<p>Last Name:
<input type="text" name="last_name" size="30" value="" />
</p>

<select name="major">
                <option ="Computer Science">Computer Science</option>
                 <option ="Biology">Biology</option>
                 <option ="History">History</option>
                 <option ="Psychology">Psychology</option>
                <option = "Liberal Arts">Liberal Arts</option>
                  <option ="History">History</option>
</select>
 
<p>Advisor Name:
<input type="text" name="advisor_name" size="30" value="" />
</p>
    
<p>Student Number:
<input type="text" name="student_number" size="30" value="" />
</p>

<p>Student email:
<input type="text" name="student_email" size="30" value="" />
</p>
<p>Student username:
<input type="text" name="student_username" size="30" value="" />
</p>

<p>Student password:
<input type="text" name="student_password" size="30" value="" />
</p>
    

<p>
<input type="submit" name="submit" value="Send" />
</p>
 
</form>
</div>
</body>
</html>