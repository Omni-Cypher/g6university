<head>
    <Title></Title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<script src="https://unpkg.com/vue"></script>

<body>
    <header>
        <div class="main-wrapper">
            <div class="box1" style="background-color:lightblue; width: 100%;">
                <h1 style="text-align: center;">Group 6 University</h1>
            </div>
            <nav>
                <div class="main-wrapper">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                    </ul>
                    <div class="nav-login">
                        <form action="includes/login.inc.php" method="POST">
                            <input type="text" name="username" placeholder="username">
                            <input type="password" name="password" placeholder="password">
                            <button type="submit" name="submit">Login</button>
                        </form>
                        <a href="signup.php">sign up</a>
                    </div>
            </nav>
        </div>
    </header>
    <div id="app">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
            <h3>{{title}}</h3>
            <div class="form">
                <div class="form-group">
                    <label>Note title</label>
                    <input class="form-control" type="text" v-model="note.title" required>
                </div>
                <div class="form-group">
                    <label>Note text</label>
                    <textarea class="form-control" v-model="note.text" required></textarea>
                </div>
                <button class="btn btn-primary" @click="addNote">Submit</button>
                <p class="non" v-bind:class="{ active: isActive }">All fields are Required</p>
            </div>
        </div>
        <div class="col-sm-12">
            <div class="col-sm-4 note" v-for="(note, index) in notes">
                <div class="card">
                    <button class="close" @click="removeNote(index)">&times;</button>
                    <div class="card-block">
                        <h4 class="card-title">{{note.title}}</h4>
                        <h6 class="card-subtitle mb-2 text-muted">{{note.date}}</h6>
                        <p class="card-text">{{note.text}}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<style>
main-wrapper {
    margin: 0 auto;
    width: 100%;
    float: left;


}


a {
    text-decoration: none;
}

header nav {
    width: 100%;
    height: 60px;
    background-color: #fff;

}

header nav ul {
    float: left;
    padding-left: 20px;


}


header nav ul li {
    float: left;
    list-style: none;


}

header nav ul li a {
    float: left;
    font-family: arial;
    font-size: 16px;
    color: #111;
    float: left;
    line-height: 68px;
    margin-right: 10px;
}

header .nav-login {
    float: right;
    padding-right: 70px;
}

header .nav-login form {
    float: left;
    padding-top: 15px;
}

header .nav-login form input {
    float: left;
    width: 140px;
    height: 30px;
    margin-right: 10px;
    border: none;
    background-color: #ccc;
    font-family: arial;
    font-size: 14px;
    color: #111;
    line-height: 30px;
}

header .nav-login form input {
    float: left;
    width: 140px;
    height: 30px;
    margin-right: 10px;
    border: none;
    background-color: #f3f3f3;
    font-family: arial;
    font-size: 14px;
    color: #111;
    cursor: pointer;
}

header .nav-login form button {
    float: left;
    width: 60px;
    height: 30px;
    margin-right: 10px;
    border: none;
    background-color: #f3f3f3;
    font-family: arial;
    font-size: 14px;
    color: #111;
    cursor: pointer;
}

header .nav-login form button:hover {
    background-color: #ccc;
}

header .nav-login a {
    display: block;
    width: 60px;

    border: none;
    float: left;
    background-color: white;
    font-family: arial;
    font-size: 16px;
    color: #111;
    line-height: 60px;
    cursor: pointer;
}

.main-container {
    padding-top: 40px;
    background-color: cadetblue;
    margin: 10px;

}

.main-container h2 {
    font-family: arial;
    font-size: 40px;
    color: #1112;
    line-height: 63px;
    text-align: center;
}

.content {}

/** styling for signup.php**/
.signup-form {
    width: 400px;
    margin: 0 auto;
    padding-top: 30px;

}

.signup-form input {

    width: 90%;
    height: 40px;
    border: none;
    background-color: #fff;
    font-family: arial;
    font-size: 16px;
    line-height: 40px;
    color: #111;
    margin-bottom: 4px;
}

.studentinfo {

    color: red;
}


.signup-form button {
    display: block;
    margin: 0 auto;
    width: 30%;
    height: 40px;
    border: none;
    background-color: #222;
    font-family: arial;
    font-size: 16px;
    line-height: 40px;
    color: #fff;
    cursor: pointer;

}

.signup-form button:hover {
    background-color: #111;
}

/** footer **/

.footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: cadetblue;
    color: white;
    text-align: center;
}

.ft1 {
    float: left;
    border-right: solid;
    border-right-color: blue;
    width: 33%;
}

.ft2 {
    float: left;
    border-right: solid;
    border-right-color: blue;
    width: 33%;
}

.ft3 {
    float: left;
    border-right: solid;
    border-right-color: blue;
    width: 33%;
}

.colimg {
    float: left;

}


.box2 {
    margin-right: 10px;
    align-content: left;
    float: left;
    height: 200px;
    width: 770px;
    text-align: left;
    font-size: 20px;
    font-family: sans-serif;
    position: relative;
    background-color: cadetblue;
    margin-top: 20px;
    border: solid;
    border-color: white;
    border-width: thick;

}

.box3 {
    align-content: left;
    float: left;
    height: 200px;
    width: 720px;
    text-align: left;
    font-size: 20px;
    font-family: sans-serif;
    position: relative;
    background-color: cadetblue;
    margin-top: 20px;
    border: solid;
    border-color: white;
    border-width: thick;
}

/** legacy style **/

.studentform {
    font-family: monospace;
    padding-left: 40px;
    background-color: cadetblue;
}

.navbox {
    color: darkcyan;
    align-content: center;
    text-align: center;
    padding-right: 10px;

    padding: 5px;
    font-family: sans-serif;
    background-color: cadetblue;
    position: relative;
    border-radius: 10px;
}

.box1 {

    align-content: center;
    border: solid;
    background-color: cadetblue;
    height: 100px;
    width: 100%;
    padding-top: 10px;
    text-align: center;
    font-size: 20px;
    font-family: roboto;
    position: relative;

}

.maintitle {
    position: relative;
    align-content: center;
    top: 30px;
    font-size: 200%;
}


.logo {
    float: left;
    position: relative;
    left: 550px;
    top: 20px;

}

.colback {

    position: relative;


}

.wlp {
    background-color: red;
    background: url(images/graduates.jpg) repeat 0 0;
}


body {
    margin: 30px;
    background: #f3f3f3;
}

.card {
    margin: 20px 0;
    background: #ffffff;
    border: 10px;
    padding: 20px;
}

.non {
    display: none;
}

.active {
    display: block;
}

<style type="text/css">td {
    color: black;
    text-align: center
}

td:hover {
    background-color: dodgerblue;
    color: maroon;
}

th:hover {
    background-color: maroon;
    color: dodgerblue
}

.square {
    height: 130px;
    width: 130px;
}
</style>
<script>
var app = new Vue({
    el: '#app',
    data: {
        isActive: false,
        title: 'Student Notes',
        note: {
            title: '',
            text: ''
        },
        notes: [{
            title: 'Mathematics',
            text: '1+1=2',
            date: new Date(Date.now()).toLocaleString()
        }]
    },
    methods: {
        addNote() {
            let {
                text,
                title
            } = this.note

            if (this.note.text.length > 1 && this.note.title.length > 1) {
                this.notes.push({
                    text,
                    title,
                    date: new Date(Date.now()).toLocaleString()
                })
                this.isActive = false;
                this.note.text = "";
                this.note.title = "";
            } else {
                this.isActive = true;
            }
        },
        removeNote(index) {
            this.notes.splice(index, 1)
        }
    }
})
</script>

</html>