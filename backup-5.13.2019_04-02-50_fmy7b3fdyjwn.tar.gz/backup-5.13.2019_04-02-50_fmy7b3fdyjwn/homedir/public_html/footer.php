</body>
<div class="footer">
        <div class="ft1">
            <p style="text-align: left; padding: 10px;">Juvon Hyatt Copyright 2018-2019</p>
        </div>

        <div class="ft2">
            <p style="text-align: left; padding: 10px;">Juvon Hyatt Copyright 2018-2019</p>
        </div>

        <div class="ft3">
            <p style="text-align: left; padding: 10px;">Juvon Hyatt Copyright 2018-2019</p>
        </div>
    </div>
    
</html>