<?php
session_start();

if(isset($_POST['submit'])){
    



                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $firstname = $_SESSION['firstname'];
                 $lastname = $_SESSION['lastname'];
                 $studentid = $_SESSION['student_id'];
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$conn = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
    
    $uid = mysqli_real_escape_string($conn,$_POST['username']);
    $pwd = mysqli_real_escape_string($conn,$_POST['password']);
    
    //error handler
    
    if( empty($uid) || empty($pwd)){
        header("Location: ../index.php?login=empty");
        exit();
    }else{
        $sql = "SELECT * FROM users WHERE username='$uid' OR email='$uid'";
        $result = mysqli_query($conn,$sql);
        $resultCheck = mysqli_num_rows($result);
        if($resultCheck<1){
            header("Location: ../index.php?login=empty");
            exit();
        }else{
            if($row = mysqli_fetch_assoc($result)){
                //dehashing password
                $hashedCheck = password_verify($pwd,$row['password']);
                if($hashedCheck==false){
                   header("Location: ../index.php?login=error");
                   exit(); 
                }elseif($hashedCheck==true){
                    //log in the user here
                    $_SESSION['level'] = $row['level'];
                    $_SESSION['id'] = $row['id'];
                    $_SESSION['student_id'] = $row['student_id'];
                    $_SESSION['firstname'] = $row['firstname'];
                    $_SESSION['lastname'] = $row['lastname'];
                    $_SESSION['email'] = $row['email'];
                    $_SESSION['username'] = $row['username'];
                     $_SESSION['major'] = $row['major'];
                    header("Location: ../index.php?login=success");
                    exit();
                }
            }
        }
    }
    
 
}

else if(isset($_POST['submit2'])){
 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $firstname = $_SESSION['firstname'];
                 $lastname = $_SESSION['lastname'];
                 $studentid = $_SESSION['student_id'];
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$conn = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
    
    $uid = mysqli_real_escape_string($conn,$_POST['username']);
    $pwd = mysqli_real_escape_string($conn,$_POST['password']);
    
    //error handler
    
    if( empty($uid) || empty($pwd)){
        header("Location: ../index.php?login=empty");
        exit();
    }else{
        $sql = "SELECT * FROM users WHERE username='$uid' OR email='$uid'";
        $result = mysqli_query($conn,$sql);
        $resultCheck = mysqli_num_rows($result);
        if($resultCheck<1){
            header("Location: ../index.php?login=empty");
            exit();
        }else{
            if($row = mysqli_fetch_assoc($result)){
                //dehashing password
                $hashedCheck = password_verify($pwd,$row['password']);
                if($hashedCheck==false){
                   header("Location: ../index.php?login=error");
                   exit(); 
                }elseif($hashedCheck==true){
                    //log in the user here
                    $_SESSION['id'] = $row['id'];
                    $_SESSION['student_id'] = $row['student_id'];
                    $_SESSION['firstname'] = $row['firstname'];
                    $_SESSION['lastname'] = $row['lastname'];
                    $_SESSION['email'] = $row['email'];
                    $_SESSION['username'] = $row['username'];
                    header("Location: ../register.php?login=success");
                    exit();
                }
            }
        }
    }
    
 
}
else{
        header("Location: ../index.php?login=error");
        exit();
    }