<?php
session_start();

if(isset($_POST['submit'])){
    
     //-------------------------------------------------------------//student--------------------------------------------------------------------
    DEFINE ('DB_USER4', 'omnicypher');
    
    DEFINE ('DB_PASSWORD4', 'S3RV3R!!');
DEFINE ('DB_HOST4', 'localhost');
DEFINE ('DB_NAME4', 'g6');
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$conn = @mysqli_connect(DB_HOST4, DB_USER4, DB_PASSWORD4, DB_NAME4)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
    
    $first = mysqli_real_escape_string($conn,$_POST['firstname']);
    $last = mysqli_real_escape_string($conn,$_POST['lastname']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $uid = mysqli_real_escape_string($conn,$_POST['username']);
    $pwd = mysqli_real_escape_string($conn,$_POST['password']);
    $major = mysqli_real_escape_string($conn,$_POST['Major']);
    $student_id = mysqli_real_escape_string($conn,$_POST['student_id']);
    
    //error handlers
    //Check for empty fields
    
    if(empty($first) || empty($last) || empty($email) || empty($uid) || empty($pwd) || empty($major) ){
        
        $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: One of more fields left empty</div>';
        
        header("Location: ../accounts.php?signup=emptyfield"); //signup=empty shows error message 
        exit();  
    }else{
        //check if input characters are valid
        if(!preg_match("/^[a-zA-Z]*$/",$first) || !preg_match("/^[a-zA-Z]*$/",$last) ){
            
             $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: Invalid Name</div>';

            header("Location: ../accounts.php?signup=invalid"); //signup=invalid shows error message 
            exit(); 
        }else{
            //check if email is valid
            if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
                
        
             $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: Invalid Email</div>';
    
               header("Location: ../accounts.php?signup=email"); //signup=email shows error message 
               exit();  
            }else{
                $sql = "SELECT * FROM users WHERE username='$uid'";
                $result = mysqli_query($conn,$sql);
                $resultCheck = mysqli_num_rows($result);
                if($resultCheck>0){
                    
                $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: Username Unavaliable</div>';
                   
                    header("Location: ../accounts.php?signup=usertaken"); //signup=usertaken shows error message 
                    exit();
                }else{
                    //hashing password
                    $hashedpwd = password_hash($pwd, PASSWORD_DEFAULT);
                    //insert the user into the database
                    $fullname = $first.' '.$last;
                    $doe = date('Y-m-d');
                    $sql = "INSERT INTO users (firstname,lastname,email,username,password,student_id,major) VALUES('$first','$last', '$email','$uid','$hashedpwd','$student_id','$major');";
                    $sql2="INSERT INTO `student` (`Student_Name`, `Date_Of_Enrollment`) VALUES ('$fullname','$doe');";
                    mysqli_query($conn,$sql);
                    mysqli_query($conn,$sql2);
    
                      
                    
                    $_SESSION['success'] = '<div style="color: lightgreen; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Account has been successfully created!</div>';
                    header("Location: ../accounts.php?signup=success"); 
                    exit();
                }
            }
        }
    }
}else if(isset($_POST['submit2'])){
    //-------------------------------------------------------------//faculty--------------------------------------------------------------------
    
    
    DEFINE ('DB_USER4', 'omnicypher');
    
    DEFINE ('DB_PASSWORD4', 'S3RV3R!!');
DEFINE ('DB_HOST4', 'localhost');
DEFINE ('DB_NAME4', 'g6');
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$conn = @mysqli_connect(DB_HOST4, DB_USER4, DB_PASSWORD4, DB_NAME4)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
    
    $first = mysqli_real_escape_string($conn,$_POST['firstname']);
    $last = mysqli_real_escape_string($conn,$_POST['lastname']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $uid = mysqli_real_escape_string($conn,$_POST['username']);
    $pwd = mysqli_real_escape_string($conn,$_POST['password']);
     $level = mysqli_real_escape_string($conn,$_POST['level']);
    
    //error handlers
    //Check for empty fields
    
    if(empty($first) || empty($last) || empty($email) || empty($uid) || empty($pwd)){
        
            $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: One of more fields left empty</div>';

        header("Location: ../accounts.php?signup=emptyfield"); //signup=empty shows error message 
        exit();  
    }else{
        //check if input characters are valid
        if(!preg_match("/^[a-zA-Z]*$/",$first) || !preg_match("/^[a-zA-Z]*$/",$last) ){
                
                $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: Invalid Name</div>';

            header("Location: ../accounts.php?signup=invalid"); //signup=invalid shows error message 
            exit(); 
        }else{
            //check if email is valid
            if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        
             $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: Invalid Email</div>';
      
               header("Location: ../accounts.php?signup=email"); //signup=email shows error message 
               exit();  
            }else{
                $sql = "SELECT * FROM users WHERE username='$uid'";
                $result = mysqli_query($conn,$sql);
                $resultCheck = mysqli_num_rows($result);
                if($resultCheck>0){
                    
                    $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: Username Unavaliable</div>';
                    
                    header("Location: ../accounts.php?signup=usertaken"); //signup=usertaken shows error message 
                    exit();
                }else{
                    //hashing password
                    $hashedpwd = password_hash($pwd, PASSWORD_DEFAULT);
                    //insert the user into the database
                    $fullname = $first.' '.$last;
                    $doe = date('Y-m-d');
                    $sql = "INSERT INTO users (firstname,lastname,email,username,password,level) VALUES('$first','$last', '$email','$uid','$hashedpwd','2');";
                    mysqli_query($conn,$sql);
                    mysqli_query($conn,$sql2);
    
                      
                    
                    $_SESSION['success'] = '<div style="color: lightgreen; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Account has been successfully created!</div>';
                    header("Location: ../accounts.php?signup=success"); 
                    exit();
                }
            }
        }
    }

    
}else if(isset($_POST['submit3'])){
    
    //-------------------------------------------------------------//Admin--------------------------------------------------------------------
    
    
    DEFINE ('DB_USER4', 'omnicypher');
    
    DEFINE ('DB_PASSWORD4', 'S3RV3R!!');
DEFINE ('DB_HOST4', 'localhost');
DEFINE ('DB_NAME4', 'g6');
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$conn = @mysqli_connect(DB_HOST4, DB_USER4, DB_PASSWORD4, DB_NAME4)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
    
    $first = mysqli_real_escape_string($conn,$_POST['firstname']);
    $last = mysqli_real_escape_string($conn,$_POST['lastname']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $uid = mysqli_real_escape_string($conn,$_POST['username']);
    $pwd = mysqli_real_escape_string($conn,$_POST['password']);
     $level = mysqli_real_escape_string($conn,$_POST['level']);
    
    //error handlers
    //Check for empty fields
    
    if(empty($first) || empty($last) || empty($email) || empty($uid) || empty($pwd)){
            $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: One of more fields left empty</div>';
        header("Location: ../accounts.php?signup=emptyfield"); //signup=empty shows error message 
        exit();  
    }else{
        //check if input characters are valid
        if(!preg_match("/^[a-zA-Z]*$/",$first) || !preg_match("/^[a-zA-Z]*$/",$last) ){
          
            $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: Invalid Name</div>';
            
            header("Location: ../accounts.php?signup=invalid"); //signup=invalid shows error message 
            exit(); 
        }else{
            //check if email is valid
            if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
          
            $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: Invalid Email</div>';
    
               header("Location: ../accounts.php?signup=email"); //signup=email shows error message 
               exit();  
            }else{
                $sql = "SELECT * FROM users WHERE username='$uid'";
                $result = mysqli_query($conn,$sql);
                $resultCheck = mysqli_num_rows($result);
                if($resultCheck>0){
                $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: Username Unavaliable</div>';
                    header("Location: ../accounts.php?signup=usertaken"); //signup=usertaken shows error message 
                    exit();
                }else{
                    //hashing password
                    $hashedpwd = password_hash($pwd, PASSWORD_DEFAULT);
                    //insert the user into the database
                    $fullname = $first.' '.$last;
                    $doe = date('Y-m-d');
                    $sql = "INSERT INTO users (firstname,lastname,email,username,password,level) VALUES('$first','$last', '$email','$uid','$hashedpwd','1');";
                    mysqli_query($conn,$sql);
                    mysqli_query($conn,$sql2);
    
                      
                    
                    $_SESSION['success'] = '<div style="color: lightgreen; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Account has been successfully created!</div>';
                    header("Location: ../accounts.php?signup=success"); 
                    exit();
                }
            }
        }
    }

    

    
}
else if(isset($_POST['submit4'])){
    //-------------------------------------------------------------//Researcher--------------------------------------------------------------------
    
    
    DEFINE ('DB_USER4', 'omnicypher');
    
    DEFINE ('DB_PASSWORD4', 'S3RV3R!!');
DEFINE ('DB_HOST4', 'localhost');
DEFINE ('DB_NAME4', 'g6');
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$conn = @mysqli_connect(DB_HOST4, DB_USER4, DB_PASSWORD4, DB_NAME4)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
    
    $first = mysqli_real_escape_string($conn,$_POST['firstname']);
    $last = mysqli_real_escape_string($conn,$_POST['lastname']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $uid = mysqli_real_escape_string($conn,$_POST['username']);
    $pwd = mysqli_real_escape_string($conn,$_POST['password']);
     $level = mysqli_real_escape_string($conn,$_POST['level']);
    
    //error handlers
    //Check for empty fields
    
    if(empty($first) || empty($last) || empty($email) || empty($uid) || empty($pwd)){
        $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: One of more fields left empty</div>';
        header("Location: ../accounts.php?signup=emptyfield"); //signup=empty shows error message 
        exit();  
    }else{
        //check if input characters are valid
        if(!preg_match("/^[a-zA-Z]*$/",$first) || !preg_match("/^[a-zA-Z]*$/",$last) ){
            $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: Invalid Name</div>';
            header("Location: ../accounts.php?signup=invalid"); //signup=invalid shows error message 
            exit(); 
        }else{
            //check if email is valid
            if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
                $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: Invalid Email</div>';
               header("Location: ../accounts.php?signup=email"); //signup=email shows error message 
               exit();  
            }else{
                $sql = "SELECT * FROM users WHERE username='$uid'";
                $result = mysqli_query($conn,$sql);
                $resultCheck = mysqli_num_rows($result);
                if($resultCheck>0){
                    $_SESSION['success'] = '<div style="color: red; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Failed! Cannot add account, Reason: Username Unavaliable</div>';
                    header("Location: ../accounts.php?signup=usertaken"); //signup=usertaken shows error message 
                    exit();
                }else{
                    //hashing password
                    $hashedpwd = password_hash($pwd, PASSWORD_DEFAULT);
                    //insert the user into the database
                    $fullname = $first.' '.$last;
                    $doe = date('Y-m-d');
                    $sql = "INSERT INTO users (firstname,lastname,email,username,password,level) VALUES('$first','$last', '$email','$uid','$hashedpwd','3');";
                    mysqli_query($conn,$sql);
                    mysqli_query($conn,$sql2);
    
                      
                    
                    $_SESSION['success'] = '<div style="color: lightgreen; font-size: 20px; padding-bottom: 10px; padding-left: 80px;">Status: Account has been successfully created!</div>';
                    header("Location: ../accounts.php?signup=success"); 
                    exit();
                }
            }
        }
    }

    
}else{
    //if they just typed out the address without the form//
    header("Location: ../signup.php");
    exit();    
}