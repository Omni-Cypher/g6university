<!DOCTYPE html>
<!-- html by Juvon Hyatt -->
<html>

<head>
    <meta charset="utf-8">
    <title>Group 6 University</title>
</head>
<title>Course Search</title>

<body class="main" body style="background-color:powderblue;">
<?php
DEFINE ('DB_USER', 'omnicypher');
    
DEFINE ('DB_PASSWORD', 'S3RV3R!!');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'g6');
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
   
             echo'<b><h1 style="padding-top: 50px; padding-left: 40px;";>Course Search</h1></b>
    <div style="padding-left: 40px;">
    <p> Day Search </p>
    <form action="searchedCourse.php" method="post">
    <select name="day-dropdown">
    <option value="monday-wednesday">Monday - Wednesday</option>
    <option value="tuesday-thursday"">Tuesday - Thursday</option>
    <option value="friday">Friday</option>
    </select>
    <Button type="submit" name="submit">Search</Button>
    </form></div>';
    
    echo'
     <div style="padding-left: 40px;">
    <p> Time Search </p>
    <form action="searchedCourse.php" method="post">
    <select name="time-dropdown">
    <option value="1">8:00 am - 9:30 am</option>
    <option value="2">9:40 am - 11:10 am</option>
    <option value="3">11:20 am - 12:50 pm</option>
    <option value="4">1:00 pm - 2:30 pm</option>
    <option value="5">2:40 pm - 3:40 pm</option>
    <option value="6">3:50 pm - 5:20 pm</option>
    <option value="7">5:30 pm - 7:00 pm</option>
    <option value="8">7:10 pm - 8:40 pm</option>
    <option value="9">8:50 pm - 10:20 pm</option>
    </select>
    <Button type="submit" name="submit2">Search</Button>
    </form></div>';
    
    echo'
     <div style="padding-left: 40px;">
    <p> CRN Search </p>
    <form action="searchedCourse.php" method="post">
    <input type="text" name="CRN">
    <Button type="submit" name="submit4">Search</Button>
    </form></div>';
    
    echo'
     <div style="padding-left: 40px;">
    <p> Semester Search </p>
    <form action="searchedCourse.php" method="post">
    <select name="semester-dropdown">
    <option value="spring">Spring 2019</option>
    <option value="summer">Summer 2019</option>
    <option value="fall">Fall 2019</option>
     <option value="winter">Winter 2019</option>

    </select>
    <Button type="submit" name="submit5">Search</Button>
    </form></div>';
    
     echo'
     <div style="padding-left: 40px;">
    <p> Department Search </p>
    <form action="searchedCourse.php" method="post">
    <select name="dep-dropdown">
    <option value="Politics Economics & Law">Politics Economics & Law</option>
    <option value="Psychology">Psychology</option>
    <option value="Public Health">Public Health</option>
    <option value="School of business">School of business</option>
    <option value="school of Education">school of Education</option>
    <option value="Sociology">Sociology</option>
    <option value="Public Health">Public Health</option>
    <option value="School of Professional Studies">School of Professional Studies</option>
    <option value="Visual Arts">Visual Arts</option>
    <option value="American Studies">American Studies</option>
    <option value="Biological Sciences">Biological Sciences</option>
    <option value="Chemistry and Physics">Chemistry and Physics</option>
    <option value="Computer Science">Computer Science</option>
    <option value="English">English</option>
    <option value="History and Philosophy">History and Philosophy</option>
    <option value="Criminology">Criminology</option>
    <option value="Industrial & Labor Relations">Industrial & Labor Relations</option>
    <option value="Liberal Studies">Liberal Studies</option>
    <option value="Mathematics">Mathematics</option>
    <option value="Modern Languages">Modern Languages</option>
    
    </select>
    <Button type="submit" name="submit6">Search</Button>
    </form></div>';
      
      
   
?>
</body>
</html>