<html>
<head>
    <Title></Title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<style>
    @import url(https://fonts.googleapis.com/css?family=Roboto:300);

    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 70%;
    }

    td,
    th {
        border: 2px solid cadetblue;
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(odd) {
        background-color: #dddddd;
    }

    .mschedual {
        align-content: center;

        height: 1400px;
        width: 750px;
        text-align: left;
        font-size: 20px;
        font-family: sans-serif;
        position: relative;
        background-color: cadetblue;
        margin-top: 20px;
        border: solid;
        border-color: white;
        border-width: thick;
        margin-left: 350px;
        margin-right: 350px;
        padding-left: 10px;
        padding-right: 10px;
    }

   
</style>
<body>
     <header>
     <div class ="main-wrapper">
          <div class="box1" style="background-color:lightblue; width: 100%;">
        <h1 style="text-align: center;">Group 6 University</h1>
         </div>
                 <?php
                 session_start();

                 $student_id = $_SESSION['student_id'];
                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $firstname = $_SESSION['firstname'];
                 $lastname = $_SESSION['lastname'];
                 $major = $_SESSION['major'];
                
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');

// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());

                    if(isset($_SESSION['username'])){
                        
                        //extra admin privlages
                        $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 1";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                        if($resultCheck>0){
                            $_SESSION['level'] = 1;
                           $level = $_SESSION['level'];
                        //if you are an admin
           
                        
                            echo '<nav>
                       
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                 
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="studentsearch.php">Search student</a></li>
                        <li><a href="accounts.php">Manage Accounts</a></li>
                        <li><a href="courseManager.php">Course Manager</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
         
                        //** add more admin abilities above **/    
                       
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form><div></nav>';
                            
                        }else{
                            
                         $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 0";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                           $_SESSION['level'] = 0;
                           $level = $_SESSION['level'];
                         //if you are an student user
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="StudentMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="degreeAudit.php">Degree Audit</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                               $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 2";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
              
                                //if you are an faculty

                                $_SESSION['level'] = 2;
                                $level =  $_SESSION['level'];
                           
                                
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="facultyMain.php">My Profile</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                        <li><a href="studentManager.php">Student Manager</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                        }else{
                            
                                 $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level = 3";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        
                            if($resultCheck>0){
                                //you are a researcher
                            
                             $_SESSION['student_id'] = 0;
                                $_SESSION['level'] = 3;
                                $level =  $_SESSION['level'];
                     
                                
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="research.php">Research</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                         <li><a href="academicCalender.php">Academic Calender</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form></div></nav>';
                            
                           }
                       }
                        
                     }
                  }
                }else{
                                echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                  
                        <li><a href="MasterSchedule.php">Master Schedule</a></li>
                        <li><a href="academicCalender.php">Academic Calender</a></li>
                        <li><a href="https://www.oldwestbury.edu/sites/default/files/documents/Catalogs/2018-20/undergrad-catalog-18-20.pdf">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
                         echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                   <button type="submit" name="submit">Login</button>
                    </form>
                    <!--<a href="signup.php">sign up</a></div></nav>-->';
                    }
                ?>
                  
                </div>

    </header>
    
<body class="main" body style="background-color:powderblue;">
<div class="studentinfo">
<?php
session_start();
// Get a connection for the database

                 $uid = $_SESSION['username'];
                 $email = $_SESSION['email'];
                 $id = $_SESSION['id'];
                 $username = $_SESSION['username'];
                 $username = $_SESSION['username'];
                 $level = $_SESSION['level'];
              
                 $cid = $_POST['cidSubmit2'];
                 DEFINE ('DB_USER3', 'omnicypher');
    
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');
                
                
 
// $dcc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dcc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
 


// Create a query for the database
 if(isset($_POST['cidSubmit2'])){
     
     $newGrade = $_POST['sGrades'];
     
     $cid = $_POST['cid2'];
     
     $sid2 = $_POST['sid2'];
     
     $_POST['sidSubmit'] = $sid2; //making sure when posted from cidSubmit 2 that the sid submit that prints the table isnt null;
     

 }

if(isset($_POST['sidSubmit']) ||isset($_POST['cidSubmit2'])  ){
    
    

 
$sid = $_POST['sidSubmit'];
$cid = $_POST['cid2'];

if($level == 1){
$query = "SELECT * FROM transcript 
INNER JOIN course
ON course.Course_ID = transcript.Course_ID
WHERE student_id ='$sid'";
}
if($level ==2){
    $query = "SELECT * FROM transcript 
INNER JOIN course
ON course.Course_ID = transcript.Course_ID
WHERE student_id ='$sid' and Semester_ID = 'Summer 2019'";
}



if($_POST['cidSubmit2']!=null){
   $query2 = "UPDATE transcript
SET Grades = '$newGrade'
WHERE Student_ID = '$sid'
AND
Course_ID = '$cid'";
}

// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dcc, $query2);
$response = @mysqli_query($dcc, $query);

// If the query executed properly proceed
if($response){

if($level == 1){
echo'<h1 style="color: cadetblue;padding-top: 20px;padding-left:15px; font-size:200%;">&nbsp;&nbsp;Edit Student Transcript</h1><br><br>';
}
else if($level== 2){
    echo'<h1 style="color: cadetblue;padding-top: 20px;padding-left:15px; font-size:200%;">&nbsp;&nbsp;Edit Student Grades</h1><br><br>';
}
echo '<table style="margin-bottom: 6px; align="left" cellspacing="5" cellpadding="8">
<tr><tr style="color:black;"><td align="left"><b>&emsp;&emsp;Student ID&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Course ID&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Course Name&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Grade&emsp;&emsp;&emsp;&emsp;</b></td>
<td align="left"><b>Semester&emsp;&emsp;&emsp;&emsp;</b></td></tr>';
 
// mysqli_fetch_array will return a row of data from the query
// until no further data is available

$count=0;
while($row = mysqli_fetch_array($response)){
      $course_ID2 =  $row['Course_ID'];
      $Student_ID = $sid;
echo '<tr><td align="left" style="padding-left: 30px; line-height: 50px;">' .$sid . '</td><td align="left">' . $row['Course_ID'] . '</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['Grades'] . '</td><td align="left">' . $row['Semester'] .'</td>';


echo '</tr>';
}
 
echo '</table>';
echo'<br><br>';
echo'<div style="position:fixed; bottom:50; right: 0px; width:28%; z-index:100; height: 170px; background-color: white; padding: 10px; border-radius: 10px 0px 0px 10px;"><p><form action="editgrades.php" method="POST">

<input type="text" placeholder="Enter Course ID" name="cid2">
<select name="sGrades">
<option value = "A">A</option>
<option value = "B">B</option>
<option value = "C">C</option>
<option value = "D">D</option>
<option value = "F">F</option>
</select>
<input type="hidden" value='.$sid.' name="sid2">
<input type="submit" name="cidSubmit2" value="change grade"></p>';
echo '<div style =" color: black; padding-left: 10px; height: 42px;">Change log:<br>Course ID: '.$cid.'<br>';
    
    echo 'Student ID: '.$sid2.'<br>';
     
    echo'New Grade: '.$newGrade.'<br><br></div>';
    echo'<br><br>
    <div style="float: left; padding-left: 10px;">
    <form action="studentSearch.php" method="post">
    <Button type="submit" name="submit">Search Other Student</Button>
    </form></div>';
echo'</div>';


   
    
    


} else{
 
echo "Couldn't issue database query<br />";
 
echo mysqli_error($dcc);
 
}
}


else{
    //if they just typed out the address without the form//
    header("Location:studentsearch.php");
    exit();    
}

 
// Close connection to the database
mysqli_close($dcc);
 
?>
</div>

<div>
</div>
<?php
    
            
    
     if($level > 0){
         /*
        echo' <div style="padding-left: 30px;">
    <form action="editgrades.php" method="post">
    <Button style="height: 70px; width: 120px;" type="submit; float: left;" name="submit" value="'.$studentsID.'">Edit Grades</Button>
    </form></div>';*/
    }
    
    ?>
    

 

</body>
</html>