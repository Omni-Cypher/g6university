$(document).ready(function(){
    var dataSource = [
        { Gender: "Female", area: 1707540},
        { Gender: "Male", area: 998467},
     
        ];
        
        $("#chartContainer").dxPieChart({
            dataSource: dataSource,
            series: {
                    argumentField: "Gender",
                    valueField: "area",
                    type : "doughnut"
                }
            
        });
})