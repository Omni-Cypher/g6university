<?php
include_once 'header.php';
?>

    <section class="main-container">
        <div class="main-wrapper"></div>
        <h2>Signup</h2>
        <form class="signup-form" action="includes/signup.inc.php" method="POST">
            <input type="text" name="firstname" placeholder="Firstname">
            <input type="text" name="lastname" placeholder="Lastname">
            <input type="text" name="email" placeholder="username/e-mail">
            <input type="text" name="username" placeholder="username">
            <input type="password" name="password" placeholder="password">
            <button type="submit" name="submit">Signup</button>
        </form>
        </div>
    </section>

<?php
include_once 'footer.php';
?>
