<?php
session_start();
?>
<html>
<head>
    <Title></Title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
    @import url(https://fonts.googleapis.com/css?family=Roboto:300);

    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
    }

    td,
    th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(even) {
        background-color: #dddddd;
    }

    .mschedual {
        align-content: center;

        height: 1400px;
        width: 750px;
        text-align: left;
        font-size: 20px;
        font-family: sans-serif;
        position: relative;
        background-color: cadetblue;
        margin-top: 20px;
        border: solid;
        border-color: white;
        border-width: thick;
        margin-left: 350px;
        margin-right: 350px;
        padding-left: 10px;
        padding-right: 10px;
    }


    .footer {
        
        position: relative;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: lightblue;
        color: white;
        text-align: center;
        padding-top: 10px;
    }

    .ft1 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .ft2 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .ft3 {
        float: left;
        border-right: solid;
        border-right-color: blue;
        width: 33%;
        background-color: cadetblue;
    }

    .colimg {
        float: left;

    }

    .slink {
        size: 200px;
    }

    .logout {
        font-family: monospace;
        background-color: skyblue;
        color: black;
        position: absolute;
        top: -15px;
        right: -9px;
        border-radius: 5px;
        padding: 3px;
        width: 80px;
    }

    .msboxsub {
        height: 100%;
        width: 100%;
        position: relative;
        border: solid;
        border-color: white;
    }
</style>
</head>



<body class="main" body style="background-color:powderblue;">
<header>
     <div class ="main-wrapper">
          <div class="box1" style="background-color:lightblue">
        <h1 style="text-align: center;">Group 6 University</h1>
         </div>
         

                 <?php
                 
                DEFINE ('DB_USER3', 'omnicypher');
                DEFINE ('DB_PASSWORD3', 'S3RV3R!!');
                DEFINE ('DB_HOST3', 'localhost');
                DEFINE ('DB_NAME3', 'g6');
                
                
 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser
 
$dbc = @mysqli_connect(DB_HOST3, DB_USER3, DB_PASSWORD3, DB_NAME3)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());

                 
                 
                 
                    if(isset($_SESSION['username'])){
                        
                        //extra admin privlages
                        $name = $_SESSION['username'];
                        $sql = "SELECT * FROM users WHERE username='$name' AND level>0";
                        $result = mysqli_query($dbc,$sql);
                        $resultCheck = mysqli_num_rows($result);
                        if($resultCheck>0){
                        //if you are an admin
                        
                            echo '<nav>
                       
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="index.html">Student</a></li>
                        <li><a href="index.html">Admissions</a></li>
                        <li><a href="coursecatalog.php">Course Catalog</a></li>
                        <li><a href="studentsearch.php">Search Student</a></li>
                        <li><a href="addstudent2.php">Add Student</a></li>
                    </ul>
                        <div class="nav-login">';
         
                        //** add more admin abilities above **/    
                       
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form>';
                            
                        }else{
                         //if you are an regular user
                           echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="StudentMain.html">Student</a></li>
                        <li><a href="admissions.html">Admissions</a></li>
                        <li><a href="coursecatalog.php">Course Catalog</a></li>
                        <li><a href="index.html">My Profile</a></li>
                    </ul>
                        <div class="nav-login">';
                            
                            echo '<form action="includes/logout.inc.php" method="POST">
                        <Button type="submit" name="submit">Logout</Button>
                        </form>';   
                        }
                }else{
                                echo '<nav>
                        <div class ="main-wrapper">
                    <ul style="position:relative; bottom: 20px;">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="StudentMain.html">Student</a></li>
                        <li><a href="admissions.html">Admissions</a></li>
                        <li><a href="coursecatalog.php">Course Catalog</a></li>
                    </ul>
                        <div class="nav-login">';
                         echo'<form action="includes/login.inc.php" method="POST">
                    <input type="text" name="username" placeholder="username">
                    <input type="password" name="password" placeholder="password">
                    <button type="submit" name="submit">Login</button>
                    </form>
                    <a href="signup.php">sign up</a>';
                    }
             mysqli_close($dbc); ?>
                  
                </div>

    </header>
<div style="position:fixed; bottom:10; right: 0px; width:30%; z-index:100; hight: 200px; background-color: white; padding: 10px; border-radius: 10px 0px 0px 10px;">
   <form action="register.php" method="post">
        <input type="Text" placeholder="enter course id" name="class_id">
         <Button type="submit" name="reg">Register</Button>
   </form>
  
</div>
<div class="studentinfo">

<?php 
DEFINE ('DB_USER', 'omnicypher');
    
DEFINE ('DB_PASSWORD', 'S3RV3R!!');
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'g6');
     

 
// $dbc will contain a resource link to the database
// @ keeps the error from showing in the browser

$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
OR die('Could not connect to MySQL: ' .
mysqli_connect_error());
if(isset($_POST['submit'])){
$day = $_POST['day-dropdown'];

if($day=="monday-wednesday"){
    $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Day = 'Monday - Wednesday';

";
}
if($day=="tuesday-thursday"){
    $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Day = 'Tuesday - Thursday';

";
}else if($day=="friday"){
        $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Day = 'Friday';

";
}  
}
 
 
 if(isset($_POST['submit2'])){
$time = $_POST['time-dropdown'];

if($time=="1"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Time_Slot = '8:00 am - 9:30 am';
";
}

if($time=="2"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Time_Slot = '9:40 am - 11:10 am';
";
}

if($time=="3"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Time_Slot = '11:20 am - 12:50 pm';
";
}

if($time=="4"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Time_Slot = '1:00 pm - 2:30 pm';
";
}

if($time=="5"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Time_Slot = '2:40 pm - 3:40 pm';
";
}

if($time=="6"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Time_Slot = '3:50 pm - 5:20 pm';
";
}

if($time=="7"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Time_Slot = '5:30 pm - 7:00 pm';
";
}

if($time=="8"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Time_Slot = '7:10 pm - 8:40 pm';
";
}

else if($time=="9"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Time_Slot = '8:50 pm - 10:20 pm';
";
}
 
}


if(isset($_POST['submit4'])){
$crn = $_POST['CRN'];
    $query = 'SELECT course.Course_ID,course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE course.CRN = "'.$crn.'"';

}

 if(isset($_POST['submit5'])){
$semester = $_POST['semester-dropdown'];

if($semester=="spring"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Semester_ID = 'Spring 2019';
";
}

if($semester=="summer"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Semester_ID = 'Summer 2019';
";
}

if($semester=="fall"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Semester_ID = 'Fall 2019';
";
}

else if($semester=="winter"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Semester_ID = 'Winter 2019';
";
}

 
}

if(isset($_POST['submit6'])){
$department = $_POST['dep-dropdown'];

if($department=="Politics Economics & Law"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'Politics Economics & Law';
";
}

if($department=="Psychology"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'Psychology';
";
}

if($department=="Public Health"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'Public Health';";
}

if($department=="School of business"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'School of business';
";
}

if($department=="school of Education"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'school of Education';
";
}
if($department=="Sociology"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'Sociology';
";
}
if($department=="School of Professional Studies"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'School of Professional Studies';
";
}
if($department=="Visual Arts"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'Visual Arts';
";
}

if($department=="American Studies"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'American Studies';
";
}

if($department=="Biological Sciences"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'Biological Sciences';
";
}

if($department=="Chemistry and Physics"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Semester_ID = 'Chemistry and Physics';
";
}


if($department=="Computer Science"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'Computer Science';
";
}

if($department=="English"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'English';
";
}

if($department=="History and Philosophy"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'History and Philosophy';
";
}

if($department=="Criminology"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'Criminology';
";
}

if($department=="Industrial & Labor Relations"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'Industrial & Labor Relations';
";
}

if($department=="Liberal Studies"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'Liberal Studies';
";
}
if($department=="Mathematics"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'Mathematics';
";
}

else if($department=="Modern Languages"){
      $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
WHERE Department_Name = 'Modern Languages';
";
}

 
}

else if(isset($_POST['register'])){
    echo'COURSE ID MUST BE NUMERIC';
}
// Get a response from the database by sending the connection
// and the query
$response = @mysqli_query($dbc, $query);

// If the query executed properly proceed
if($response){


$resultCheck = mysqli_num_rows($response);
                if($resultCheck>0){
                         echo $username;
echo'<h1 style="color: cadetblue;padding-top: 20px;padding-left:15px;">Master Schedule</h1>';
echo '<table align="left"
cellspacing="5" cellpadding="8">
<tr><td align="left"><b>Course ID</b></td><td align="left"><b>CRN</b></td>
<td align="left"><b>Time</b></td>
<td align="left"><b>Course Name</b></td>
<td align="left"><b>Day</b></td>
<td align="left"><b>Semester</b></td>
<td align="left"><b>Department</b></td>';

// mysqli_fetch_array will return a row of data from the query
// until no further data is available

                    while($row = mysqli_fetch_array($response)){
 
echo '<tr><td align="left">' . $row['Course_ID'] . '</td><td align="left">'. $row['CRN'] . '</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['Time_Slot'] . '</td><td align="left">' . $row['day'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Department_Name'] . '</td>';
 
echo '</tr>';
}
                    
                }else{
                 echo' NO AVALIABLE CLASSES WITH THIS SPECIFICATION';
                  echo'<form action="courseSearch.php">
    <input type="submit" value="Search Again" />
</form>';
                }


 
 
echo '</table>';
 
} else {
    echo'<h1 style="color: cadetblue;padding-top: 20px;padding-left:15px;">Master Schedule</h1>';
echo '<table align="left"
cellspacing="5" cellpadding="8">
<tr><td align="left"><b>Course ID</b></td><td align="left"><b>CRN</b></td>
<td align="left"><b>Time</b></td>
<td align="left"><b>Course Name</b></td>
<td align="left"><b>Day</b></td>
<td align="left"><b>Semester</b></td>
<td align="left"><b>Department</b></td>';
 
echo "Entered Course ID must be numeric";
 $query = "SELECT course.Course_ID, course.CRN, course.Course_Name, timee.Time_Slot, timee.day, course.Semester_ID, department.Department_Name
FROM course 
INNER JOIN timee
ON course.Time_ID = timee.Time_ID
INNER JOIN department
ON course.Department_ID = department.Department_ID
";

$response = @mysqli_query($dbc, $query);

while($row = mysqli_fetch_array($response)){
 
echo '<tr><td align="left">' . $row['Course_ID'] . '</td><td align="left">'. $row['CRN'] . '</td><td align="left">' . $row['Course_Name'] . '</td><td align="left">' . $row['Time_Slot'] . '</td><td align="left">' . $row['day'] . '</td><td align="left">' . $row['Semester_ID'] . '</td><td align="left">' . $row['Department_Name'] . '</td>';
 
echo '</tr>';
}
 
echo mysqli_error($dbc);
 


}
  
 //end of submit 1
 
// Close connection to the database
mysqli_close($dbc);
?>
  <br> 
</div>
 <div style="height: 100px;"></div>

</body>
</html>