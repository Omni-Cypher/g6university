<?php
include_once 'header.php';
?>

    <section class="main-container">
        <div class="main-wrapper"></div>
        <h2>Main Page</h2>
        <div class="content">
        <?php
        if(isset($_SESSION['username'])){
            $username= $_SESSION['username'];
            echo"Welcome $username,You are logged in";     
            
               $sql = "SELECT * FROM users WHERE username='$username' AND level>0";
            $result = mysqli_query($conn,$sql);
            $resultCheck = mysqli_num_rows($result);
            if($resultCheck>0){
            echo" <br></br><p>you are an admin!!!<p>";
            }
        }
       
        
        ?>
        </div>
        </div>
    </section>

<?php
include_once 'footer.php';
?>
