<?php

if(isset($_POST['submit'])){
    include_once'dbh.inc2.php';
    
    $first = mysqli_real_escape_string($conn,$_POST['firstname']);
    $last = mysqli_real_escape_string($conn,$_POST['lastname']);
    $email = mysqli_real_escape_string($conn,$_POST['email']);
    $uid = mysqli_real_escape_string($conn,$_POST['username']);
    $pwd = mysqli_real_escape_string($conn,$_POST['password']);
    
    //error handlers
    //Check for empty fields
    
    if(empty($first) || empty($last) || empty($email) || empty($uid) || empty($pwd) ){
        header("Location: ../signup.php?signup=empty"); //signup=empty shows error message 
        exit();  
    }else{
        //check if input characters are valid
        if(!preg_match("/^[a-zA-Z]*$/",$first) || !preg_match("/^[a-zA-Z]*$/",$last) ){
            header("Location: ../signup.php?signup=invalid"); //signup=invalid shows error message 
            exit(); 
        }else{
            //check if email is valid
            if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
               header("Location: ../signup.php?signup=email"); //signup=email shows error message 
               exit();  
            }else{
                $sql = "SELECT * FROM users WHERE username='$uid'";
                $result = mysqli_query($conn,$sql);
                $resultCheck = mysqli_num_rows($result);
                if($resultCheck>0){
                    header("Location: ../signup.php?signup=usertaken"); //signup=usertaken shows error message 
                    exit();
                }else{
                    //hashing password
                    $hashedpwd = password_hash($pwd, PASSWORD_DEFAULT);
                    //insert the user into the database
                    $sql = "INSERT INTO users (firstname,lastname,email,username,password) VALUES('$first','$last', '$email','$uid','$hashedpwd');";
                    mysqli_query($conn,$sql);
                    header("Location: ../signup.php?signup=success"); 
                    exit();
                }
            }
        }
    }
}else{
    //if they just typed out the address without the form//
    header("Location: ../signup.php");
    exit();    
}