<?php

$servername = "mysqldb.ctzxklvx7teb.us-east-2.rds.amazonaws.com";
$username = "omnicypher";
$password = "S3RV3R!!";
$database = "login";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>